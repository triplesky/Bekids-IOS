//
//  ErrorMaker.h
//  Enlighten
//
//  Created by changle on 2022/7/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define kErrorIdExtra(__domain, __code, __identifier, __extraInfo) [ErrorMaker errorWithDomain:__domain code:__code identifier:__identifier extraInfo:__extraInfo]
#define kErrorExtra(__domain, __code, __message, __extraInfo) [ErrorMaker errorWithDomain:__domain code:__code message:__message extraInfo:__extraInfo]

#define kErrorMessage(__domain, __code, __message) [ErrorMaker errorWithDomain:__domain code:__code message:__message extraInfo:nil]
#define kErrorId(__domain, __code, __identifier) [ErrorMaker errorWithDomain:__domain code:__code identifier:__identifier extraInfo:nil]
#define kError(__domain, __code) [ErrorMaker errorWithDomain:__domain code:__code identifier:nil extraInfo:nil]
#define kIHError(__error) kErrorMessage(IHErrorDomain, __error.code, __error.message)

@interface ErrorMaker : NSObject

+ (NSError *)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code message:(NSString * _Nullable)message extraInfo:(NSDictionary * _Nullable)extraInfo;

+ (NSError *)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code identifier:(NSString * _Nullable)identifier extraInfo:(NSDictionary * _Nullable)extraInfo;

+ (void)registerMessage:(NSString *)message forErrorDomain:(NSErrorDomain)domain code:(NSInteger)code identifier:(NSString * _Nullable)identifier;

+ (void)registerMessage:(NSString *)message forErrorDomain:(NSErrorDomain)domain code:(NSInteger)code;

+ (NSString *)messageForDomain:(NSErrorDomain)domain code:(NSInteger)code identifier:(NSString * _Nullable)identifier;

@end

NS_ASSUME_NONNULL_END
