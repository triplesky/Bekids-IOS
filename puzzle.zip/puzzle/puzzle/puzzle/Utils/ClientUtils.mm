//
//  ClientUtils.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/9/23.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "ClientUtils.h"
#import <UIKit/UIKit.h>
#import <iHumanSDK/iHumanSDK.h>
#import <AVFoundation/AVFoundation.h>
//#import "launcher_view_controller.h"
#import <UnityFramework/NativeCommunicater.h>

@implementation ClientUtils
+ (NSString *)convertToString:(NSDictionary *) dic
{
    NSError * error = nil;
    NSData * jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&error];
    if (error) {
        DLog(@"Json转字典失败: %@",error);
        return nil;
    }
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

+ (NSString *)convertArrayToString:(NSArray *) array
{
    NSError * error = nil;
    NSData * jsonData = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
    if (error) {
        DLog(@"Json转字典失败: %@",error);
        return nil;
    }
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}
+ (NSDictionary *)convertToDictionary:(NSString *) jsonStr
{
    if (jsonStr == nil || jsonStr.length <=2) {
        return nil;
    }
    NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError * error = nil;
    NSDictionary * result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers  error:&error];
    if (error) {
        DLog(@"解析Json错误: %@ 原始数据:%@",error,jsonStr);
        return nil;
    }
    return result;
}

+ (NSArray *)convertToArray:(NSString *) jsonStr
{
    if (jsonStr == nil || jsonStr.length <=2) {
        return nil;
    }
    
    NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError * error = nil;
    NSArray * result = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions|NSJSONWritingPrettyPrinted  error:&error];
    if (error) {
        DLog(@"解析Json错误: %@ 原始数据:%@",error,jsonStr);
        return nil;
    }
    return result;
}

+ (void) quickSetSession
{
    NSError * error = nil;
    if([[AVAudioSession sharedInstance].category isEqualToString:AVAudioSessionCategoryPlayAndRecord]){
        return;
    }
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker|AVAudioSessionCategoryOptionAllowBluetooth error:&error];
    [[AVAudioSession sharedInstance] setActive:YES error:&error];
}

+ (BOOL) isPad
{
    return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad;
}

+ (UIImage*) load_image:(NSString *) name
{
    NSString * imagePath = [[NSBundle mainBundle] pathForResource:name ofType:@"png"];
    UIImage * image = [[UIImage alloc] initWithContentsOfFile:imagePath];
    return image;
}

+ (BOOL) is_current_user_login
{
    if ([iHumanSDK currentAccount].utoken == nil || [iHumanSDK currentAccount].utoken.length == 0) {
        return NO;
    }
    return YES;
}

+ (void) show_login_view_controller
{
//    ReadingAppController* appController =  (ReadingAppController*)[UIApplication sharedApplication].delegate;
//    [launcher_view_controller show:appController.window.rootViewController];
}

+ (void) report_login_result:(NSDictionary *) user_info user_token:(NSDictionary *) tokenInfo new_account:(BOOL) new_account
{
    NSMutableDictionary * account_info = [[NSMutableDictionary alloc] init];
    if (user_info) {
        account_info[@"user_info"] = user_info;
    }
    account_info[@"user_token"] = tokenInfo;
    account_info[@"new_account"] = @(new_account);
    
    NSString * jsonParams = [ClientUtils convertToString:account_info];
    [[NativeCommunicater sharedInstance] call_application:@"receive_user_login_info" params:jsonParams];
}

+ (void) report_login_result_from_sdk
{
    IHAccount *current = [iHumanSDK currentAccount];
    NSString * token = current.utoken;
    NSString * uid = current.uid;
    NSDictionary * token_info = @{@"utoken":token,@"uid":uid};
    [ClientUtils report_login_result:nil user_token:token_info new_account:NO];
}
@end
