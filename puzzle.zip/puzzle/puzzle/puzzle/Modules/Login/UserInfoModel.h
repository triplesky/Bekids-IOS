//
//  UserModel.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import <Foundation/Foundation.h>

@class UserRightsModel;
@interface UserInfoModel : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *head_image_url;
@property (nonatomic, assign) NSInteger gender;
@property (nonatomic, assign) NSInteger birthday;

@end

@interface UserRightsModel : NSObject

@property (nonatomic, assign) NSInteger all_pack;
@property (nonatomic, assign) NSInteger vip;
@property (nonatomic, assign) NSTimeInterval vip_expire_time;

#pragma mark custom properties
@property (nonatomic, copy) NSString *utoken;
@property (nonatomic, assign) NSUInteger cacheTime;

@end

