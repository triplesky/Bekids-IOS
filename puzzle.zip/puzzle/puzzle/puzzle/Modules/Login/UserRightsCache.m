//
//  UserCache.m
//  Enlighten
//
//  Created by changle on 2022/7/13.
//

#import "UserRightsCache.h"
@import FMDB;
#import <sqlite3.h>

#define DB_SECRETKEY @"YpKZiRfbVJuMA4os"
#define DB_SECRETKEY2 @"9UVB1TFdixQZ80jd"

static NSString *const kMainTable = @"MainTable";

@interface UserRightsCache ()

@property (nonatomic, copy) NSString *path;
@property (nonatomic, strong) FMDatabase *db;

@property (nonatomic, strong) UserRightsModel *userRightsModel;

@end

@implementation UserRightsCache

- (instancetype)initWithDirectory:(NSString *)directory filename:(NSString *)filename {
    if (self = [super init]) {
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:directory isDirectory:nil]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        self.path = [directory stringByAppendingPathComponent:filename];
        
        [self setupDB];
        
        if (![self.db executeUpdate:[NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (\n"
                           "\t id INTEGER PRIMARY KEY AUTOINCREMENT, \n"
                           "\t userRightsJson TEXT NOT NULL \n"
                                    ");\n", kMainTable]]) {
            DLog(@"create table %@ error", kMainTable);
        }
    }
    
    return self;
}

- (void)dealloc {
    [self close];
}

- (void)saveUserRightsModel:(UserRightsModel *)model {
    [self.db beginExclusiveTransaction];
    
    if (![self.db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", kMainTable]]) {
        [self.db rollback];
        DLog(@"saveUserRightsModel delete error");
        return;
    }
    
    if (model == nil || model.utoken.length == 0) {
        return;
    }
    
    model.cacheTime = [[NSDate date] timeIntervalSince1970];
    
    if (![self.db executeUpdate:[NSString stringWithFormat:@"INSERT INTO %@ (userRightsJson) VALUES (?)", kMainTable], [model yy_modelToJSONString]]) {
        [self.db rollback];
        DLog(@"saveUserRightsModel insert error: %@, %@", kMainTable, [model yy_modelToJSONString]);
        return;
    }
    
    [self.db commit];
    
    _userRightsModel = model;
}

- (void)clearUserRightsModel {
    if (![self.db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", kMainTable]]) {
        DLog(@"clearUserRightsModel error");
    }
    
    _userRightsModel = nil;
}

- (UserRightsModel *)userRightsModel {
    if (_userRightsModel == nil) {
        
        FMResultSet *res = [self.db executeQuery:[NSString stringWithFormat:@"SELECT * FROM %@", kMainTable]];
        
        UserRightsModel *model = nil;
        NSError *error = nil;
        while ([res nextWithError:&error]) {
            model = [UserRightsModel yy_modelWithJSON:[res stringForColumn:@"userRightsJson"]];
        }
        
        if (error) {
            DLog(@"%@", error);
        }
        
        if (model == nil) {
            return nil;
        }
        
        NSUInteger dur = [[NSDate date] timeIntervalSince1970] - model.cacheTime;
        if (dur < 0 || dur > 60 * 60 * 24 * 7) { // 用户权益，7天强制过期
            [self clearUserRightsModel];
            return nil;
        }
        
        if (model.utoken) {
            _userRightsModel = model;
        }
    }
    
    return _userRightsModel;
}

#pragma mark -

- (void)setupDB
{
    self.db = [FMDatabase databaseWithPath:self.path];
    
    
#ifdef ENVIRONMENT_PRODUCTION
    char *chars = calloc(1, DB_SECRETKEY.length + 1);
    chars[DB_SECRETKEY.length] = '\0';
    
    for (int i = 0; i < DB_SECRETKEY.length; i++) {
        char c1 = [DB_SECRETKEY characterAtIndex:i];
        char c2 = [DB_SECRETKEY2 characterAtIndex:DB_SECRETKEY.length - 1 - i];
        char c = (c1 ^ c2);
        chars[DB_SECRETKEY.length - 1 - i] = c;
    }
    
    [self.db setKey:[NSString stringWithUTF8String:chars]];
    
    free(chars);
#endif
}

- (FMDatabase *)db {
    if (![_db isOpen]) {
        [_db openWithFlags:SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE];
    }
    
    return _db;
}

- (void)close {
    [self.db close];
    self.db = nil;
}

@end
