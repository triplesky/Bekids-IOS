//
//  LoginModel.h
//  Enlighten
//
//  Created by changle on 2022/7/11.
//

#import <Foundation/Foundation.h>
#import "UserInfoModel.h"

@interface LoginUTokenModel : NSObject

@property (nonatomic, copy) NSString *expire;
@property (nonatomic, copy) NSString *uid;
@property (nonatomic, copy) NSString *utoken;

@end

@interface LoginModel : NSObject

@property (nonatomic, copy) NSString *uid;
@property (nonatomic, strong) LoginUTokenModel *utoken;
@property (nonatomic, assign) BOOL new_user;

@end


