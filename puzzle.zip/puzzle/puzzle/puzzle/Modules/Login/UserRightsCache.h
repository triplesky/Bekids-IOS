//
//  UserCache.h
//  Enlighten
//
//  Created by changle on 2022/7/13.
//

#import <Foundation/Foundation.h>
#import "UserInfoModel.h"

NS_ASSUME_NONNULL_BEGIN

/// 用户权益缓存，目的是断网时用户也能享受权益
@interface UserRightsCache : NSObject

- (instancetype)initWithDirectory:(NSString *)directory filename:(NSString *)filename;

- (void)saveUserRightsModel:(UserRightsModel *)model;

- (void)clearUserRightsModel;

- (UserRightsModel *)userRightsModel;

@end

NS_ASSUME_NONNULL_END
