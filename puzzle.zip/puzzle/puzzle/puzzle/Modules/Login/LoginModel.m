//
//  LoginModel.m
//  Enlighten
//
//  Created by changle on 2022/7/11.
//

#import "LoginModel.h"

@implementation LoginUTokenModel

@end

@implementation LoginModel

@end
