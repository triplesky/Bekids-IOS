//
//  UserCenter.m
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "UserCenter.h"
#import "UserRightsCache.h"
#import "PurchaseManager.h"

static NSString *const kUserLoginInfoKey = @"AppLoginInfo";
static NSString *const kUserUserInfoKey = @"AppUserInfo";

NSString *const UserCenterLoginUpdateNotification = @"UserCenterLoginUpdateNotification";
NSString *const UserCenterUserInfoUpdateNotification = @"UserCenterUserInfoUpdateNotification";

@interface UserCenter ()

@property (nonatomic, strong) UserRightsCache *cache;
@property (nonatomic, assign) UserCenterLoginMode mode;

@end

@implementation UserCenter

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static UserCenter *instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    if (self = [super init]) {
        self.cache = [[UserRightsCache alloc] initWithDirectory:AppLibraryDirectory filename:@"UserCenterCache"];
        [self loadLoginInfo];
        [self loadUserInfo];
        [self.cache userRightsModel]; // 过期会自动删除
        
        [self updateLoginStateShouldNoti:NO];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tokenInvalidNoti:) name:LoginTokenExpiredNotification object:nil];
    }
    
    return self;
}

- (void)setupWithMode:(UserCenterLoginMode)mode {
    self.mode = mode;
}

- (void)updateLoginStateShouldNoti:(BOOL)shouldNoti {
    if (self.loginModel) {
        if (self.userRightsModel) {
            _loginState = LoginStateLogin;
        } else {
            
            // 可能手动清。也可能自动清。
            if (self.mode == UserCenterLoginModeSupportVisitor) {
                if (_loginState != LoginStateTokenInvalid) {
                    self.loginModel.utoken.utoken = @"expired";
                    [[Network sharedInstance] setValue:self.loginModel.utoken.utoken forCommonParamKey:@"utoken"];
                    [[NSUserDefaults standardUserDefaults] setObject:[self.loginModel yy_modelToJSONString] forKey:kUserLoginInfoKey];
                    _loginState = LoginStateTokenInvalid;
                    
                    if (shouldNoti) {
                        [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterLoginUpdateNotification object:nil];
                        [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
                    }
                }
            } else {
                [self clearLoginInfo];
                _loginState = LoginStateLogout;
                
                if (shouldNoti) {
                    [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterLoginUpdateNotification object:nil];
                    [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
                }
            }
        }
    } else {
        // 可能手动清。也可能自动清。
        [self clearLoginInfo];
        _loginState = LoginStateLogout;
        
        if (shouldNoti) {
            [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterLoginUpdateNotification object:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
        }
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)tokenInvalidNoti:(NSNotification *)noti {
    [self.cache clearUserRightsModel];
    [self updateLoginStateShouldNoti:YES];
}

- (void)loginWithSuccess:(void (^)(void))success failure:(void (^)(NSError * _Nonnull))failure {
    
    if (self.loginState == LoginStateTokenInvalid) {
        [iHumanSDK logoutWithBlock:nil];
    }
    
    IHLoginConfig *loginConfig = [self getLoginConfig];
    [iHumanSDK showLoginViewWithConfig:loginConfig handleLoginInfoBlock:^(NSString * _Nonnull uid, NSString * _Nonnull ticket) {
        DLog(@"showLoginView uid = %@, ticket = %@", uid, ticket);
        
        [API requestLoginWithUid:uid ticket:ticket success:^(LoginModel * _Nonnull loginModel, UserInfoModel * _Nullable userInfoModel, UserRightsModel * _Nullable userRightsModel) {
            [self saveLoginInfo:loginModel];
            [self saveUserInfo:userInfoModel];
            [self saveUserRights:userRightsModel];
            
            [self updateLoginStateShouldNoti:NO];
            
            [iHumanSDK finishedLoginWithUtoken:loginModel.utoken.utoken];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterLoginUpdateNotification object:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
        } failure:^(NSError * _Nonnull error) {
            [iHumanSDK failedLogin];
            [iHumanSDK keyboardManagerEnable:NO];//关闭
            if (failure) { failure(error); }
        }];
    } finishedBlock:^(IHError * _Nonnull error) {
            if (error.code == IHErrorCodeOK || error.code == IHErrorCodeSignupNewAccount) {
                if (success) { success(); }
            } else if (error.code == IHErrorCodeLoginUserCanceled) {
                // 用户取消登录
                
            } else if (error.code == IHErrorCodeNotConnectedToInternet) {
                // 没网了
            } else if (error.code == IHErrorCodeWrongVerifyCode) {
                // 验证码错误
            } else if (error.code == IHErrorCodeWrongParameter) {
                // 电话号输错了
            } else if (error.code == 310) {
                // 网络错误
            } else {
                // 其他错误
            }
            
            if (!(error.code == IHErrorCodeOK || error.code == IHErrorCodeSignupNewAccount)) {
                [iHumanSDK failedLogin];
                [iHumanSDK keyboardManagerEnable:NO];//关闭
                if (failure) {
                    failure(kIHError(error));
                }
            }
            DLog(@"showLoginView isnew:%d , error %ld, %@", error.code == IHErrorCodeSignupNewAccount, error.code, error.message);
    }];
}

- (void)logout {
    [self clearLoginInfo];
    [self updateLoginStateShouldNoti:YES];
}

- (void)refreshUserInfoWithSuccess:(void (^)(UserInfoModel * _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure {
    
    [API requestUserInfoWithSuccess:^(UserInfoModel * _Nonnull userInfoModel, UserRightsModel * _Nullable userRightsModel) {
        
        [self saveUserInfo:userInfoModel];
        [self saveUserRights:userRightsModel];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
        
        if (success) {
            success(userInfoModel);
        }
    } failure:^(NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
    
}

- (IHLoginConfig *)getLoginConfig {
    IHLoginConfig *config = [IHLoginConfig new];
    config.loginOnly = YES;
    config.orientation = IHLoginViewOrientationTypeLandscape;
    config.supportOverSeasType = IHLoginSupportOnlyOverseas;
    config.presentationStyle = IHLoginViewPresentationFullScreen;
    
    config.loginUIConfig = [self getLoginUIConfig];//设置自定义UI
    return config;
}

- (IHLoginUIConfig *)getLoginUIConfig {
    
    IHLoginUIConfig *loginUIConfig = [IHLoginUIConfig new];
//    loginUIConfig.backgroundImage = IS_PAD ? [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"ic_login_bg_ipad" ofType:@"png"]] : [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"ic_login_bg" ofType:@"png"]];
    loginUIConfig.backgroundImage = [UIImage imageNamed:@"bg_1"];
    
    loginUIConfig.closeButtonImage = [UIImage imageNamed:@"btn_skip_"];
    loginUIConfig.closeButtonWidth = @(IS_PAD ? 47.0 : 47.0);
    loginUIConfig.closeButtonHeight = @(IS_PAD ? 47.0 : 47.0);
    
    loginUIConfig.backButtonImage = [UIImage imageNamed:@"btn_back_"];
    loginUIConfig.backButtonWidth = @(IS_PAD ? 12.5 : 12.5);
    loginUIConfig.backButtonHeight = @(IS_PAD ? 19.5 : 19.5);
    
    loginUIConfig.titleLabelTextColor = HEXCOLOR(0xde7d00);
    
    loginUIConfig.inputTextColor = HEXCOLOR(0x666666);
    loginUIConfig.inputBackgroundColor = HEXCOLOR(0xffffff);
    loginUIConfig.inputPlaceholderColor = HEXCOLOR(0xc8c8c8);
    loginUIConfig.inputBorderWidth = @(1); // @2x?
    loginUIConfig.inputCornerRadius = @(15); // @2x?
    loginUIConfig.inputBorderNormalColor = HEXCOLOR(0xbebebe);
    loginUIConfig.inputBorderHighlightedColor = HEXCOLOR(0xffaa15);
    
    loginUIConfig.inputClearImage = [UIImage imageNamed:@"btn_clear_"];
    loginUIConfig.inputUnsecureImage = [UIImage imageNamed:@"btn_password_show_"];
    loginUIConfig.inputSecureImage = [UIImage imageNamed:@"btn_password_display_"];
    
    loginUIConfig.forgetPasswordButtonTitleColor = HEXCOLOR(0xde7d00);

    loginUIConfig.submitButtonNormalImage = [UIImage imageNamed:@"btn_next_normal_"];
    loginUIConfig.submitButtonDisabledImage = [UIImage imageNamed:@"btn_next_disabled_"];
    
    loginUIConfig.createEmailAccountButtonTitleColor = HEXCOLOR(0xFFFFFF);
    loginUIConfig.createEmailAccountButtonImage = [UIImage imageNamed:@"btn_create_"];

    loginUIConfig.privacyCheckedImage = [UIImage imageNamed:@"Component1_"];
    loginUIConfig.privacyUncheckedImage = [UIImage imageNamed:@"Component2_"];
    loginUIConfig.privacyTextNormalColor = HEXCOLOR(0x666666);
    loginUIConfig.privacyTextHighlightedColor = HEXCOLOR(0xec651f);
    
    loginUIConfig.emailCodeReceiveTipTextColor = HEXCOLOR(0x666666);
    
    loginUIConfig.createEmailAccountButtonTitleColor = HEXCOLOR(0xffffff);// 5.9.56 可以不配置
    loginUIConfig.createEmailAccountButtonImage = [UIImage imageNamed:@"btn_create_"];// 5.9.56 可以不配置

    loginUIConfig.createEmailAccountOrLoginButtonTitleColor = HEXCOLOR(0x666666);//added 5.9.56
    loginUIConfig.createEmailAccountOrLoginButtonTitleHighlightColor = HEXCOLOR(0xec651f);//added 5.9.56
    loginUIConfig.emailConfirmButtonNormalImage = [UIImage imageNamed:@"btn_create_"];//added 5.9.56
    loginUIConfig.emailConfirmButtonDisabledImage = [UIImage imageNamed:@"btn_create_02_"];//added 5.9.56
    loginUIConfig.emailConfirmButtonTitleColor = HEXCOLOR(0xffffff);//added 5.9.56
    
    return loginUIConfig;
}

- (void)clearLoginInfo {
    _loginModel = nil;
    
    [iHumanSDK logoutWithBlock:nil];
    
    [[Network sharedInstance] setValue:nil forCommonParamKey:@"utoken"];
    [[Network sharedInstance] setValue:nil forCommonParamKey:@"uid"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserLoginInfoKey];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserUserInfoKey];
    
    [self.cache clearUserRightsModel];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
}

- (void)loadLoginInfo {
    NSString *loginInfo = [[NSUserDefaults standardUserDefaults] objectForKey:kUserLoginInfoKey];
    if (loginInfo.length == 0) {
        return;
    }
    
    LoginModel *loginModel = [LoginModel yy_modelWithJSON:loginInfo];
    [[Network sharedInstance] setValue:loginModel.utoken.utoken forCommonParamKey:@"utoken"];
    [[Network sharedInstance] setValue:loginModel.utoken.uid forCommonParamKey:@"uid"];
    
    _loginModel = loginModel;
}

- (void)saveLoginInfo:(LoginModel *)loginModel {
    [[Network sharedInstance] setValue:loginModel.utoken.utoken forCommonParamKey:@"utoken"];
    [[Network sharedInstance] setValue:loginModel.utoken.uid forCommonParamKey:@"uid"];
    [[NSUserDefaults standardUserDefaults] setObject:[loginModel yy_modelToJSONString] forKey:kUserLoginInfoKey];
    _loginModel = loginModel;
}

- (void)loadUserInfo {
    NSString *userInfo = [[NSUserDefaults standardUserDefaults] objectForKey:kUserUserInfoKey];
    if (userInfo.length == 0) {
        return;
    }
    _userInfoModel = [UserInfoModel yy_modelWithJSON:userInfo];
}

// 拆开存，便于分段更新
- (void)saveUserInfo:(UserInfoModel *)userInfoModel {
    if (userInfoModel == nil) {
        return;
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:[userInfoModel yy_modelToJSONString] forKey:kUserUserInfoKey];
    _userInfoModel = userInfoModel;
}

- (void)saveUserRights:(UserRightsModel *)userRightsModel {
    if (userRightsModel == nil) {
        return;
    }
    
    userRightsModel.utoken = self.loginModel.utoken.utoken;
    [self.cache saveUserRightsModel:userRightsModel];
}

- (UserRightsModel *)userRightsModel {
    if (self.cache.userRightsModel.utoken && self.loginModel.utoken.utoken.length && [self.cache.userRightsModel.utoken isEqualToString:self.loginModel.utoken.utoken]) {
        return self.cache.userRightsModel;
    }
    
    return nil;
}

@end
