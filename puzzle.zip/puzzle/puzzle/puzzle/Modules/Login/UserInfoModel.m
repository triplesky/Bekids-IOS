//
//  UserModel.m
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "UserInfoModel.h"

@implementation UserInfoModel

@end

@implementation UserRightsModel

@end
