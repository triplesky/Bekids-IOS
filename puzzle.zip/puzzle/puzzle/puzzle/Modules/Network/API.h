//
//  API.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import <Foundation/Foundation.h>
#import "Network.h"
#import "APIModelHeader.h"
#import "APIURL.h"

NS_ASSUME_NONNULL_BEGIN

@interface API : NSObject

+ (NSURLSessionDataTask *)postApi:(NSString *)api params:(NSDictionary * _Nullable)params responseModelClass:(Class _Nullable)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)vertifyResponse processModelBlock:(nullable id (^)(id _Nullable model))processModelBlock success:(void (^)(id _Nullable model, NSDictionary *responseObject))success failure:(void (^)(NSError * _Nonnull error))failure;


+ (NSURLSessionDataTask *)getApi:(NSString *)api params:(NSDictionary * _Nullable)params responseModelClass:(Class _Nullable)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)vertifyResponse processModelBlock:(nullable id (^)(id _Nullable model))processModelBlock success:(void (^)(id _Nullable model, NSDictionary *responseObject))success failure:(void (^)(NSError * _Nonnull error))failure;

+ (void)requestLoginWithUid:(NSString *)uid ticket:(NSString *)ticket success:(void (^)(LoginModel *loginModel, UserInfoModel * _Nullable userInfoModel, UserRightsModel * _Nullable userRightsModel))success failure:(void (^)(NSError * error))failure;

+ (void)requestUserInfoWithSuccess:(void (^)(UserInfoModel *userInfoModel, UserRightsModel * _Nullable userRightsModel))success failure:(void (^)(NSError *error))failure;

@end

NS_ASSUME_NONNULL_END
