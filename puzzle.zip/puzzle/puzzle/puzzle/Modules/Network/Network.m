//
//  Network.m
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "Network.h"
#import "NetworkCache.h"

@import AFNetworking;

NSString * const LoginTokenExpiredNotification = @"LoginTokenExpiredNotification";

NSErrorDomain const NetworkErrorDomain = @"NetworkErrorDomain";
NSString *const ErrorResponseUserInfo = @"ErrorResponseUserInfo";


typedef NS_ENUM(NSUInteger, NetworkRequestMethod) {
    NetworkRequestMethodPost = 0,
    NetworkRequestMethodGet = 1,
};

@interface NetworkResponse : NSObject

@property (copy, nonatomic) NSString *msg;
@property (assign, nonatomic) NSInteger code;
@property (strong, nonatomic) id result;

@end

@implementation NetworkResponse

@end

@interface Network ()

@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;
@property (nonatomic, strong) NSMutableDictionary *coreParams;
@property (nonatomic, strong) NSMutableDictionary *commonParams;

@property (nonatomic, strong) NetworkCache *caches;

@end

@implementation Network

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static id instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    
    if (self = [super init]) {
        _sessionManager = [[AFHTTPSessionManager alloc] init];
        [_sessionManager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        _sessionManager.requestSerializer.timeoutInterval = 15;
        
        _coreParams = [NSMutableDictionary dictionary];
        _coreParams[@"deviceid"] = [iHumanSDK deviceId];
        _coreParams[@"device_type"] = [iHumanSDK isPad] ? @"pad" : @"phone";
        _coreParams[@"platform"] = @"ios";
        _coreParams[@"app_version"] = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
        
        _commonParams = [NSMutableDictionary dictionary];
        [_commonParams addEntriesFromDictionary:_coreParams];
        
        _caches = [[NetworkCache alloc] init];
    }
    
    return self;
}

#pragma mark - public

- (NSURLSessionDataTask *)postUrl:(NSString *)url params:(NSDictionary *)params responseModelClass:(Class)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)verifyResponse processModelBlock:(id  _Nonnull (^)(id _Nullable))processModelBlock success:(void (^)(id _Nullable, NSDictionary * _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure {
    
    return [self requestUrl:url method:NetworkRequestMethodPost params:params modelClass:modelClass cachePolicy:cachePolicy verifyResponse:verifyResponse processModelBlock:processModelBlock success:success failure:failure];
}

- (NSURLSessionDataTask *)getUrl:(NSString *)url params:(NSDictionary *)params responseModelClass:(Class)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)verifyResponse processModelBlock:(id  _Nonnull (^)(id _Nullable))processModelBlock success:(void (^)(id _Nullable, NSDictionary * _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure {
    
    return [self requestUrl:url method:NetworkRequestMethodGet params:params modelClass:modelClass cachePolicy:cachePolicy verifyResponse:verifyResponse processModelBlock:processModelBlock success:success failure:failure];
}

- (void)cancelWithTaskId:(NSUInteger)taskId {
    NSArray *dataTasks = [self.sessionManager dataTasks];
    for (NSURLSessionDataTask *task in dataTasks) {
        if (task.taskIdentifier == taskId) {
            [task cancel];
        }
    }
}

- (void)clearCaches {
    [self.caches clearCaches];
}


- (NSURLSessionDataTask *)requestUrl:(NSString *)url method:(NetworkRequestMethod)method params:(NSDictionary *)params modelClass:(Class _Nullable)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)verifyResponse processModelBlock:(nullable id (^)(id _Nullable model))processModelBlock success:(void (^)(id _Nullable model, NSDictionary * _Nonnull))success failure:(void (^)(NSError * _Nonnull error))failure {
    
    //增加公共参数
    NSMutableDictionary *_params = [NSMutableDictionary dictionaryWithDictionary:[self getCommonParams]];
    if (params) {
        [_params addEntriesFromDictionary:params];
    }
    
    NSString *sign = [iHumanSDK appSignForParams:_params];
    if (sign.length > 0) {
        _params[@"sign"] = sign;
    }
    
    void (^successBlock)(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) = ^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
        
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE, 0), ^{
            
    #ifdef DEBUG
            NSString *responseJsonStr = [responseObject yy_modelToJSONString];
            DLog(@"receive %@ success: %@", url, responseJsonStr);
    #endif

            
            NetworkResponse *response = [self parseResponseObject:responseObject modelClass:modelClass processModelBlock:processModelBlock];
            
            if (response.code == 0) {
                
                if (modelClass == nil || response.result) {
                    
                    BOOL verify = YES;
                    if (verifyResponse) {
                        verify = [iHumanSDK verifyResponse:responseObject forURL:url];
                    }
                    
                    if (!verify) {
                        
                        if (failure) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                failure(kErrorExtra(NetworkErrorDomain, NetworkErrorCodeVerifyResponseFailed, nil, @{ErrorResponseUserInfo : responseObject ? : @{}}));
                            });
                        }
                        
                        return;
                    }
                    
                    if (cachePolicy == NetworkCachePolicyUseCacheWhenFailed) {
                        [self.caches saveResponseObjectWithUrl:url params:_params responseObject:responseObject];
                    }
                    
                    if (success) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            success(response.result, responseObject);
                        });
                    }
                    
                } else {
                    if (failure) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            failure(kErrorExtra(NetworkErrorDomain, NetworkErrorCodeAPIModelIsNotValid, nil, @{ErrorResponseUserInfo : responseObject ? : @{}}));
                        });
                    }
                }
                
                return;
            }
            
            if (response.code == 102) {
                //参数错误
            }
            if (response.code == 103) {
                //验签错误
                DLog(@"Invalid signature");
            }
            if (response.code == 252) {
                // token失效
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[NSNotificationCenter defaultCenter] postNotificationName:LoginTokenExpiredNotification object:nil];
                });
            }
            
            if (failure) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    failure(kErrorMessage(IHResponseErrorDomain, response.code, response.msg));
                });
                
            }
            
        });
    };

    
    void (^failureBlock)(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) = ^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        DLog(@"%@", error);
        
        if (cachePolicy == NetworkCachePolicyUseCacheWhenFailed) {
            [self.caches loadResponseObjectWithUrl:url params:_params completion:^(id  _Nullable responseObject) {
                BOOL complete = NO;
                if (responseObject) {
                    NetworkResponse *response = [self parseResponseObject:responseObject modelClass:modelClass processModelBlock:processModelBlock];
                    if (response && response.code == 0 && response.result) {
                        if (success) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                success(response.result, responseObject);
                            });
                        }
                        complete = YES;
                    }
                }
                
                if (!complete) {
                    if (failure) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            failure(error);
                        });
                    }
                }
            }];
            
            return;
        }
        
        
        if (failure) {
            failure(error);
        }
    };
    
    NSURLSessionDataTask *task = nil;
    if (method == NetworkRequestMethodPost) {
        task = [self.sessionManager POST:url parameters:_params progress:nil success:successBlock failure:failureBlock];
        DLog(@"POST URL: %@, HTTPBody: %@", task.originalRequest.URL, [[NSString alloc] initWithData:task.originalRequest.HTTPBody encoding:NSUTF8StringEncoding]);
    } else {
        task = [self.sessionManager GET:url parameters:_params progress:nil success:successBlock failure:failureBlock];
        DLog(@"GET URL: %@", task.originalRequest.URL);
    }
    
    return task;
}

- (void)setValue:(NSString *)value forCommonParamKey:(NSString *)key {
    if ([self.coreParams.allKeys containsObject:key]) {
        DLog(@"Can't modify core params: %@", key);
        return;
    }
    
    self.commonParams[key] = value;
}

#pragma mark - private

+ (NSMutableDictionary *)getCommonParams {
    return [[Network sharedInstance] getCommonParams];
}

- (NSMutableDictionary *)getCommonParams {
    self.commonParams[@"timestamp"] = @([iHumanSDK currentServerTime]);
    return self.commonParams;
}

- (NetworkResponse *)parseResponseObject:(id)responseObject modelClass:(Class _Nullable)modelClass processModelBlock:(nullable id (^)(id _Nullable model))processModelBlock {
    NetworkResponse *response = nil;
    
    if (responseObject) {
        response = [NetworkResponse yy_modelWithJSON:responseObject];
    }
    
    if (response.result && modelClass) {
        response.result = [modelClass yy_modelWithJSON:response.result];
        if (processModelBlock) {
            id processedModel = processModelBlock(response.result);
            if (processedModel) {
                response.result = processedModel;
            }
        }
    }
    
    return response;
}

@end
