//
//  API.m
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "API.h"
#import "APIURL.h"

@implementation API

+ (NSURLSessionDataTask *)postApi:(NSString *)api params:(NSDictionary *)params responseModelClass:(Class)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)vertifyResponse processModelBlock:(id  _Nonnull (^)(id _Nullable))processModelBlock success:(void (^)(id _Nullable, NSDictionary * _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure {
    NSString *url = [API_BASE_URL stringByAppendingString:api ? : @""];
    return [NetworkShare postUrl:url params:params responseModelClass:modelClass cachePolicy:cachePolicy verifyResponse:vertifyResponse processModelBlock:processModelBlock success:success failure:failure];
}

+ (NSURLSessionDataTask *)getApi:(NSString *)api params:(NSDictionary *)params responseModelClass:(Class)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)vertifyResponse processModelBlock:(id  _Nonnull (^)(id _Nullable))processModelBlock success:(void (^)(id _Nullable, NSDictionary * _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure {
    NSString *url = [API_BASE_URL stringByAppendingString:api ? : @""];
    return [NetworkShare getUrl:url params:params responseModelClass:modelClass cachePolicy:cachePolicy verifyResponse:vertifyResponse processModelBlock:processModelBlock success:success failure:failure];
}

+ (void)requestLoginWithUid:(NSString *)uid ticket:(NSString *)ticket success:(void (^)(LoginModel * _Nonnull, UserInfoModel * _Nullable, UserRightsModel * _Nullable))success failure:(void (^)(NSError * _Nonnull))failure {
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"ticket"] = ticket;
    params[@"uid"] = uid;
    
    [self postApi:API_LOGIN params:params responseModelClass:[LoginModel class] cachePolicy:NetworkCachePolicyNone verifyResponse:YES processModelBlock:nil success:^(LoginModel * _Nullable loginModel, NSDictionary * _Nonnull responseObject) {
        
        UserInfoModel *userInfoModel = nil;
        UserRightsModel *userRightsModel = nil;
        
        // success、loginModel存在 -> responseObject可以放心取到loginModel的下一层
        // 把麻烦限制在最小范围内
        id user_info = responseObject[@"result"][@"user_info"];
        if (user_info && user_info != [NSNull null] && [user_info isKindOfClass:[NSDictionary class]]) {
            userInfoModel = [UserInfoModel yy_modelWithJSON:user_info];
            
            id rights = user_info[@"rights"];
            if (rights && rights != [NSNull null] && [rights isKindOfClass:[NSDictionary class]]) {
                userRightsModel = [UserRightsModel yy_modelWithJSON:rights];
            }
        }
        
        if (success) {
            success(loginModel, userInfoModel, userRightsModel);
        }
    } failure:^(NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

+ (void)requestUserInfoWithSuccess:(void (^)(UserInfoModel * _Nonnull, UserRightsModel * _Nullable))success failure:(void (^)(NSError * _Nonnull))failure {
    
    [self postApi:API_GET_USER_INFO params:nil responseModelClass:[UserInfoModel class] cachePolicy:NetworkCachePolicyNone verifyResponse:YES processModelBlock:nil success:^(UserInfoModel *  _Nullable userInfoModel, NSDictionary * _Nonnull responseObject) {
        
        UserRightsModel *userRightsModel = nil;
        
        id rights = responseObject[@"result"][@"rights"];
        if (rights && rights != [NSNull null] && [rights isKindOfClass:[NSDictionary class]]) {
            userRightsModel = [UserRightsModel yy_modelWithJSON:rights];
        }
        
        if (success) {
            success(userInfoModel, userRightsModel);
        }
    } failure:^(NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

@end
