//
//  NetworkCache.m
//  puzzle
//
//  Created by changle on 2022/9/21.
//

#import "NetworkCache.h"
@import FMDB;
@import AFNetworking;
#import <sqlite3.h>

#define DB_SECRETKEY @"YpKZiRfbVJuMA4os"
#define DB_SECRETKEY2 @"9UVB1TFdixQZ80jd"

static NSString *const kMainTable = @"MainTable";

@interface NetworkCache ()

@property (nonatomic, copy) NSString *cachePath;
@property (nonatomic, strong) FMDatabaseQueue *dbQueue;
@property (nonatomic, strong) dispatch_queue_t backQueue;

@end

@implementation NetworkCache

- (instancetype)init {
    if (self = [super init]) {
        _backQueue = dispatch_queue_create("puzzle.network.cache.backqueue", DISPATCH_QUEUE_SERIAL);
        [self setupDB];
        [self createTables];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appWillTerminate:) name:UIApplicationWillTerminateNotification object:nil];
        
        // 分表不能依赖实例数据。分库也同理。
        // 库和表，要按照统一规则、结构来设计。
    }
    
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - public
- (void)saveResponseObjectWithUrl:(NSString *)url params:(NSDictionary *)params responseObject:(id)responseObject {
    NSDictionary *mParams = [self cachingParams:params];
    NSString *key = [self keyWithUrl:url params:mParams];
    dispatch_async(self.backQueue, ^{
        [self.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
            [self _saveResponseObject:responseObject key:key db:db];
        }];
    });
}

- (void)loadResponseObjectWithUrl:(NSString *)url params:(NSDictionary *)params completion:(void (^)(id _Nullable))completion {
    if (!completion) {
        return;
    }
    
    NSDictionary *mParams = [self cachingParams:params];
    NSString *key = [self keyWithUrl:url params:mParams];
    dispatch_async(self.backQueue, ^{
        [self.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
            NSDictionary *response = [self _loadWithKey:key db:db];
            completion(response);
        }];
    });
}

- (void)clearCaches {
    dispatch_async(self.backQueue, ^{
        [self.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
            [self _clearWithDb:db];
        }];
    });
}

#pragma mark - noti
- (void)appWillTerminate:(NSNotification *)noti
{
    dispatch_sync(self.backQueue, ^{
        [self.dbQueue inDatabase:^(FMDatabase *db) {
            // 执行完当前队列里的操作
        }];
    });
}

#pragma mark - 异步操作
- (void)setupDB
{
    dispatch_async(self.backQueue, ^{
        NSString *dir = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:[[[NSBundle mainBundle] bundleIdentifier] stringByAppendingPathComponent:@"net"]];
        if (![[NSFileManager defaultManager] fileExistsAtPath:dir]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        self.cachePath = [dir stringByAppendingPathComponent:@"Caches.db"];
        self.dbQueue = [FMDatabaseQueue databaseQueueWithPath:self.cachePath];
        [self.dbQueue inDatabase:^(FMDatabase *db) {
            
#ifdef ENVIRONMENT_PRODUCTION
            char *chars = calloc(1, DB_SECRETKEY.length + 1);
            chars[DB_SECRETKEY.length] = '\0';

            for (int i = 0; i < DB_SECRETKEY.length; i++) {
                char c1 = [DB_SECRETKEY characterAtIndex:i];
                char c2 = [DB_SECRETKEY2 characterAtIndex:DB_SECRETKEY.length - 1 - i];
                char c = (c1 ^ c2);
                chars[DB_SECRETKEY.length - 1 - i] = c;
            }

            [db setKey:[NSString stringWithUTF8String:chars]];
            
            free(chars);
#endif
        }];
    });
}

- (void)createTables
{
    dispatch_async(self.backQueue, ^{
        [self.dbQueue inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
            BOOL success = [self _createTableWithDb:db];
            *rollback = !success;
        }];
    });
}

- (NSDictionary *)cachingParams:(NSDictionary *)params {
    NSMutableDictionary *mParams = [NSMutableDictionary dictionaryWithDictionary:params];
    mParams[@"utoken"] = nil;
    mParams[@"sign"] = nil;
    mParams[@"timestamp"] = nil;
    return mParams;
}

- (NSString *)keyWithUrl:(NSString *)url params:(NSDictionary *)params {
    NSString *form = AFQueryStringFromParameters(params);
    NSString *key = [url stringByAppendingFormat:@"?%@", form];
    return key;
}

#pragma mark - SQL
- (BOOL)_createTableWithDb:(FMDatabase *)db
{
    BOOL success = [db executeUpdate:@"CREATE TABLE IF NOT EXISTS api_cache_response ( "
                    "entry_ID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, "
                    "version TEXT NOT NULL, "
                    "response BLOB NOT NULL, "
                    "request_key TEXT UNIQUE, "
                    "ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                    ")"
    ];
    if (!success) { return NO; }
    
    success = [db executeUpdate:@"CREATE INDEX IF NOT EXISTS request_key_index ON api_cache_response(request_key)"];
    if (!success) { return NO; }
    
    return success;
}

- (BOOL)_clearWithDb:(FMDatabase *)db {
    BOOL success = [db executeUpdate:@"DELETE FROM api_cache_response"];
    return success;
}

- (BOOL)_saveResponseObject:(NSDictionary *)responseObject key:(NSString *)key db:(FMDatabase *)db {
    NSData *data = [responseObject yy_modelToJSONData];
    NSString *version = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
    BOOL success = [db executeUpdate:@"INSERT OR REPLACE INTO api_cache_response (request_key, response, version) VALUES (?, ?, ?)", key, data, version];
    DLog(@"NetworkCaches SaveKey: %@", key);
    return success;
}

- (NSDictionary *)_loadWithKey:(NSString *)key db:(FMDatabase *)db {
    
    NSString *version = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
    FMResultSet *rs = [db executeQuery:@"SELECT * FROM api_cache_response WHERE request_key = ? AND version = ?", key, version];
    NSDictionary *responseObject = nil;
    
    while ([rs nextWithError:nil]) {
        NSData *data = [rs dataForColumn:@"response"];
        responseObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    }
    
    return responseObject;
}

@end
