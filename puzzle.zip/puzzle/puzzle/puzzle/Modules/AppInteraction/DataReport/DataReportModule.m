//
//  DataReportModule.m
//  Enlighten
//
//  Created by changle on 2022/8/4.
//

#import "DataReportModule.h"

@implementation DataReportModule

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(log_status:(NSString *)statusId attributes:(nullable NSDictionary *)attributes)
{
    [iHumanSDK logStatus:statusId attributes:attributes];
}

//上传打点事件
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(log_action:(NSString *)actionId attributes:(nullable NSDictionary *)attributes)
{
    DLog(@"检测上报事件:%@ %@",actionId,attributes);
    [iHumanSDK logAction:actionId attributes:attributes];
}

/**
 上传事件数据
 */
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(log_action_data:(NSString *)actionId attributes:(nullable NSDictionary *)attributes)
{
    DLog(@"检测上报事件 logActionData :%@ %@",actionId,attributes);
    [iHumanSDK logActionData:actionId attributes:attributes];
}

/**
 上报页面开始
 */
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(log_page_start:(NSString *)pageName)
{
    [iHumanSDK logPageStart:pageName];
}

/*
  上报页面结束
 */
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(log_page_end:(NSString *)pageName)
{
    [iHumanSDK logPageEnd:pageName];
}

/**
 统计网络事件
 */
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(log_net_work_event:(NSDictionary *) event)
{
    IHNetworkEvent * netevent = [[IHNetworkEvent alloc] init];
    netevent.URL = event[@"url"];
    netevent.respCode = [event[@"code"] intValue];
    netevent.respMessage = event[@"message"];
    netevent.apiCode = [event[@"api_code"] intValue];
    netevent.lookupTime = [event[@"lookup"] intValue];
    netevent.ip = event[@"ip"];
    [iHumanSDK logNetworkEvent:netevent];
}


@end
