//
//  OperationalModule.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/9.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "OperationalModule.h"
#import <StoreKit/StoreKit.h>
#import "AppConfigs.h"

@interface OperationalModule()<IHUserBenefitDelegate,IHOperationDelegate>
@property (nonatomic,strong) NSMutableDictionary* webview_cache;
@end

@implementation OperationalModule

- (instancetype)init
{
    self = [super init];
    if (self) {
        [IHOperation setBenefitDelegate:self];
        [IHOperation setListener:self];
        self.webview_cache = [[NSMutableDictionary alloc] init];
        [IHOperation enableAutoUpdate:YES];
    }
    return self;
}

#pragma mark-IHOperationProtocol
// 精彩活动是否有更新
- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(has_new_event){
    [self call_application:@"has_new_event" params:@"has_new_eventhas_new_eventhas_new_event" block:blockID];
    return [self return_bool:[IHOperation hasNewEvent]];
}

//新版开启精彩活动页面
- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_event_view_with_hide_block){
    [IHOperation showEventViewWithHideBlock:^{
        [self make_bool_params:@"closed" value:YES];
        [self call_application:@"show_event_view_with_hide_block" params:[self get_params] block:blockID];
    }];
}

//主动关闭精彩活动页面
- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(hidn_event_view_with_completion){
    [IHOperation hideEventViewWithCompletion:^{
        [self make_bool_params:@"closed" value:YES];
        [self call_application:@"hidn_event_view_with_completion" params:[self get_params] block:blockID];
    }];
}


//暂停显示所有运营页面
- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(suspend_presenting_operationView){
    return [self return_bool:[IHOperation suspendPresentingOperationView]];
}

//恢复显示所有运营页面
- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(resume_presenting_operationView){
    return [self return_bool:[IHOperation suspendPresentingOperationView]];
}

#pragma mark-IHRecommendProtocol

// 检查推荐App是否有最新福利
- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(has_new_benefits){
    return [self return_bool:[IHOperation hasNewBenefits]];
}

// 检查推荐App是否已准备就绪
- (NSDictionary *) get_recommend_app_info:(IHRecommendApp*) app
{
    return @{
        @"app_id":[self safe_string:app.appId],
        @"icon_path":[self safe_string:app.iconImagePath],
        @"installed":@(app.isInstalled)
    };
}
- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(check_recommend_apps_status_with_block){
    [IHOperation checkRecommendAppsStatusWithBlock:^(BOOL isReady, NSArray<IHRecommendApp *> * _Nullable appList) {
        [self make_bool_params:@"is_ready" value:isReady];
        NSMutableArray * array = [[NSMutableArray alloc] init];
        for(IHRecommendApp *app in appList){
            NSDictionary * appinfo = [self get_recommend_app_info:app];
            [array addObject:appinfo];
        }
        [self add_array_params:@"apps" value:array];
        [self call_application:@"check_recommend_apps_status_with_block" params:[self get_params] block:blockID];
    }];
}

// 显示推荐页面
// @param block 点击了哪个app，和下面的api拆开用于在中间插入家长控制
- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_recommend_view_with_selected_block){
    [IHOperation showRecommendViewWithSelectedBlock:^(IHRecommendApp * _Nonnull recommendApp, BOOL isOpen) {
        [self make_bool_params:@"is_open" value:isOpen];
        NSDictionary * appinfo = [self get_recommend_app_info:recommendApp];
        [self add_dic_params:@"app" value:appinfo];
        [self call_application:@"show_recommend_view_with_selected_block" params:[self get_params] block:blockID];
    }];
}

//显示推荐页面，增加了一个hide回调
// @param block 点击了哪个app
// @param hideBlock 回调由于用户主动关闭（不是下面的hide接口）的触发
-(void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_recommend_view_with_selected_and_hide_block){
    [IHOperation showRecommendViewWithSelectedBlock:^(IHRecommendApp * _Nonnull recommendApp, BOOL isOpen) {
        [self make_bool_params:@"open_act" value:YES];
        [self make_bool_params:@"is_open" value:isOpen];
        NSDictionary * appinfo = [self get_recommend_app_info:recommendApp];
        [self add_dic_params:@"app" value:appinfo];
        [self call_application:@"show_recommend_view_with_selected_and_hide_block" params:[self get_params] block:blockID];
    } hideBlock:^{
        [self make_bool_params:@"open_act" value:NO];
        [self call_application:@"show_recommend_view_with_selected_and_hide_block" params:[self get_params] block:blockID];
    }];
}

// 处理点击app事件，打开app或者跳转到appstore
-(void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(handle_selected_app){
    [IHOperation handleSelectedApp];
}

// 关闭推荐页面
-(void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(hide_recommand_view){
    [IHOperation hideRecommendView];
}

#pragma mark-IHSplashProtocol

//显示开屏页面
//@return 是否真正打开了开屏页
-(const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_splash_view_with_dismiss_block){
    BOOL res = [IHOperation showSplashViewWithDismissBlock:^{
        [self make_params];
        [self call_application:@"show_splash_view_with_dismiss_block" params:[self get_params] block:blockID];
    }];
    return [self return_bool:res];
}
/**
 关闭开屏页面（正常情况不需要主动调用此方法关闭），因为以下三种情况下，，开屏页都会自动关闭
 1. 如果用户点击开屏页，且开屏内容可以被处理
 2. 如果用户点击“跳过”
 3. 如果显示时间到了
 */
-(void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(hide_splash_view){
    [IHOperation hideSplashView];
}

/**
 设置从后台进入前台展示开屏图的最小间隔时间（即从进入后台开始计时，直到重新进入前台这段时间差），默认30*60秒
 */
-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_splash_time_interval:(int) time)
{
    [IHOperation setSplashTimeInterval:time];
}




#pragma mark - IHWebViewProtocol



-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(handle_js_call:(NSString*) params){
    [IHOperation handleJsCall:params completion:^(NSString * _Nullable javascriptString) {
        [self make_string_params:@"js" value:javascriptString];
        [self call_application:@"handle_js_call" params:[self get_params] block:blockID];
    }];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(add_webview_with_frame:(CGFloat)x y:(CGFloat)y width:(CGFloat)width height:(CGFloat)height url:(NSString*) url){
    IHWebView * webview = [IHOperation addWebViewWithX:x y:y width:width height:height];
    if(webview != nil){
        [webview loadURLString:url];
        NSString * guid = [NSString stringWithFormat:@"%p",webview];
        [self.webview_cache setObject:webview forKey:guid];
        return [self return_string:guid];
    }
    return nil;
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(hide_web_view:(NSString*) guid){
    if(guid != nil){
        IHWebView * webview = [self.webview_cache objectForKey:guid];
        if(webview != nil){
            [IHOperation hideWebView:webview];
            return [self return_bool:YES];
        }
    }
    return [self return_bool:NO];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(hide_all_web_view){
    for(IHWebView * webview in self.webview_cache.allValues){
         [IHOperation hideWebView:webview];
    }
    [self.webview_cache removeAllObjects];
    
    [IHOperation hideWebViewWithCompletion:nil];
}


/**
 从下往上弹出WebView
 */
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_webview_with_url:(NSString*) url title:(NSString*)title scene:(NSString*) scene){
    [IHOperation showWebViewWithURL:url title:title scene:scene dismissBlock:^{
        [self call_application:@"show_webview_with_url" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_webview_with_url_and_direction:(NSString*) url title:(NSString*)title scene:(NSString*) scene orientaion:(int) orientaion){
    
    [IHOperation showWebViewWithURL:url title:title scene:scene orientation:(IHOrientationType)orientaion dismissBlock:^{
        [self call_application:@"show_webview_with_url_and_direction" params:[self get_params] block:blockID];
    }];
 
    
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(hide_webview_with_completion){
    [IHOperation hideWebViewWithCompletion:^{
        [self make_params];
        [self call_application:@"hide_webview_with_completion" params:[self get_params] block:blockID];
    }];
}

- (NSDictionary *)handleURL:(NSString *)URL
{
    [self make_params];
    [self add_string_params:@"url" value:URL];
    [self call_application:@"handle_url" params:[self get_params] block:@""];
    return nil;
}

- (void)webviewOnClose
{
    [self make_params];
    [self call_application:@"web_view_on_close" params:@"" block:@""];
}

- (void)wantsToLogin
{
    [self make_params];
    [self call_application:@"wants_to_login" params:@"" block:@""];
}

- (void)wantsToLogout
{
    [self call_application:@"wants_to_logout" params:@"" block:@""];
}

#pragma mark - IHBenefitProtocol

//检查某App中是否有福利
- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(check_user_benefit_with_block)
{
    [IHOperation checkUserBenefitWithBlock:^(BOOL exist, IHError * _Nonnull error) {
        [self make_bool_params:@"exist" value:exist];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"check_user_benefit_with_block" params:[self get_params] block:blockID];
    }];
}

//展示福利页面（如果有福利）
- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_benefit_view)
{
    [IHOperation showBenefitView];
}


/**
 显示未登录时福利提醒页面 or  显示福利领取后知道了提醒页面
 */

- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_collect_benefit_view_with_need_login_block){
    [IHOperation showCollectBenefitViewWithNeedLoginBlock:^{
        [self make_bool_params:@"need_login" value:YES];
        [self call_application:@"show_collect_benefit_view_with_need_login_block" params:[self get_params] block:blockID];
    } collectFinishBlock:^(BOOL success, IHCollectBenefitType type) {
        [self make_bool_params:@"need_login" value:NO];
        [self make_bool_params:@"success" value:success];
        [self call_application:@"show_collect_benefit_view_with_need_login_block" params:[self get_params] block:blockID];
    }];
}


//显示福利中心
- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_benefit_center_view)
{
    [IHOperation showBenefitCenterView];
}


// 互推判断是否有其他app的福利信息
- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(check_recommend_user_benefit_with_block){
    [IHOperation checkRecommendUserBenefitWithBlock:^(BOOL exist, IHError * _Nonnull error) {
        [self make_bool_params:@"exist" value:exist];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"check_recommend_user_benefit_with_block" params:[self get_params] block:blockID];
    }];
}

- (void)didClickClollectCodeToShowBenefitCenter {
    [self call_application:@"did_click_clollect_code_to_show_benefitcenter" params:@"" block:@""];
}

- (void)hotStartToShowCollectBenefitView {
    [self call_application:@"hot_start_to_show_collect_benefit_view" params:@"" block:@""];
}


#pragma mark -IHBulletinBoardProtocol

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_bulletin_message_if_possible_with_hide_block){
    bool res = [IHOperation showBulletinMessageIfPossibleWithHideBlock:^{
        [self call_application:@"show_bulletin_message_if_possible_with_hide_block" params:@"" block:blockID];
    }];
    return [self return_bool:res];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(has_new_bulletin_message){
    bool res = [IHOperation showBulletinMessageIfPossibleWithHideBlock:^{
        [self call_application:@"show_bulletin_message_if_possible_with_hide_block" params:@"" block:blockID];
    }];
    return [self return_bool:res];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_bulletin_board_with_hide_block){
    [IHOperation showBulletinBoardWithHideBlock:^{
        [self call_application:@"show_bulletin_board_with_hide_block" params:@"" block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(hide_bulletin_board_with_completion){
    [IHOperation hideBulletinBoardWithCompletion:^{
        [self call_application:@"hide_bulletin_board_with_completion" params:@"" block:blockID];
    }];
}

#pragma mark-IHAutoUpdateProtocol
-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(enable_auto_update:(bool) enabled)
{
    [IHOperation enableAutoUpdate:enabled];
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(config_debug_phone_time_enable:(bool) enabled)
{
    [IHOperation configDebugPhoneTimeEnable:enabled];
}


- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_app_store_comments){
    if (@available(iOS 10.3, *)) {
        if([SKStoreReviewController respondsToSelector:@selector(requestReview)]) {
            [[UIApplication sharedApplication].keyWindow endEditing:YES];
            [SKStoreReviewController requestReview];
        }
    }
}

- (NSDictionary*) bannerInfoToDic:(IHBannerInfo*) info
{
    return @{
        @"banner_id":[self safe_string:info.bannerId],
        @"name":[self safe_string:info.name],
        @"horizontal_resource_path":[self safe_string:info.horizontalResourcePath],
        @"vertical_resource_path":[self safe_string:info.verticalResourcePath],
        @"scheme":[self safe_string:info.scheme]
    };
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(fetch_banners_blocks){
    [IHOperation fetchBannersWithBlock:^(BOOL isReady, NSDictionary<NSString *,NSArray<IHBannerInfo *> *> * _Nullable bannersDictionary) {
        [self make_params];
        [self add_bool_params:@"is_ready" value:isReady];
        if(bannersDictionary != nil){
            NSMutableDictionary * bannerList = [[NSMutableDictionary alloc] init];
            for(NSString * key in bannersDictionary.allKeys){
                NSMutableArray * bannerTypeList = [[NSMutableArray alloc] init];
                NSArray * bannerInfoList = bannersDictionary[key];
                for(IHBannerInfo * info in bannerInfoList)
                {
                    NSDictionary * bannerInfo = [self bannerInfoToDic:info];
                    [bannerTypeList addObject:bannerInfo];
                }
                bannerList[key] = bannerTypeList;
            }
            [self add_dic_params:@"banners" value:bannerList];
        }
        [self call_application:@"fetch_banners_blocks" params:[self get_params] block:blockID];
       
    }];
}

-(bool)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(handle_scheme:(NSString*) scheme scene:(NSString*) scene){
    return [IHOperation handleScheme:scheme scene:scene];
}

@end
