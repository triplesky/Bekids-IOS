//
//  PrivacyPolicyModule.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/9.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "PrivacyPolicyModule.h"

@implementation PrivacyPolicyModule
- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(privacy_view_did_show) name:kIHPrivacyViewDidShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(privacy_view_did_close) name:kIHPrivacyViewDidDismissNotification object:nil];
    }
    return self;
}
//显示新版隐私条款
- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_privacy_policy_if_needed){
    [iHumanSDK showPrivacyPolicyIfNeeded];
}

//显示隐私中心
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_privacy_center_with_user_info:(NSString*) userinfo){
    [iHumanSDK showPrivacyCenterWithUserInfo:userinfo block:^(IHPrivacyCenterType type) {
        [self make_int_params:@"center_type" value:(int)type];
        [self call_application:@"show_privacy_center_with_user_info" params:[self get_params] block:blockID];
    }];
}

//法律条款与隐私中心标题
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(privacy_center_title){
    return [self return_string:[iHumanSDK privacyCenterTitle]];
}

//获取隐私协议地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(privacy_url){
    return [self return_string:[iHumanSDK privacyURL]];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(privacy_url_with_overseas:(BOOL)isOversease){
    return [self return_string:[iHumanSDK privacyURLWithOverseas:isOversease]];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(privacy_url_title){
    return [self return_string:[iHumanSDK privacyURLTitle]];
}

//获取用户协议地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(terms_url){
    return [self return_string:[iHumanSDK termsURL]];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(terms_url_with_overseas:(BOOL)isOversease){
    return [self return_string:[iHumanSDK termsURLWithOverseas:isOversease]];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(terms_url_title){
    return [self return_string:[iHumanSDK termsURLTitle]];
}

//获取儿童隐私保护指引地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(kids_privacy_url){
    return [self return_string:[iHumanSDK kidsPrivacyURL]];
}

//获取第三方收集个人信息地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(third_sdk_privacy_url){
    return [self return_string:[iHumanSDK thirdSDKPrivacyURL]];
}

//获取用户反馈地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(feedback_url_with_extra){
    return [self return_string:[iHumanSDK feedbackURLWithExtra:nil]];
}

//获取家长须知地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(parent_guide_url){
    return [self return_string:[iHumanSDK parentGuideURL]];
}

//获取公司简介地址
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(company_introduction_url){
    return [self return_string:[iHumanSDK companyIntroductionURL]];
}

- (void) privacy_view_did_show
{
    [self call_application:@"privacy_view_did_show" params:@"" block:@""];
}

- (void) privacy_view_did_close
{
    [self call_application:@"privacy_view_did_close" params:@"" block:@""];
}

@end
