//
//  AudioPlayer.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2021/1/23.
//  Copyright © 2021 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MessageHandleBase.h"
NS_ASSUME_NONNULL_BEGIN


@interface AudioPlayer : MessageHandleBase

@end

NS_ASSUME_NONNULL_END
