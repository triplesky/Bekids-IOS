//
//  PurchaseModule.m
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "PurchaseModule.h"
#import "PurchaseManager.h"
#import "UserCenter.h"

@interface PurchaseModule () <IHPaymentProtocol>

@end

@implementation PurchaseModule

- (instancetype)init {
    if (self = [super init]) {
        [IHPurchase addListener:self];
    }
    
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(fetch_product_list) {
    
    [[PurchaseManager sharedInstance] fetchProductList:^(NSArray<ProductListItem *> * _Nonnull products) {
        [self make_params];
        [self add_int_params:@"code" value:0];
        
        NSMutableArray *array = [NSMutableArray array];
        for (ProductListItem *item in products) {
            NSMutableDictionary *obj = [item yy_modelToJSONObject];
            obj[@"ih_product"] = [self product_to_dic:item.ih_product];
            [array addObject:obj];
        }
        
        [self add_array_params:@"product_list" value:array];
        [self call_application:@"fetch_product_list" params:[self get_params] block:blockID];
    } failure:^(NSError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.localizedDescription];
        [self call_application:@"fetch_product_list" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(clear_product_list) {
    [[PurchaseManager sharedInstance] clearProductList];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(purchase_with_product_id:(NSString *)productId) {
    [[PurchaseManager sharedInstance] purchaseWithProductId:productId];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(create_order_and_purchase_with_product_id:(NSString *)productId) {
    [[PurchaseManager sharedInstance] createOrderAndPurchaseWithProductId:productId failure:^(NSError * _Nonnull error) {
        [self make_params];
        [self add_array_params:@"payments" value:@[]];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.localizedDescription];
        [self call_application:@"payments_failed" params:[self get_params] block:@""];
    }];
}

// 仅用于判断游客权益
- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(has_visitor_rights:(NSString *)userRightsType) {
    return [self return_bool:[[PurchaseManager sharedInstance] hasVisitorRights:userRightsType]];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(restore_purchase){
    [[PurchaseManager sharedInstance] restore];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(product_info_for_user_rights_type:(NSString *)userRightsType) {
    return [self return_object:[[PurchaseManager sharedInstance] productInfoForUserRightsType:userRightsType]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(product_price_with_rate:(float)rate productId:(NSString *)productId) {
    return [self return_string:[[PurchaseManager sharedInstance] productPriceWithRate:rate productId:productId]];
}

#pragma mark - callback
- (void)paymentsSucceed:(NSArray<IHPayment *> *)payments {
    
    // 游客购买，直接发送用户信息更新通知
//    [[NSNotificationCenter defaultCenter] postNotificationName:UserCenterUserInfoUpdateNotification object:nil];
    
    [[UserCenter sharedInstance] refreshUserInfoWithSuccess:nil failure:nil];
    
    [self make_params];
    
    NSMutableArray *array = [NSMutableArray array];
    for (IHPayment *payment in payments) {
        [array addObject:[payment paymentInfo]];
    }
    
    [self add_array_params:@"payments" value:array];
    [self call_application:@"payments_succeed" params:[self get_params] block:@""];
}

- (void)paymentsFailed:(NSArray<IHPayment *> *)payments error:(IHError *)error {
    [self make_params];
    
    NSMutableArray *array = [NSMutableArray array];
    for (IHPayment *payment in payments) {
        [array addObject:[payment paymentInfo]];
    }
    
    [self add_array_params:@"payments" value:array];
    [self add_int_params:@"code" value:(int)error.code];
    [self add_string_params:@"message" value:error.message];
    [self call_application:@"payments_failed" params:[self get_params] block:@""];
}

- (void)legacyPaymentSucceed:(IHLegacyPayment *)payment {
    [self make_params];
    [self add_dic_params:@"payment" value:[self legacy_payment_to_dic:payment]];
    [self call_application:@"legacy_payment_succeed" params:[self get_params] block:@""];
}

- (void)legacyPaymentFailed:(IHLegacyPayment *)payment error:(IHError *)error {
    [self make_params];
    [self add_dic_params:@"payment" value:[self legacy_payment_to_dic:payment]];
    [self add_int_params:@"code" value:(int)error.code];
    [self add_string_params:@"message" value:error.message];
    [self call_application:@"legacy_payment_failed" params:[self get_params] block:@""];
}

- (void)wantsToPurchasePromotedPayment:(IHPayment *)payment {
    
    [[PurchaseManager sharedInstance] wantsToPurchasePromotedPayment:payment];
    
    [self make_params];
    [self add_dic_params:@"payment" value:[payment paymentInfo]];
    [self call_application:@"wants_to_purchase_promoted_payment" params:[self get_params] block:@""];
}

#pragma mark -

- (NSDictionary*)product_to_dic:(IHProduct*)product
{
    return @{
        @"productId":[self safe_string:product.productId],
        @"title":[self safe_string:product.title],
        @"introduction":[self safe_string:product.introduction],
        @"subscriptionPeriodUnit":@(product.subscriptionPeriodUnit),
        @"subscriptionNumberOfUnits":@(product.subscriptionNumberOfUnits),
        @"priceInCent":@(product.priceInCent),
        @"priceString":[self safe_string:product.priceString],
        @"discountType":@(product.discountType),
        @"discountNumberOfPeriods":@(product.discountNumberOfPeriods),
        @"discountPeriodUnit":@(product.discountPeriodUnit),
        @"discountPriceInCent":@(product.discountPriceInCent),
        @"discountPriceString":[self safe_string:product.discountPriceString],
        @"region":[self safe_string:product.region],
        @"currency":[self safe_string:product.currency],
    };
}

- (NSDictionary *) legacy_payment_to_dic:(IHLegacyPayment*) payment
{
    
    return @{
        @"productId":[self safe_string:payment.productId],
        @"productName":[self safe_string:payment.productName],
        @"productDescription":[self safe_string:payment.productDescription],
        @"priceInCent":@(payment.priceInCent),
        @"quantity":@(payment.quantity),
        @"status":@(payment.status),
//        @"useEcom":@(payment.useEcom),
        @"appOrderId":[self safe_string:payment.appOrderId],
        @"appOrderTime":@(payment.appOrderTime),
        @"amount":@(payment.amount),
        @"errorDescription":[self safe_string:payment.errorDescription]
    };
}

#pragma mark - base sdk

// 建议region，会根据返回的SKProduct实时变化
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(suggested_region){
    return [self return_string:[IHPurchase suggestedRegion]];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_products_with_ids:(NSArray*) ids)
{
    [IHPurchase fetchProductsWithIds:ids block:^(NSArray<IHProduct *> * _Nullable validProducts, NSArray<NSString *> * _Nullable invalidProductIds, IHError * _Nonnull error) {
        [self make_params];
        NSMutableArray * products = [[NSMutableArray alloc] init];
        for(IHProduct * duct in validProducts){
            [products addObject:[self product_to_dic:duct]];
        }
        [self add_array_params:@"valid" value:products];
        [self add_array_params:@"invalid" value:invalidProductIds];
        [self call_application:@"fetch_products_with_ids" params:[self get_params] block:blockID];
    }];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(purchase_with_payment:(NSString*) product_id quantity:(int) quantity uid:(NSString*) uid){
    IHPayment * payment = [IHPayment paymentWithProductId:product_id quantity:quantity];
    [IHPurchase purchaseWithPayment:payment uid:uid];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(purchase_with_legacy_payment:(NSString*) product_id quantity:(int) quantity){
    IHLegacyPayment * payment = [[IHLegacyPayment alloc] init];
    payment.productId = product_id;
    payment.quantity = quantity;
    [IHPurchase purchaseWithLegacyPayment:payment];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(purchase_with_legacy_payment_showtip:(NSString*) product_id quantity:(int) quantity showTip:(BOOL)showTip){
    IHLegacyPayment * payment = [[IHLegacyPayment alloc] init];
    payment.productId = product_id;
    payment.quantity = quantity;
    [IHPurchase purchaseWithLegacyPayment:payment showTip:showTip];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(purchase_with_legacy_h5_payment:(NSString*) product_id quantity:(int) quantity showTip:(BOOL)showTip){
    IHLegacyPayment * payment = [[IHLegacyPayment alloc] init];
    payment.productId = product_id;
    payment.quantity = quantity;
    [IHPurchase purchaseWithLegacyH5Payment:payment];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(cancel_promoted_payment:(NSString*) product_id quantity:(int) quantity){
    IHPayment * payment = [IHPayment paymentWithProductId:product_id quantity:quantity];
    [IHPurchase cancelPromotedPayment:payment];
}

- (NSDictionary *) purchased_product_to_dic:(IHPurchasedProduct*) product
{
    return @{
        @"productId":[self safe_string:product.productId],
        @"purchasedStatus":@(product.purchasedStatus),
        @"expireTime":@(product.expireTime),
        @"purchaseTime":@(product.purchaseTime),
        @"expireIntent":@(product.expireIntent)
    };
}
- (const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(purchased_product_with_id:(NSString*) product_id ){
    return [self return_object:[self purchased_product_to_dic: [IHPurchase purchasedProductWithId:product_id]]];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(all_purchased_products){
    NSArray * products = [IHPurchase allPurchasedProducts];
    NSMutableArray * all_products = [[NSMutableArray alloc] init];
    for(IHPurchasedProduct * product in products){
        [all_products addObject:[self purchased_product_to_dic:product]];
    }
    return [self return_array:all_products];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(clear_iap_cache){
    [IHPurchase clearIAPCache];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(store_region){
    return [self return_string:[IHPurchase storeRegion]];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_should_finish_all_iaps:(BOOL) bl){
    [IHPurchase setShouldFinishAllIAPs:bl];
}

@end
