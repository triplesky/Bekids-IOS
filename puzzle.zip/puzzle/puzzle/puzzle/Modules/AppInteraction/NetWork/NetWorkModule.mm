//
//  NetWorkModule.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/10/20.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "NetWorkModule.h"
#import "ClientUtils.h"
#import <iHumanSDK/iHumanSDK.h>
#import <Bugly/Bugly.h>
#import "AppConfigs.h"
#import <AVFoundation/AVFoundation.h>
#import "Network.h"
#import "API.h"

@interface NetWorkModule()
@property (nonatomic,strong) NSTimer * timer;
@property (nonatomic,assign) IHNetworkStatus currentstate;
@end

@implementation NetWorkModule

- (instancetype) init
{
    self = [super init];
    if (self) {
        [IHNetwork addDownloadListener:self];
        [IHNetwork setCocurrentDownloadTaskCount:3];
        [IHNetwork clearAllDownloadTasks];
        [IHNetwork setUseHTTPDNS:YES];
        self.currentstate = [IHNetwork currentNetworkStatus];
        [self initTimer];
    }
    return self;
}

- (void) initTimer{
    if (self.timer == nil) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(update) userInfo:nil repeats:YES];
        [self.timer fireDate];
    }
}

- (void) update
{
//     NSLog(@"AVAudioSession:%@",[[AVAudioSession sharedInstance] category]);
    if (self.currentstate != [IHNetwork currentNetworkStatus]) {
        [self make_params];
        [self add_int_params:@"status" value:(int)[IHNetwork currentNetworkStatus]];
        [self call_application:@"net_work_status_changed" params:[self get_params] block:@""];
    }
    self.currentstate =[IHNetwork currentNetworkStatus];
    if ([UIApplication sharedApplication].idleTimerDisabled == NO) {
        [UIApplication sharedApplication].idleTimerDisabled = YES;
    }
}


- (NSDictionary*) download_task_to_dic:(IHDownloadTask*) task
{
    if (task == nil) {
        return nil;
    }
    return @{
        @"url":[self safe_string:task.URL],
        @"allow_cellular":@(task.allowCellular),
        @"status":@(task.status),
        @"background":@(task.inBackground),
        @"download_bytes":@(task.downloadBytes),
        @"total_bytes":@(task.totalBytes),
        @"speed":@(task.speed),
        @"avg_speed":@(task.avgSpeed)
    };
}

#pragma mark-IHNetworkProtocol

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_current_download_task_count:(int) c){
    [IHNetwork setCocurrentDownloadTaskCount:c];
}

// 设置是否使用HTTPDNS，默认值为NO
- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_use_http_dns:(bool) b){
    [IHNetwork setUseHTTPDNS:b];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(download_task_for_url:(NSString*) url){
    return [self return_object:[self download_task_to_dic:[IHNetwork downloadTaskForURL:url]]];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(add_download_task_for_url:(NSString *)URLString inBackground:(BOOL)inBackground onPriority:(BOOL)onPriority){
   [IHNetwork addDownloadTaskForURL:URLString inBackground:inBackground onPriority:onPriority];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(add_download_task_for_url_resumable:(NSString *)URLString inBackground:(BOOL)inBackground onPriority:(BOOL)onPriority resumable:(BOOL)resumable){
    [IHNetwork addDownloadTaskForURL:URLString inBackground:inBackground onPriority:onPriority resumable:resumable];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(resume_download_task_for_url:(NSString*) url){
    [IHNetwork resumeDownloadTaskForURL:url];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(resume_all_download_tasks){
    [IHNetwork resumeAllDownloadTasks];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(pause_download_task_for_url:(NSString*) url){
    [IHNetwork pauseDownloadTaskForURL:url];
}
- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(pause_all_download_tasks){
    [IHNetwork pauseAllDownloadTasks];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(clear_download_task_for_url:(NSString*) url){
    [IHNetwork clearDownloadTaskForURL:url];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(clear_all_download_tasks){
    [IHNetwork clearAllDownloadTasks];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(download_image:(NSString*) url){
    [IHNetwork downloadImage:url withBlock:^(NSString * _Nullable filePath, IHError * _Nonnull error) {
        [self make_string_params:@"filePath" value:filePath];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"download_image" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(download_resource:(NSString *)URLString toDestinationPath:(NSString *)destinationPath){
    [IHNetwork downloadResource:URLString toDestinationPath:destinationPath completion:^(IHError * _Nonnull error) {
        [self make_string_params:@"filePath" value:destinationPath];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"download_image" params:[self get_params] block:blockID];
    }];
}


- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_api_with_url_phmsf:(NSString *)URLString
                                         parameters:(nullable NSDictionary *)parameters
                                         headers:(nullable NSDictionary<NSString *, NSString *> *)headers
                                         method:(NSString *)method){
    [IHNetwork fetchAPIWithURL:URLString parameters:parameters headers:headers method:method success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject, NSString * _Nonnull responseString) {
        [self make_string_params:@"url" value:URLString];
        [self add_int_params:@"code" value:0];
        [self add_dic_params:@"data" value:responseObject];
        [self call_application:@"fetch_api_with_url_phmsf" params:[self get_params] block:blockID];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [self make_string_params:@"url" value:URLString];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:[error description]];
        [self call_application:@"fetch_api_with_url_phmsf" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_api_with_url_pmsf:(NSString *)URLString
                                         parameters:(nullable NSDictionary *)parameters
                                         method:(NSString *)method){
    [IHNetwork fetchAPIWithURL:URLString parameters:parameters method:method success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject, NSString * _Nonnull responseString) {
        [self make_string_params:@"url" value:URLString];
        [self add_int_params:@"code" value:0];
        [self add_dic_params:@"data" value:responseObject];
        [self call_application:@"fetch_api_with_url_pmsf" params:[self get_params] block:blockID];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [self make_string_params:@"url" value:URLString];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:[error description]];
        [self call_application:@"fetch_api_with_url_pmsf" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_api_with_url_som:(NSString *)URLString
                                         signedParameters:(nullable NSDictionary *)signedParameters
                                         optionalParameters:(nullable NSDictionary *)optionalParameters
                                         method:(NSString *)method){
    [IHNetwork fetchAPIWithURL:URLString signedParameters:signedParameters optionalParameters:optionalParameters method:method success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject, NSString * _Nonnull responseString) {
        [self make_string_params:@"url" value:URLString];
        [self add_int_params:@"code" value:0];
        [self add_dic_params:@"data" value:responseObject];
        [self call_application:@"fetch_api_with_url_som" params:[self get_params] block:blockID];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [self make_string_params:@"url" value:URLString];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:[error description]];
        [self call_application:@"fetch_api_with_url_som" params:[self get_params] block:blockID];
    }];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(get_api:(NSString *)api
                                         params:(nullable NSDictionary *)params
                                         verify_response:(BOOL)verify_response
                                         cache_policy:(int)cache_policy
                                         ) {
    NetworkCachePolicy cachePolicy = (NetworkCachePolicy)cache_policy;
    NSURLSessionTask *task = [API getApi:api params:params responseModelClass:nil cachePolicy:cachePolicy verifyResponse:verify_response processModelBlock:nil success:^(id  _Nullable model, NSDictionary * _Nonnull responseObject) {
        [self make_params];
        [self add_int_params:@"code" value:0];
        [self add_dic_params:@"data" value:responseObject];
        [self call_application:@"get_api" params:[self get_params] block:blockID];
    } failure:^(NSError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.localizedDescription];
        [self add_string_params:@"domain" value:error.domain];
        [self call_application:@"get_api" params:[self get_params] block:blockID];
    }];
    
    return [self return_number:task.taskIdentifier];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(post_api:(NSString *)api
                                         params:(nullable NSDictionary *)params
                                         verify_response:(BOOL)verify_response
                                         cache_policy:(int)cache_policy
                                         ) {
    
    NetworkCachePolicy cachePolicy = (NetworkCachePolicy)cache_policy;
    NSURLSessionTask *task = [API postApi:api params:params responseModelClass:nil cachePolicy:cachePolicy verifyResponse:verify_response processModelBlock:nil success:^(id  _Nullable model, NSDictionary * _Nonnull responseObject) {
        [self make_params];
        [self add_int_params:@"code" value:0];
        [self add_dic_params:@"data" value:responseObject];
        [self call_application:@"post_api" params:[self get_params] block:blockID];
    } failure:^(NSError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.localizedDescription];
        [self add_string_params:@"domain" value:error.domain];
        [self call_application:@"post_api" params:[self get_params] block:blockID];
    }];
    
    return [self return_number:task.taskIdentifier];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(cancel_api_with_task_id:(NSUInteger)taskId) {
    [NetworkShare cancelWithTaskId:taskId];
}

- (NSString*) printParamOriginString:(NSDictionary *) params
{
    if (params.count == 0) {
        return @"";
    }
    
    NSArray *keys = [[params allKeys] sortedArrayUsingSelector:@selector(localizedCompare:)];
    
    NSMutableString *srcString = [NSMutableString string];
    for (NSString *key in keys) {
        [srcString appendFormat:@"%@=%@&", key, params[key]];
    }
    
    if (srcString.length) {
        [srcString deleteCharactersInRange:NSMakeRange(srcString.length - 1, 1)];
    }
    return srcString;
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_api_with_url_sohm:(NSString *)URLString
                                         signedParameters:(nullable NSDictionary *)signedParameters
                                         optionalParameters:(nullable NSDictionary *)optionalParameters
                                         headers:(nullable NSDictionary<NSString *, NSString *> *)headers
                                         method:(NSString *)method){
    [IHNetwork fetchAPIWithURL:URLString signedParameters:signedParameters optionalParameters:optionalParameters headers:headers method:method success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject, NSString * _Nonnull responseString) {
        DLog(@"fetch_api_with_url_sohm url:%@  result:%@",URLString,responseString)
            [self make_string_params:@"url" value:@"URLString"];
            [self add_int_params:@"code" value:0];
            [self add_dic_params:@"data" value:responseObject];
            [self call_application:@"fetch_api_with_url_sohm" params:[self get_params] block:blockID];

    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        DLog(@"fetch_api_with_url_sohm url:%@  result:%@",URLString,error);
        [self make_string_params:@"url" value:@"URLString"];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:[error description]];
        [self call_application:@"fetch_api_with_url_sohm" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(upload_audio_file:(NSString *)filepath){
    [IHNetwork uploadAudioFile:[NSData dataWithContentsOfFile:filepath] completionBlock:^(NSString * _Nullable fileId, IHError * _Nonnull error) {
        [self make_string_params:@"filepath" value:filepath];
        [self add_string_params:@"fileId" value:fileId];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"download_image" params:[self get_params] block:blockID];
    }];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(current_network_status){
    return [self return_number:[IHNetwork currentNetworkStatus]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(current_wwan_type){
    return [self return_number:[IHNetwork currentWWANType]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(previous_network_status){
    return [self return_number:[IHNetwork previousNetworkStatus]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(previous_wwan_type){
    return [self return_number:[IHNetwork previousWWANType]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(network_error_status){
    return [self return_number:[IHNetwork networkErrorStatus]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(user_agent){
    return [self return_string:[IHNetwork userAgent]];
}

- (void)taskUpdated:(nonnull IHDownloadTask *)task path:(nullable NSString *)path error:(nonnull IHError *)error {
    IHDownloadStatus state = task.status;
    dispatch_async(dispatch_get_main_queue(), ^{
         DLog(@"url:%@,status:%d, bytes:%d,total:%d,error:%d,msg:%@",task.URL,state,task.downloadBytes,task.totalBytes,error.code,error.message);
        switch (state) {
            case IHDownloadStatusFinished:
            {
                if (error.code == IHErrorCodeOK && path.length >0) {
                    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) {
//                        [self reportDownloadError:@"下载失败,文件不存在" info:[NSString stringWithFormat:@"code:%zd path:%@",error.code,path] url:task.URL];
                        [self report_download_task:task.URL status:IHDownloadStatusFailed current:(int)task.downloadBytes total:(int)task.totalBytes error:(int)error.code errormsg:path];
                    }else{
                        [self report_download_task:task.URL status:IHDownloadStatusFinished current:(int)task.downloadBytes total:(int)task.totalBytes error:(int)error.code errormsg:path];
                    }
                    
                }else{
                   // DLog(@"url:%@,status:%d, bytes:%d,total:%d,error:%d,msg:%@",task.URL,state,task.downloadBytes,task.totalBytes,error.code,error.message);
                    [self reportDownloadError:@"下载失败,文件路径为空" info:[NSString stringWithFormat:@"code:%zd path:%@",error.code,path] url:task.URL];
                    [self report_download_task:task.URL status:IHDownloadStatusFailed current:(int)task.downloadBytes total:(int)task.totalBytes error:(int)error.code errormsg:error.message];
                }
                break;
            }
            default:
              //  DLog(@"url:%@,status:%d, bytes:%d,total:%d,error:%d,msg:%@",task.URL,state,task.downloadBytes,task.totalBytes,error.code,error.message);
                if (state == IHDownloadStatusCleared && error.code != IHErrorCodeOK) {
                    if(state != IHDownloadStatusCleared){
                       [self reportDownloadError:@"下载失败" info:[NSString stringWithFormat:@"code:%zd status:%zd message:%@",error.code,state,error.message] url:task.URL];
                    }
                    [self report_download_task:task.URL status:IHDownloadStatusFailed current:(int)task.downloadBytes total:(int)task.totalBytes error:(int)error.code errormsg:error.message];
                } else if(state == IHDownloadStatusFailed){
                    [self reportDownloadError:@"下载失败" info:[NSString stringWithFormat:@"code:%zd status:%zd message:%@",error.code,state,error.message] url:task.URL];
                     [self report_download_task:task.URL status:(int)state current:(int)task.downloadBytes total:(int)task.totalBytes error:(int)error.code errormsg:error.message];
                }else{
                     [self report_download_task:task.URL status:(int)state current:(int)task.downloadBytes total:(int)task.totalBytes error:(int)error.code errormsg:error.message];
                }
               
                break;
        }
    });
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_net_diagnose_view_with_config:(NSDictionary *)config){
    IHNetDiagnoseConfig * netConfig = [[IHNetDiagnoseConfig alloc] init];
    netConfig.apiURL = [self safe_string:config[@"api_url"]];
    netConfig.cdnURL = [self safe_string:config[@"cdn_url"]];
    netConfig.cdnMd5 = [self safe_string:config[@"cdn_md5"]];
    netConfig.cosURL = [self safe_string:config[@"cos_url"]];
    netConfig.cosMd5 = [self safe_string:config[@"cos_md5"]];
    [IHNetwork showNetDiagnoseViewWithConfig:netConfig hideBlock:^{
        [self make_params];
        [self call_application:@"net_diagnose_view_did_close" params:[self get_params] block:blockID];
    }];
}
@end
