//
//  NetWorkModule.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/10/20.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MessageHandleBase.h"
#import <iHumanSDK/iHumanSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface NetWorkModule : MessageHandleBase<IHDownloadProtocol>

@end

NS_ASSUME_NONNULL_END
