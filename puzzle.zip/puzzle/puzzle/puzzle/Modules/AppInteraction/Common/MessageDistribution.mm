//
//  MessageDistribution.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/8.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "MessageDistribution.h"
#import "MessageHandleBase.h"
#import "BuglyModule.h"
#import "NetWorkModule.h"
#import "LoginModule.h"
#import "PurchaseModule.h"
#import "DataReportModule.h"
#import "ClientUtils.h"
#import "CommonInfoModule.h"
#import "PrivacyPolicyModule.h"
#import "OperationalModule.h"
#import "FileOperationModule.h"
#import "AudioPlayer.h"
#import <AVFoundation/AVFoundation.h>

@interface MessageDistribution()
@property (nonatomic,strong) NSMutableArray<MessageHandleBase*>* avaliableHandles;
@property (nonatomic,strong) BuglyModule* buglyModule;
@end

@implementation MessageDistribution

- (instancetype)init
{
    self = [super init];
    if (self) {
        TIME_CHECK(@"开始检测反射注册",@"反射注册结束",
                   self.avaliableHandles = [[NSMutableArray<MessageHandleBase*> alloc] init];
                   self.buglyModule = [[BuglyModule alloc] init];
                   
                   [self.avaliableHandles addObject:[[AudioPlayer alloc] init]];
                   [self.avaliableHandles addObject:[[NetWorkModule alloc] init]];
                   [self.avaliableHandles addObject:[[LoginModule alloc] init]];
                   [self.avaliableHandles addObject:[[CommonInfoModule alloc] init]];
                   [self.avaliableHandles addObject:[[PurchaseModule alloc] init]];
                   [self.avaliableHandles addObject:[[PrivacyPolicyModule alloc] init]];
                   [self.avaliableHandles addObject:[[OperationalModule alloc] init]];
                   [self.avaliableHandles addObject:[[FileOperationModule alloc] init]];
                   [self.avaliableHandles addObject:[[DataReportModule alloc] init]];
                   
                   );
    }
    return self;
}

- (void) initBugly
{
    [self.buglyModule initBugly];
}

- (const char*) on_message:(NSString*) message params:(NSString *) params block:(NSString*) blockID
{
   // NSLog(@"on_message begin:%@ %@",message,params,[[AVAudioSession sharedInstance] category]);
    if ([self.buglyModule respondsMessage:message]) {
        [self.buglyModule quick_respone_message:message info:params];
    }else{
        for (MessageHandleBase * handle in self.avaliableHandles) {
            if([handle respondsMessage:message]){
                return [handle processMessage:message params:[ClientUtils convertToArray:params] block:blockID];
            }
        }
        DLog(@"无法处理的消息: %@ params:%@",message,params);
    }
    return nil;
}


- (void)application_report_log:(NSString *)message {
    [BuglyModule buglyLog:message];
}

- (void) app_enter_background
{
    for (MessageHandleBase * handle in self.avaliableHandles) {
        [handle app_enter_background];
    }
}
- (void) app_enter_forgeground
{
    for (MessageHandleBase * handle in self.avaliableHandles) {
        [handle app_enter_forgeground];
    }
}

@end
