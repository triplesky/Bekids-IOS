//
//  MessageHandleBase.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/8.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "MessageHandleBase.h"
#import "MessageInvocation.h"
#import <UnityFramework/NativeCommunicater.h>
#import <objc/runtime.h>
#import "ClientUtils.h"
#import "ReadingAlertController.h"
#import "AppConfigs.h"
#import "AppDelegate.h"
#import <Bugly/Bugly.h>


@interface MessageHandleBase()
@property (nonatomic,strong) NSMutableDictionary* avaliableInvocations;
@property (nonatomic,strong) NSMutableDictionary* paramMaker;
@property (nonatomic,strong) NSMutableDictionary* returnValue;
@end

@implementation MessageHandleBase
- (instancetype)init{
    self = [super init];
    if(self){
        self.avaliableInvocations = [[NSMutableDictionary alloc] init];
        self.paramMaker = [[NSMutableDictionary alloc] init];
        self.returnValue = [[NSMutableDictionary alloc] init];
        [self auto_regist_message];
    }
    return self;
}

- (void) auto_regist_message
{
    unsigned int methCount = 0;
    Method *meths = class_copyMethodList([self class], &methCount);
    for(int i = 0; i < methCount; i++) {
        Method meth = meths[i];
        SEL sel = method_getName(meth);
        const char *name = sel_getName(sel);
        NSString * funcname = [NSString stringWithUTF8String:name];
        if ([funcname containsString:@"call_native_"] ) {
            NSString * messagename = [funcname componentsSeparatedByString:@":"].firstObject;
            messagename = [messagename stringByReplacingOccurrencesOfString:@"call_native_" withString:@""];
            [self regist_invocation:messagename sel:sel];
        }
    }
    free(meths);
}

- (void) regist_invocation:(NSString *) message sel:(SEL) selector
{
    MessageInvocation * invocation = [[MessageInvocation alloc] initWithObject:self sel:selector];
    if (invocation != nil) {
        [self.avaliableInvocations setObject:invocation forKey:message];
    }else{
        DLog(@"注册消息失败:%@",message);
    }
}

- (BOOL) respondsMessage:(NSString *) message
{
    if (self.avaliableInvocations[message] != nil) {
        return YES;
    }
    return NO;
}

- (const char *) processMessage:(NSString *) message params:(NSArray *) params block:(NSString *) block
{
    MessageInvocation * invocation = self.avaliableInvocations[message];
    if (invocation) {
        return [invocation invocation:params block:block];
    }else{
        DLog(@"不存在这个消息的处理函数:%@",message);
    }
    return nil;
}

- (void) call_application:(NSString *) message params:(NSString *) jsonStr block:(NSString *) block_id
{
    if (block_id == nil || block_id.length == 0) {
         [[NativeCommunicater sharedInstance] call_application:message params:jsonStr];
    }else{
        [[NativeCommunicater sharedInstance] call_application_with_block:block_id params:jsonStr];
    }
}

- (void) report_download_task:(NSString*) url status:(int) status current:(int) bytes total:(int)total_bytes error:(int) ercode errormsg:(NSString*) errormsg
{
//    [self make_params];
//    [self add_string_params:@"url" value:url];
//    [self add_int_params:@"status" value:status];
//    [self add_int_params:@"bytes" value:bytes];
//    [self add_int_params:@"total_bytes" value:total_bytes];
//    [self add_int_params:@"ercode" value:ercode];
//    [self add_string_params:@"errormsg" value:errormsg];
//    [self call_application:@"report_download_task" params:[self get_params] block:@""];
    [[NativeCommunicater sharedInstance] report_download_task:url status:status current:bytes total:total_bytes error:ercode errormsg:errormsg];
}

- (void) make_params
{
    [self.paramMaker removeAllObjects];
}

- (void) make_int_params:(NSString *) key value:(int) v
{
    [self make_params];
    [self.paramMaker setObject:@(v) forKey:key];
}

- (void) add_int_params:(NSString *) key value:(int) v
{
    [self.paramMaker setObject:@(v) forKey:key];
}

- (void) make_bool_params:(NSString *) key value:(bool) v
{
    [self make_params];
    [self.paramMaker setObject:@(v) forKey:key];
}

- (void) add_bool_params:(NSString *) key value:(bool) v
{
    [self.paramMaker setObject:@(v) forKey:key];
}

- (void) make_string_params:(NSString *) key value:(NSString *) v
{
    [self make_params];
    [self add_string_params:key value:v];
}

- (void) add_string_params:(NSString *) key value:(NSString *) v
{
    if(v == nil){
        v = @"";
    }
    [self.paramMaker setObject:v forKey:key];
}

- (void) make_float_params:(NSString *) key value:(float) v
{
    [self make_params];
    [self.paramMaker setObject:@(v) forKey:key];
}

- (void) add_float_params:(NSString *) key value:(float) v
{
    [self.paramMaker setObject:@(v) forKey:key];
}

- (void) add_dic_params:(NSString*)key value:(NSDictionary*) v
{
    if (v == nil) {
        [self.paramMaker setObject:@{} forKey:key];
    }else{
        [self.paramMaker setObject:v forKey:key];
    }
    
}

- (void) add_array_params:(NSString*)key value:(NSArray*) v
{
    if (v == nil) {
        [self.paramMaker setObject:@[] forKey:key];
    }else{
        [self.paramMaker setObject:v forKey:key];
    }
    
}

- (NSString *) get_params
{
    NSString* res = [ClientUtils convertToString:self.paramMaker];
    [self make_params];
    return res;
}

- (char*) translate_string_for_unity:(NSString *) s
{
    if (s == nil || s.length == 0) {
        return nil;
    }
    const char* utf8 = s.UTF8String;
    size_t len = strlen(utf8);
    
    char *res = (char*)malloc(len+1);
    strcpy(res, utf8);
    return res;
}

- (NSString *) safe_string:(NSString *) row
{
    if(row == nil){
        return @"";
    }
    return row;
}

- (const char*) return_void
{
    return nil;
}
- (const char*) return_string:(NSString*) str
{
    [self.returnValue removeAllObjects];
    [self.returnValue setObject:str ? : @"" forKey:@"value"];
    [self.returnValue setObject:@"s" forKey:@"type"];
     return [self translate_string_for_unity:[ClientUtils convertToString:self.returnValue]];
}
- (const char*) return_number:(double) num
{
    [self.returnValue removeAllObjects];
    [self.returnValue setObject:@(num) forKey:@"value"];
    [self.returnValue setObject:@"num" forKey:@"type"];
     return [self translate_string_for_unity:[ClientUtils convertToString:self.returnValue]];
}
- (const char*) return_bool:(bool) bl
{
    [self.returnValue removeAllObjects];
    [self.returnValue setObject:@(bl) forKey:@"value"];
    [self.returnValue setObject:@"bool" forKey:@"type"];
     return [self translate_string_for_unity:[ClientUtils convertToString:self.returnValue]];
}

- (const char*) return_object:(NSDictionary*) obj
{
    [self.returnValue removeAllObjects];
    [self.returnValue setObject:obj ? : @{} forKey:@"value"];
    [self.returnValue setObject:@"obj" forKey:@"type"];
    return [self translate_string_for_unity:[ClientUtils convertToString:self.returnValue]];
}
- (const char*) return_array:(NSArray*) obj
{
    [self.returnValue removeAllObjects];
    [self.returnValue setObject:obj ? : @[] forKey:@"value"];
    [self.returnValue setObject:@"obj" forKey:@"type"];
    return [self translate_string_for_unity:[ClientUtils convertToString:self.returnValue]];
}

- (void)ShowAlert:(NSString *) title content:(NSString*) content
{
    AppConfigs* config = [AppConfigs sharedInstance];
    if (config.enviroment == AppEnviroment_Production) {
        return;
    }
    UIViewController * keyVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    if ( keyVC!= nil) {
        ReadingAlertController * alertC = [ReadingAlertController alertControllerWithTitle:title message:content preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSLog(@"确定");
        }];
        [alertC addAction:okAction];
        [keyVC presentViewController:alertC animated:YES completion:nil];
        alertC.popoverPresentationController.sourceView = keyVC.view;
        alertC.popoverPresentationController.sourceRect = keyVC.view.bounds;
    }
}

- (void) reportDownloadError:(NSString *) title info:(NSString *) errorInfo url:(NSString *) url
{
    NSString * info = [NSString stringWithFormat:@"url:%@ msg:%@",url,errorInfo];
    NSException * exception = [NSException exceptionWithName:title reason:info userInfo:nil];
    [Bugly reportException:exception];
}

-(bool) isPad
{
    return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad;
}

- (void) logAction:(NSString*) event attr:(NSDictionary*) info
{
    if(info == nil){
        info = @{};
    }
    [iHumanSDK logAction:event attributes:info];
}

- (void) app_enter_background
{
    
}
- (void) app_enter_forgeground
{
    
}
@end
