//
//  MessageDistribution.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/8.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UnityFramework/NativeCommunicater.h>
NS_ASSUME_NONNULL_BEGIN

@interface MessageDistribution : NSObject<NativeCommunicaterProtocol>
- (void) initBugly;
- (void) app_enter_background;
- (void) app_enter_forgeground;
@end

NS_ASSUME_NONNULL_END
