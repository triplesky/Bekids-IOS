//
//  MessageInvocation.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/8.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MessageInvocation : NSObject
- (instancetype) initWithObject:(NSObject*) target sel:(SEL) selector;
- (instancetype) initWithObject:(NSObject*) target selector:(NSString *) selectorname;
- (const char*) invocation:(NSArray *) params block:(NSString *) blockID;
@end

NS_ASSUME_NONNULL_END
