//
//  MessageInvocation.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/8.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "MessageInvocation.h"
#import <QXUtilityKit/QXLogger.h>

@interface MessageInvocationParam : NSObject
- (void) set_param:(int) index from:(NSArray *) params to:(NSInvocation*) invocation;
@end

@implementation MessageInvocationParam
- (void) set_param:(int) index from:(NSArray *) params to:(NSInvocation*) invocation
{
    
}
@end

@interface MessageInvocationParamObject : MessageInvocationParam


@end

@implementation MessageInvocationParamObject
- (void) set_param:(int) index from:(NSArray *) params to:(NSInvocation*) invocation
{
    NSObject * param = nil;
    if (params.count > index) {
        param = [params objectAtIndex:index];
    }
    [invocation setArgument:&param atIndex:index+2];
}
@end

@interface MessageInvocationParamInt : MessageInvocationParam

@end

@implementation MessageInvocationParamInt
- (void) set_param:(int) index from:(NSArray *) params to:(NSInvocation*) invocation
{
    int  param = 0;
    if (params.count > index) {
        param = [[params objectAtIndex:index] intValue];
    }
    [invocation setArgument:&param atIndex:index+2];
}
@end

@interface MessageInvocationParamFloat : MessageInvocationParam

@end

@implementation MessageInvocationParamFloat
- (void) set_param:(int) index from:(NSArray *) params to:(NSInvocation*) invocation
{
    float  param = 0;
    if (params.count > index) {
        param = [[params objectAtIndex:index] floatValue];
    }
    [invocation setArgument:&param atIndex:index+2];
}
@end

@interface MessageInvocationParamBool : MessageInvocationParam

@end

@implementation MessageInvocationParamBool
- (void) set_param:(int) index from:(NSArray *) params to:(NSInvocation*) invocation
{
    bool  param = NO;
    if (params.count > index) {
        param = [[params objectAtIndex:index] boolValue];
    }
    [invocation setArgument:&param atIndex:index+2];
}
@end

@interface MessageInvocation()
@property (nonatomic,strong) NSObject * target;
@property (nonatomic,strong) NSInvocation * invocation;
@property (nonatomic,strong) NSMutableArray<MessageInvocationParam*> * paramsType;
@property (nonatomic,assign) bool haveReturnValue;
@end

@implementation MessageInvocation

- (instancetype) initWithObject:(NSObject*) target sel:(SEL) selector
{
    self = [super init];
    if (self) {
        self.target = target;
        self.paramsType = [[NSMutableArray<MessageInvocationParam*> alloc] init];
        
        NSMethodSignature * signature = [[target class] instanceMethodSignatureForSelector:selector];
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
        self.invocation = invocation;
        NSSelectorFromString(@"");
        invocation.target = target;
        invocation.selector = selector;
       
        NSInteger paramsCount = signature.numberOfArguments - 2;
        for (int i = 0; i<paramsCount-1; i++) { //最后一个是留给回调block的,固定死的，
            const char * type = [signature getArgumentTypeAtIndex:2+i];
            if (strcmp(type, "@")==0) {
                [self.paramsType addObject:[[MessageInvocationParamObject alloc] init]];
            }else if(strcmp(type, "i")==0 || strcmp(type, "q")==0){
                [self.paramsType addObject:[[MessageInvocationParamInt alloc] init]];
            }else if(strcmp(type, "B")==0){
                [self.paramsType addObject:[[MessageInvocationParamBool alloc] init]];
            }else if(strcmp(type, "f")==0 || strcmp(type, "d")==0){
                [self.paramsType addObject:[[MessageInvocationParamFloat alloc] init]];
            }else{
                DLog(@"不支持的参数类型: %s",type);
            }
        }
        const char *returnType = signature.methodReturnType;
        if( !strcmp(returnType, @encode(void)) ){
            self.haveReturnValue = false;
        }else{
            self.haveReturnValue = true;
        }
    }
    return self;
}

- (instancetype) initWithObject:(NSObject*) target selector:(NSString *) selectorname
{
    SEL selector = NSSelectorFromString(selectorname);
    return [self initWithObject:target sel:selector];
}

- (const char*) invocation:(NSArray *) params block:(NSString *) blockID
{
    for (int i = 0; i <self.paramsType.count; i++) {
        MessageInvocationParam* p = self.paramsType[i];
        [p set_param:i from:params to:self.invocation];
    }
    [self.invocation setArgument:&blockID atIndex:self.paramsType.count+2];
    [self.invocation invoke];
    
    if (self.haveReturnValue) {
        const char * returnValue = nil;
        [self.invocation getReturnValue:&returnValue];
        if (returnValue == nil) {
            return nil;
        }
        return returnValue;
    }
    return nil;
}
@end
