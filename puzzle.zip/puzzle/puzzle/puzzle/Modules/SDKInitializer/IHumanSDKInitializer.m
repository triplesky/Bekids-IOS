//
//  IHumanSDKInitializer.m
//  UnityFramework
//
//  Created by 王哲贤 on 2020/9/8.
//

#import "IHumanSDKInitializer.h"
#import <iHumanSDK/iHumanSDK.h>
#import "AppConfigs.h"
#import "AppDelegate.h"
#import "OrientationController.h"

@implementation IHumanSDKInitializer

- (void)initSDK
{
    [[OrientationController sharedInstance] setOrientationMask:UIInterfaceOrientationMaskLandscape];
    
    AppConfigs * config = [AppConfigs sharedInstance];
    [iHumanSDK registerWithAppId:config.app_id appKey:config.app_key rsaKey:config.rsa_key environment:config.sdk_enviroment];
    [iHumanSDK registerChannels:@[@(IHChannelTypeFacebook)] withAppIds:@[AppFacebookID] appKeys:@[AppFacebookKey]];
//    [LAFCloudCOSSDK registerCloudCOSSDKWithTypeArray:@[@(LAFCOSCredentialTypeHomework)]];
    [iHumanSDK setAppDelegate:self];
    [iHumanSDK setAppleId:APPSTORE_ID];
    
    [iHumanSDK setLanguage:IHLanguageTypeEN];
    
    
    // 开启AF广告投放及归因
    [IHOperation enableAdAttributionWithBlock:^(NSDictionary * _Nullable attributionInfo, IHError * _Nonnull error) {
        if (error && error.message) {
            DLog(@"开启AF广告投放及归因%@ -- %@", error, [[NSBundle mainBundle] bundleIdentifier]);
        }
    }];
    // 开启Firebase广告投放及归因
    [IHOperation enableFirebaseWithBlock:^(IHError * _Nonnull error) {
        if (error && error.message) {
            DLog(@"开启Firebase广告投放及归因%@", error);
        }
    }];
    
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(nonnull NSURL *)url
{
    return [iHumanSDK handleOpenUrl:url sourceApplication:nil annotation:nil];
}

- (BOOL)application:(UIApplication *)app openURL:(nonnull NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(nonnull id)annotation
{
    return [iHumanSDK handleOpenUrl:url sourceApplication:sourceApplication annotation:annotation];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
    return [iHumanSDK handleOpenUniversalLinks:userActivity];
}


- (UIInterfaceOrientationMask) application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    // SDK建议 pad都强制横屏，因为SDK内部的横竖屏逻辑 有时并没有区分pad
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        return UIInterfaceOrientationMaskLandscape;
    }
    return [OrientationController sharedInstance].orientationMask;
}

 - (void)updateOrientation:(IHOrientationType)orientation
{
    IHJOrientationType type = IHJOrientationTypeUseCurrent;
    switch (orientation) {
        case IHOrientationTypeUseCurrent:
            type = IHJOrientationTypeUseCurrent;
            break;
        case IHOrientationTypeLandscape:
            type = IHJOrientationTypeLandscape;
            break;
        case IHOrientationTypePortrait:
            type = IHJOrientationTypePortrait;
            break;
        case IHOrientationTypeAll:
            type = IHJOrientationTypeAll;
            break;
        default:
            break;
    }
    [[OrientationController sharedInstance] setIHOrientation:type];
}



@end
