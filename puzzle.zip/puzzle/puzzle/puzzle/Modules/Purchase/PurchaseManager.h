//
//  PurchaseManager.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import <Foundation/Foundation.h>
#import "PurchaseModel.h"


NS_ASSUME_NONNULL_BEGIN

@interface PurchaseManager : NSObject

+ (instancetype)sharedInstance;

- (void)fetchProductList:(void (^)(NSArray<ProductListItem *> *products))success failure:(void (^)(NSError *error))failure;

- (void)clearProductList;

- (void)purchaseWithProductId:(NSString *)productId;

- (void)createOrderAndPurchaseWithProductId:(NSString *)productId failure:(void (^)(NSError *error))failure;

- (void)restore;

- (NSDictionary *)productInfoForUserRightsType:(NSString *)userRightsType;

- (BOOL)hasVisitorRights:(NSString *)userRightsType;

- (NSInteger)userStatus;

- (void)wantsToPurchasePromotedPayment:(IHPayment *)payment;

- (NSString *)productPriceWithRate:(double)rate productId:(NSString *)productId;

@end

NS_ASSUME_NONNULL_END
