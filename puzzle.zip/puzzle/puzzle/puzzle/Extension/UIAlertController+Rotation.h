//
//  UIAlertController+Rotation.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/30.
//  Copyright © 2020 王哲贤. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIAlertController(Rotation)
- (BOOL)shouldAutorotate;
@end

NS_ASSUME_NONNULL_END
