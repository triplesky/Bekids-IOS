//
//  AppKeys.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#ifndef AppKeys_h
#define AppKeys_h

#ifdef ENVIRONMENT_STAGING

#define AppKey @"987210mnbvcxzlkjhgfdsapoiuytrewq"
#define RSAKey @"-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCp7JB6i0sYAgcOlB3Qnp3l6VzxtCz2w16s6WmE9A2t9/40c/tIhbCmGxAk4DRWGcLkrZKs7DquOk7i5M7x1I7PvGwpKCahlc98XM51eBdw9t2VMCezaRQE3YuHrWCCWEpC6W8a53ansyGZQocTiKqzF35HNKz9fYvVrvcrdXO0kQIDAQAB-----END PUBLIC KEY-----"

#define BuglyKey @"0ddc28a40a"

#else
#define AppKey @"kahtnagqCjtbvhyj46hildhkywzImjrf"
#define RSAKey @"-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3t1ggHu/L1sjicvvKKQYHyAx6BOmZQRfQAy19kzTMVpvD+zmAASZh3DGYKZYXu3L1/hlxaaz4skyCjrYYspauxQkB3H2F9xpVXAR9oqCxF2P4DCCZuhXVT+K8TZrINNG0dFyNYQ4jeXUndakRRqF4GvWLjtZrg1bd+tL5M6xP82+gmsO+6eosjb7dPhn0cd/Eh9Ukf0m0fkmReHgN+cu/PqUo85joG/Sz58rwJIYu00DMb91m72yQq80XQvJQNRMQ/SiHRVwMZsObNnAX6j8sEArAkdY5OU2NY97/jv8YPUA8NtCVkW6yPCi4x3NGnI61n+GX576g/fHt8ft8PlfXwIDAQAB-----END PUBLIC KEY-----"

#define BuglyKey @"761bc3e49a"

#endif


#define AppId @"110"


#define AppFacebookID @"764392397966197"
#define AppFacebookKey @"dc666126adc836d1fb71ca10a0bfe8ec"



#endif /* AppKeys_h */
