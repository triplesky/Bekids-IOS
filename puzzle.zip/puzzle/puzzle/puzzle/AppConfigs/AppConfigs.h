//
//  AppConfigs.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/12.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <iHumanSDK/iHumanSDK.h>
#import "AppKeys.h"

NS_ASSUME_NONNULL_BEGIN

#define APPSTORE_ID @"6443551217"

typedef enum{
    AppEnviroment_Dev = 1,
    AppEnviroment_Staging,
    AppEnviroment_Production,
} AppEnviroment;


@interface AppConfigs : NSObject
@property (assign,nonatomic,readonly) AppEnviroment enviroment;
@property (assign,nonatomic,readonly) IHEnvironmentType sdk_enviroment;

@property (assign,nonatomic,readonly) bool debug_mode;
@property (strong,nonatomic,readonly) NSString* app_id;
@property (strong,nonatomic,readonly) NSString* rsa_key;
@property (strong,nonatomic,readonly) NSString* app_key;
@property (strong,nonatomic,readonly) NSString* bugly_app_key;
@property (strong,nonatomic,readonly) NSString* app_version;


+(instancetype) sharedInstance;
@end

NS_ASSUME_NONNULL_END
