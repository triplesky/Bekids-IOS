//
//  ToastView.m
//  Enlighten
//
//  Created by changle on 2022/7/15.
//

#import "ToastView.h"

@implementation ToastView

+ (void)showToast:(NSString *)text fromView:(UIView *)view completion:(void (^)(void))completion {
    
    ToastView *hud = [[ToastView alloc] initWithView:view];
    [view addSubview:hud];
    
    hud.completionBlock = completion;
    
    hud.removeFromSuperViewOnHide = YES;
    hud.mode = MBProgressHUDModeText;
    
    hud.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.backgroundView.color = [HEXCOLOR(0x1E1E1E) colorWithAlphaComponent:0];
//    hud.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0];
    
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.67];
    
    hud.label.font = [UIFont boldSystemFontOfSize:16];
    hud.label.textColor = [UIColor whiteColor];
    hud.label.numberOfLines = 0;
    
    hud.label.text = text;
    
    hud.margin = 30;
    
    [hud showAnimated:YES];
    
    [hud hideAnimated:YES afterDelay:2];
}

+ (void)showToast:(NSString *)text fromView:(UIView *)view {
    [self showToast:text fromView:view completion:nil];
}

+ (void)showToast:(NSString *)text completion:(void (^)(void))completion {
    UIView *fromView = [UIApplication sharedApplication].delegate.window;
    if (fromView) {
        [self showToast:text fromView:fromView completion:completion];
    }
}

+ (void)showToast:(NSString *)text {
    [self showToast:text completion:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.bezelView.layer.cornerRadius = 10;
    
}

+ (void)showToastImage:(NSString *)ImageStr text:(NSString *)text fromView:(UIView *)view {
    
    ToastView *hud = [[ToastView alloc] initWithView:view];
    [view addSubview:hud];
    //自定义图片
    UIImage *image = [[UIImage imageNamed:ImageStr] imageWithRenderingMode:UIImageRenderingModeAutomatic];
    hud.customView = [[UIImageView alloc] initWithImage:image];
    
    hud.removeFromSuperViewOnHide = YES;
    hud.mode = MBProgressHUDModeCustomView;
    
    hud.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.backgroundView.color = [HEXCOLOR(0x1E1E1E) colorWithAlphaComponent:0];
    
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.67];
    
    hud.label.font = [UIFont boldSystemFontOfSize:16];
    hud.label.textColor = HEXCOLOR(0xFFFFFF);
    hud.label.numberOfLines = 0;
    
    hud.label.text = text;
    
    hud.margin = 30;
    
    [hud showAnimated:YES];
    
    [hud hideAnimated:YES afterDelay:2];
}


@end
