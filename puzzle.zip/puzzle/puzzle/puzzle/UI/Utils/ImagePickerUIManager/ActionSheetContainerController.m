//
//  ActionSheetContainerController.m
//  live
//
//  Created by changle on 2020/9/16.
//  Copyright © 2020 changle. All rights reserved.
//

#import "ActionSheetContainerController.h"

@interface ActionSheetContainerController ()

@property (nonatomic, weak) UIView *dimmingView;

@property(nonatomic, assign) BOOL appearAnimated;
@property(nonatomic, copy) void (^appearCompletionBlock)(BOOL finished);
@property(nonatomic, assign) BOOL disappearAnimated;
@property(nonatomic, copy) void (^disappearCompletionBlock)(BOOL finished);

@property (nonatomic, assign) BOOL visible; // 浮层是否显示

@property(nonatomic, strong) UIWindow *containerWindow;
@property(nonatomic, weak) UIWindow *previousKeyWindow;

@end

@implementation ActionSheetContainerController

- (instancetype)init {
    if (self = [super init]) {
        self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    
    return self;
}

- (BOOL) prefersStatusBarHidden
{
    return YES;
}

- (void)dealloc
{
    self.containerWindow = nil;
}

- (BOOL) shouldAutorotate
{
    return NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    UIView *dimmingView = [[UIView alloc] init];
    dimmingView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    [self.view addSubview:dimmingView];
    self.dimmingView = dimmingView;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dimmingViewTapped:)];
    [dimmingView addGestureRecognizer:tap];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    self.dimmingView.frame = self.view.bounds;
    CGRect contentViewFrame = [self contentViewFrameForShowing];
    
    self.contentView.frame = CGRectApplyAffineTransform(contentViewFrame, self.contentView.transform);
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // 只有使用showWithAnimated:completion:显示出来的浮层，才需要修改之前就记住的animated的值
    animated = self.appearAnimated;
    
    if (self.contentViewController) {
        [self.contentViewController beginAppearanceTransition:YES animated:animated];
    }
    
    UIWindow *window = UIApplication.sharedApplication.delegate.window;
    window.tintAdjustmentMode = UIViewTintAdjustmentModeDimmed;
    [window tintColorDidChange];
    
    void (^didShownCompletion)(BOOL finished) = ^(BOOL finished) {
        
        if (self.contentViewController) {
            [self.contentViewController endAppearanceTransition];
        }
        
        self.visible = YES;
        
        if (self.appearCompletionBlock) {
            self.appearCompletionBlock(finished);
            self.appearCompletionBlock = nil;
        }
        
        self.appearAnimated = NO;
    };
    
    if (animated) {
        [self.view addSubview:self.contentView];
        [self.view layoutIfNeeded];
        
        CGRect contentViewFrame = [self contentViewFrameForShowing];
        
        self.contentView.frame = contentViewFrame;
        [self.contentView setNeedsLayout];
        [self.contentView layoutIfNeeded];
        
        [self showingAnimationWithCompletion:didShownCompletion];
    } else {
        CGRect contentViewFrame = [self contentViewFrameForShowing];
        self.contentView.frame = contentViewFrame;
        [self.view addSubview:self.contentView];
        didShownCompletion(YES);
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    animated = self.disappearAnimated;
    
    [self.view endEditing:YES];
    
    if (self.contentViewController) {
        [self.contentViewController beginAppearanceTransition:NO animated:animated];
    }
    
    UIWindow *window = UIApplication.sharedApplication.delegate.window;
    window.tintAdjustmentMode = UIViewTintAdjustmentModeNormal;
    [window tintColorDidChange];
    
    void (^didHiddenCompletion)(BOOL finished) = ^(BOOL finished) {
        
        // 恢复 keyWindow 之前做一下检查，避免这个问题 https://github.com/Tencent/QMUI_iOS/issues/90
        if (UIApplication.sharedApplication.keyWindow == self.containerWindow) {
            if (self.previousKeyWindow.hidden) {
                // 保护了这个 issue 记录的情况，避免主 window 丢失 keyWindow https://github.com/Tencent/QMUI_iOS/issues/315
                [UIApplication.sharedApplication.delegate.window makeKeyWindow];
            } else {
                [self.previousKeyWindow makeKeyWindow];
            }
        }
        self.containerWindow.hidden = YES;
        self.containerWindow.rootViewController = nil;
        self.previousKeyWindow = nil;
        [self endAppearanceTransition];
        
        [self.contentView removeFromSuperview];
        if (self.contentViewController) {
            [self.contentViewController endAppearanceTransition];
        }
        
        self.visible = NO;
        
        if (self.disappearCompletionBlock) {
            self.disappearCompletionBlock(YES);
            self.disappearCompletionBlock = nil;
        }
        
        self.disappearAnimated = NO;
    };
    
    if (animated) {
        [self hidingAnimationWithCompletion:didHiddenCompletion];
    } else {
        didHiddenCompletion(YES);
    }
}

- (CGRect)contentViewFrameForShowing {
    
    CGSize contentViewContainerSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height);
    CGSize contentViewLimitSize = CGSizeMake(contentViewContainerSize.width, contentViewContainerSize.height);
    CGSize contentViewSize = CGSizeZero;
    
    contentViewSize = [self.contentView sizeThatFits:contentViewLimitSize];
    contentViewSize.width = fmin(contentViewLimitSize.width, contentViewSize.width);
    contentViewSize.height = fmin(contentViewLimitSize.height, contentViewSize.height);
    CGRect contentViewFrame = CGRectMake((contentViewContainerSize.width - contentViewSize.width) * 0.5, contentViewContainerSize.height - contentViewSize.height - 20, contentViewSize.width, contentViewSize.height);
    return contentViewFrame;
}

#pragma mark -
- (void)setContentViewController:(UIViewController *)contentViewController {
    _contentViewController = contentViewController;
    self.contentView = contentViewController.view;
}

#pragma mark -
- (void)dimmingViewTapped:(UITapGestureRecognizer *)tap {
    [self hideWithAnimated:YES completion:nil];
}

- (void)showWithAnimated:(BOOL)animated completion:(void (^)(BOOL))completion {
    if (self.visible) return;
    
    // makeKeyAndVisible 导致的 viewWillAppear: 必定 animated 是 NO 的，所以这里用额外的变量保存这个 animated 的值
    self.appearAnimated = animated;
    self.appearCompletionBlock = completion;
    self.previousKeyWindow = UIApplication.sharedApplication.keyWindow;
    if (!self.containerWindow) {
        self.containerWindow = [[UIWindow alloc] init];
        self.containerWindow.windowLevel = UIWindowLevelAlert;
        self.containerWindow.backgroundColor = [UIColor colorWithWhite:1 alpha:0];// 避免横竖屏旋转时出现黑色
        self.containerWindow.layer.zPosition = 1000;
    }
    self.containerWindow.rootViewController = self;
    [self.containerWindow makeKeyAndVisible];
}

- (void)hideWithAnimated:(BOOL)animated completion:(void (^)(BOOL))completion {
    if (!self.visible) return;
    
    self.disappearAnimated = animated;
    self.disappearCompletionBlock = completion;
    // window模式下，通过手动触发viewWillDisappear:来做界面消失的逻辑
    [self beginAppearanceTransition:NO animated:animated];
}

- (void)showingAnimationWithCompletion:(void (^)(BOOL))completion {
    self.dimmingView.alpha = 0.0;
    self.contentView.transform = CGAffineTransformMakeTranslation(0, self.view.bounds.size.height - self.contentView.frame.origin.y);
    [UIView animateWithDuration:.2 delay:0.0 options:(7<<16) animations:^{
        self.dimmingView.alpha = 1.0;
        self.contentView.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        if (completion) {
            completion(finished);
        }
    }];
}

- (void)hidingAnimationWithCompletion:(void (^)(BOOL))completion {
    [UIView animateWithDuration:.2 delay:0.0 options:(7<<16) animations:^{
        self.dimmingView.alpha = 0.0;
        self.contentView.transform = CGAffineTransformMakeTranslation(0, self.view.bounds.size.height - self.contentView.frame.origin.y);
    } completion:^(BOOL finished) {
        if (completion) {
            self.dimmingView.alpha = 1.0;
            self.contentView.transform = CGAffineTransformIdentity;
            completion(finished);
        }
    }];
}


@end
