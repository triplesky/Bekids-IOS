//
//  ImagePickerActionSheetContentView.h
//  live
//
//  Created by changle on 2020/9/16.
//  Copyright © 2020 changle. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, ImagePickerActionSheetType) {
    ImagePickerActionSheetTypeCamera = 0L,
    ImagePickerActionSheetTypePhoto,
    ImagePickerActionSheetTypeCancel
};


@class ImagePickerActionSheetContentView;
@protocol ImagePickerActionSheetContentViewDelegate <NSObject>

@optional
- (void)imagePickerActionSheetContentView:(ImagePickerActionSheetContentView *)contentView didSelectActionType:(ImagePickerActionSheetType)type;

@end

@interface ImagePickerActionSheetContentView : UIView

@property (nonatomic, weak) id<ImagePickerActionSheetContentViewDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
