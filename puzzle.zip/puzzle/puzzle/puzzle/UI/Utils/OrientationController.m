//
//  OrientationController.m
//  Exercise
//
//  Created by changle on 2021/12/15.
//

#import "OrientationController.h"

@interface OrientationController ()

@end

@implementation OrientationController

+ (instancetype)sharedInstance {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

- (instancetype)init {
    
    if (self = [super init]) {
        self.orientationMask = UIInterfaceOrientationMaskPortrait;
    }
    
    return self;
}

- (void)setOrientationMask:(UIInterfaceOrientationMask)orientationMask {
    _orientationMask = orientationMask;
}

- (void)updateInterfaceOrientationMask:(UIInterfaceOrientationMask)orientationMask {
    self.orientationMask = orientationMask;
    UIDeviceOrientation targetDeviceOrientation = UIDeviceOrientationPortrait;
    UIDeviceOrientation deviceOrientation = [UIDevice currentDevice].orientation;
    
    if ((orientationMask & UIInterfaceOrientationMaskAll) == UIInterfaceOrientationMaskAll) {
        targetDeviceOrientation = deviceOrientation;
    } else if ((orientationMask & UIInterfaceOrientationMaskAllButUpsideDown) == UIInterfaceOrientationMaskAllButUpsideDown) {
        if (deviceOrientation != UIDeviceOrientationPortraitUpsideDown) {
            targetDeviceOrientation = deviceOrientation;
        }
    } else if ((orientationMask & UIInterfaceOrientationMaskLandscape) == UIInterfaceOrientationMaskLandscape) {
        if (deviceOrientation == UIDeviceOrientationLandscapeLeft || deviceOrientation == UIDeviceOrientationLandscapeRight) {
            targetDeviceOrientation = deviceOrientation;
        } else {
            targetDeviceOrientation = UIDeviceOrientationLandscapeLeft;
        }
    } else if (orientationMask & UIInterfaceOrientationMaskLandscapeLeft) {
        targetDeviceOrientation = UIDeviceOrientationLandscapeRight;
    } else if (orientationMask & UIInterfaceOrientationMaskLandscapeRight) {
        targetDeviceOrientation = UIDeviceOrientationLandscapeLeft;
    } else if (orientationMask & UIInterfaceOrientationMaskPortraitUpsideDown) {
        targetDeviceOrientation = UIDeviceOrientationPortraitUpsideDown;
    } else {
        targetDeviceOrientation = UIDeviceOrientationPortrait;
    }
    
    [self forceRotateScreenWithTargetDeviceOrientation:targetDeviceOrientation];
}

- (void)setIHOrientation:(IHJOrientationType)orientation {
    
    if (orientation == IHJOrientationTypeAll) {
        self.orientationMask = UIInterfaceOrientationMaskAll;
    } else if (orientation == IHJOrientationTypeLandscape) {
        self.orientationMask = UIInterfaceOrientationMaskLandscape;
    } else if (orientation == IHJOrientationTypePortrait) {
        self.orientationMask = UIInterfaceOrientationMaskPortrait;
    } else if (orientation == IHJOrientationTypeUseCurrent) {
        
    } else {
        
    }
}

- (void)forceRotateScreenWithTargetDeviceOrientation:(UIDeviceOrientation)targetDeviceOrientation {
    
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
//        [[UIDevice currentDevice] setValue:@(UIDeviceOrientationUnknown) forKey:@"orientation"];
        [[UIDevice currentDevice] setValue:@(targetDeviceOrientation) forKey:@"orientation"];
    }
    [UIViewController attemptRotationToDeviceOrientation];
    [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
}

@end
