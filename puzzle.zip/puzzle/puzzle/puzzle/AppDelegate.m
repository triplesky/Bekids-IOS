//
//  AppDelegate.m
//  puzzle
//
//  Created by changle on 2022/8/12.
//

#import "AppDelegate.h"
#import "MessageDistribution.h"
#import <UnityFramework/NativeCommunicater.h>
#import "IHumanSDKInitializer.h"
#import <AVFoundation/AVFoundation.h>
#import <QXUtilityKit/QXLogger.h>
#import "UserCenter.h"

@interface AppDelegate ()

@property (strong,nonatomic,readonly) IHumanSDKInitializer *sdkInitializer;
@property (assign,nonatomic) BOOL first_launcher;

@end

@implementation AppDelegate

- (void)initApplication
{
    [self initSDK];
    [NativeCommunicater sharedInstance].messageDelegate = [[MessageDistribution alloc] init];
    
    [[UserCenter sharedInstance] setupWithMode:UserCenterLoginModeSupportVisitor];
        
    MessageDistribution * distributioner =(MessageDistribution*)[NativeCommunicater sharedInstance].messageDelegate;
    [distributioner initBugly];
}
- (void) initSDK
{
    if(self.sdkInitializer == nil){
        _sdkInitializer = [[IHumanSDKInitializer alloc] init];
        [_sdkInitializer initSDK];
    }
}

- (void)showLaunchScreenWithCompletion:(void (^)(void))completion {
    if (!self.first_launcher) {
        self.first_launcher = YES;
        [self initAudioCategory];
        [iHumanSDK useVideoLaunchView:YES];
        [iHumanSDK showLaunchViewWithDismissBlock:^{
            //洪恩隐私页
            [iHumanSDK showPrivacyPolicyIfNeeded];
            if (completion) {
                completion();
            }
        }];
    }
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self initApplication];
    [super application:application didFinishLaunchingWithOptions:launchOptions];
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    DLog(@"window-->%@",application.delegate.window);
    return YES;
}

- (void) initAudioCategory
{
    NSError * error = nil;
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker|AVAudioSessionCategoryOptionAllowBluetooth error:&error];
    [[AVAudioSession sharedInstance] setActive:YES error:&error];
    DLog(@"%@",error);
    DLog(@"%@",[AVAudioSession sharedInstance].category);
}

- (UIViewController *) topViewController
{
    if (self.window.rootViewController == nil) {
        nil;
    }
    UIViewController * vc = self.window.rootViewController;
    while (vc.presentedViewController) {
        vc = vc.presentedViewController;
    }
    return vc;
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return [self.sdkInitializer application:application supportedInterfaceOrientationsForWindow:window];
}

- (BOOL)application:(UIApplication*)app openURL:(NSURL*)url options:(NSDictionary<NSString*, id>*)options
{
    return [self.sdkInitializer application:app handleOpenURL:url];
}

- (BOOL)application:(UIApplication*)application openURL:(NSURL*)url sourceApplication:(NSString*)sourceApplication annotation:(id)annotation
{
    [super application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
    return [self.sdkInitializer application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
}

- (void)applicationDidEnterBackground:(UIApplication*)application
{
    
    [[NativeCommunicater sharedInstance] call_application:@"application_did_enter_background" params:@"{}"];
    [super applicationDidEnterBackground:application];
    MessageDistribution * distributioner =(MessageDistribution*)[NativeCommunicater sharedInstance].messageDelegate;
    [distributioner app_enter_background];
}
- (void)applicationWillEnterForeground:(UIApplication*)application
{
   
    [[NativeCommunicater sharedInstance] call_application:@"application_did_enter_forgeground" params:@"{}"];
     [super applicationWillEnterForeground:application];
    MessageDistribution * distributioner =(MessageDistribution*)[NativeCommunicater sharedInstance].messageDelegate;
    [distributioner app_enter_forgeground];
}

- (void)applicationWillResignActive:(UIApplication*)application
{
    [super applicationWillResignActive:application];
}
- (void)applicationDidReceiveMemoryWarning:(UIApplication*)application
{
    [super applicationDidReceiveMemoryWarning:application];
    [[NativeCommunicater sharedInstance] call_application:@"application_did_receive_memory_warning" params:@"{}"];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
    [super application:application continueUserActivity:userActivity restorationHandler:restorationHandler];
    return [self.sdkInitializer application:application continueUserActivity:userActivity restorationHandler:restorationHandler];
}

@end
