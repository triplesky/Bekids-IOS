//
//  AppDelegate.h
//  puzzle
//
//  Created by changle on 2022/8/12.
//

#import <UnityFramework/UnityFramework.h>
#import <iHumanSDK/iHumanSDK.h>
#import <UIKit/UIKit.h>

@interface AppDelegate : UnityAppController

- (void)showLaunchScreenWithCompletion:(void (^)(void))completion;

@end
