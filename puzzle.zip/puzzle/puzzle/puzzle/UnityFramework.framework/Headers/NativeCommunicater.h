/*
自动生成的代码，不要手动修改。
PRC在IOS平台的管理类,主要作用是记录回调
Native的函数指针。同时分发函数到各个模块
*/
#import <Foundation/Foundation.h>
#import "NativeCommunicaterForIOS.h"

__attribute__ ((visibility("default")))

@protocol NativeCommunicaterProtocol <NSObject>
@required
- (const char*) on_message:(NSString*) message params:(NSString *) params block:(NSString*) blockID;
- (void) application_report_log:(NSString*) message;
@end

__attribute__ ((visibility("default")))
@interface NativeCommunicater : NSObject
{
   
}
@property(assign, nonatomic) recive_native_call_application recive_native_call_application_callback;
@property(assign, nonatomic) recive_native_call_application_block recive_native_call_application_block_callback;
@property(assign, nonatomic) recive_report_download_task_report recive_report_download_task_report_callback;
@property(assign, nonatomic) recive_native_request_runing_state recive_native_request_runing_state_callback;



//系统默认的。无法删除
@property(strong, nonatomic) id<NativeCommunicaterProtocol> messageDelegate;

+ (instancetype) sharedInstance;
#pragma -mark Lua调用Native的函数
- (const char*) on_message:(NSString*) message params:(NSString *) params block:(NSString*) blockID;
- (void) call_application:(NSString *) message params:(NSString *) params;
- (void) call_application_with_block:(NSString *) blockID params:(NSString *) params;
- (void) report_download_task:(NSString*) url status:(int) status current:(int) bytes total:(int)total_bytes error:(int) ercode errormsg:(NSString*) errormsg;
- (NSString *) get_app_runing_state;
- (void) application_report_log:(NSString*) message;
@end
