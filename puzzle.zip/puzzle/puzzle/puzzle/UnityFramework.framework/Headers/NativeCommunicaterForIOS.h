/*
    此代码自动生成的，不要手动修改
    C#调用Native的接口文件
*/

#ifdef __cplusplus
extern "C"
{
#endif
    //函数指针声明
    #ifndef RPC
    #define RPC
        typedef void(*recive_native_call_application)(const char* message, const char* paramStr);
        typedef void(*recive_native_call_application_block)(const char* blockID, const char* paramStr);
        typedef void(*recive_report_download_task_report)(const char* url, int status, int cbyte, int tbytes, int ecode, const char* errmsg);
        typedef const char*(*recive_native_request_runing_state)(void);

        extern const char* application_call_native(const char* message, const char* paramStr, const char* blockID);
        extern void application_report_log(const char* message);
        extern void application_regist_call_back(const char* message, void* function_ptr);
    #endif

#ifdef __cplusplus
}
#endif
