//
//  BaseMacro.h
//  Enlighten
//
//  Created by changle on 2022/7/11.
//

#ifndef BaseMacro_h
#define BaseMacro_h

#define CasablancaURWDigitalFont(x)               [UIFont fontWithName:@"CasablancaURW-Bol" size:x]

#define RGBCOLOR(r, g, b)               [UIColor colorWithRed : (r) / 255.0f green : (g) / 255.0f blue : (b) / 255.0f alpha : 1]
#define RGBACOLOR(r, g, b, a)           [UIColor colorWithRed : (r) / 255.0f green : (g) / 255.0f blue : (b) / 255.0f alpha : (a)]

// sample: Designer - #FF0000, We - HEXCOLOR(0xFF0000)
#define HEXCOLOR(hexValue)              [UIColor colorWithRed : ((CGFloat)((hexValue & 0xFF0000) >> 16)) / 255.0 green : ((CGFloat)((hexValue & 0xFF00) >> 8)) / 255.0 blue : ((CGFloat)(hexValue & 0xFF)) / 255.0 alpha : 1.0]

#define HEXACOLOR(hexValue, alphaValue) [UIColor colorWithRed : ((CGFloat)((hexValue & 0xFF0000) >> 16)) / 255.0 green : ((CGFloat)((hexValue & 0xFF00) >> 8)) / 255.0 blue : ((CGFloat)(hexValue & 0xFF)) / 255.0 alpha : (alphaValue)]

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)

#define VERTICAL_SCREEN_WIDTH ([UIScreen mainScreen].nativeBounds.size.width / [UIScreen mainScreen].nativeScale)
#define VERTICAL_SCREEN_HEIGHT ([UIScreen mainScreen].nativeBounds.size.height / [UIScreen mainScreen].nativeScale)

#define HORIZONTAL_SCREEN_WIDTH ([UIScreen mainScreen].nativeBounds.size.height / [UIScreen mainScreen].nativeScale)
#define HORIZONTAL_SCREEN_HEIGHT ([UIScreen mainScreen].nativeBounds.size.width / [UIScreen mainScreen].nativeScale)

#define isiPhoneX \
({BOOL isPhoneX = NO;\
if (@available(iOS 11.0, *)) {\
isPhoneX = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom > 0.0;\
}\
(isPhoneX);})

#define StatusHeight (isiPhoneX ? 47. : 20.)
#define NavigationBarHeight (isiPhoneX ? 110. : 86.)

#define IS_IPHONE ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
#define IS_PAD ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
#define IsPortrait ([[UIApplication sharedApplication].keyWindow.windowScene interfaceOrientation] == UIInterfaceOrientationPortrait || [[UIApplication sharedApplication].keyWindow.windowScene interfaceOrientation] == UIInterfaceOrientationPortraitUpsideDown)
#define IsLandscape ([[UIApplication sharedApplication].keyWindow.windowScene interfaceOrientation] == UIDeviceOrientationLandscapeRight || [[UIApplication sharedApplication].keyWindow.windowScene interfaceOrientation] == UIDeviceOrientationLandscapeLeft)

#define fitUI_Value(x) (([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)  ? (SCREEN_WIDTH < SCREEN_HEIGHT ? SCREEN_WIDTH / 1024.0 * x : SCREEN_HEIGHT / 768.0 * x) : (SCREEN_WIDTH < SCREEN_HEIGHT ? SCREEN_WIDTH / 375.0 * x : SCREEN_HEIGHT / 812.0 * x))

#define HORIZONTAL_fitUI_Value(x) (([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)  ? (HORIZONTAL_SCREEN_WIDTH / 1024.0 * x) : (HORIZONTAL_SCREEN_WIDTH / 812.0 * x))

#define VERTICAL_fitUI_Value(x) (([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)  ? (VERTICAL_SCREEN_WIDTH / 768.0 * x) : (VERTICAL_SCREEN_WIDTH / 375.0 * x))

#define LocalString(x)      NSLocalizedString(x, nil)

#define AppPrefix @"com.bekids.gogotown"

#define AppName(name) [AppPrefix stringByAppendingString:name]

#define AppLibraryDirectory [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:AppPrefix]


#define IHErrorDomain @"IHErrorDomain"
#define IHResponseErrorDomain @"IHResponseErrorDomain"
#import "ErrorMaker.h"

#endif /* BaseMacro_h */
