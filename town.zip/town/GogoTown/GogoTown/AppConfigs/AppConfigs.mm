//
//  AppConfigs.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/12.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "AppConfigs.h"
#import "AppKeys.h"

@implementation AppConfigs

+(instancetype) sharedInstance
{
    static AppConfigs * instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[AppConfigs alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _app_id = AppId;
        
        [self initMode];
        [self initEnviroment];
        [self init_bugly_key];
        NSString * versionKey = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
        _app_version = versionKey;
    }
    return self;
}

- (void) init_bugly_key
{
    _bugly_app_key = BuglyKey;
}

- (void) initMode
{
    _debug_mode = NO;
#ifdef DEBUG
    _debug_mode = YES;
#endif
}
- (void) initEnviroment
{
#if defined(ENVIRONMENT_STAGING)
    _enviroment = AppEnviroment_Staging;
    _sdk_enviroment = IHEnvironmentTypeStaging;
#elif defined(ENVIRONMENT_PRODUCTION)
    _enviroment = AppEnviroment_Production;
    _sdk_enviroment = IHEnvironmentTypeProduction;
#endif
    
    _app_key = AppKey;
    _rsa_key = RSAKey;
    
    _app_display_name = [NSBundle mainBundle].infoDictionary[@"CFBundleDisplayName"] ? : @"";
}
@end
