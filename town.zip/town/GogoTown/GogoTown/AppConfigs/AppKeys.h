//
//  AppKeys.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#ifndef AppKeys_h
#define AppKeys_h

#ifdef ENVIRONMENT_STAGING

#define AppKey @"987210mnbvcxzlkjhgfdsapoiuytrewq"
#define RSAKey @"-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCp7JB6i0sYAgcOlB3Qnp3l6VzxtCz2w16s6WmE9A2t9/40c/tIhbCmGxAk4DRWGcLkrZKs7DquOk7i5M7x1I7PvGwpKCahlc98XM51eBdw9t2VMCezaRQE3YuHrWCCWEpC6W8a53ansyGZQocTiKqzF35HNKz9fYvVrvcrdXO0kQIDAQAB-----END PUBLIC KEY-----"

#define BuglyKey @"085e1ab803"

#else
#define AppKey @"wsfinMnvehwdf7Nbiqtqxfadbuivbh1s"
#define RSAKey @"-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA30TFa+cOlcVFx9zOVZzw8AdIwYS2rbwBo4nSz0Ith2ObANq+IzTklNGOJpyYDH8flh09ackLv3seKhjm66bPJd4OFuJrPlRXacTTd6GTYOsg8GopdjBKhmH3M+ifzlkuBLhb4oyFPMlG9hD+3sbBfyoPPe0ay4CXGgsA2IBI+G5bYHzclb9GzbcHn/9TnC9gVM9mCv+CtoL0GCLqLKwoepiqrb+JqtYoOW117QnfDQB+JMYYwMN6rTJedEZU+xDj5DLrzcqN5EM+54sSZiEwzQTwng6A61/wNyxrEHo/BH0CTAqi+c4Sqi5bcraCm5XLEsslmkE8gp2fapq4q7g/jwIDAQAB-----END PUBLIC KEY-----"

#define BuglyKey @"b9d56b655d"

#endif


#define AppId @"112"

#define APPSTORE_ID @"1661911273"

#define AppFacebookID @"2375299879306744"
#define AppFacebookKey @"5b507e40af4a6fe3737d9983502d6443"



#endif /* AppKeys_h */
