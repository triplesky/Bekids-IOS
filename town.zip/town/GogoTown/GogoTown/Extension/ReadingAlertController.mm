//
//  ReadingAlertController.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2021/1/12.
//  Copyright © 2021 iHuman Inc. All rights reserved.
//

#import "ReadingAlertController.h"

@interface ReadingAlertController ()

@end

@implementation ReadingAlertController

- (BOOL)shouldAutorotate
{
    return YES;
}

@end
