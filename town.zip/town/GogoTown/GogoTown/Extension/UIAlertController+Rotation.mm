//
//  UIAlertController+Rotation.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/30.
//  Copyright © 2020 王哲贤. All rights reserved.
//

#import "UIAlertController+Rotation.h"
@implementation UIAlertController(Rotation)
- (BOOL)shouldAutorotate
{
    return YES;
}
@end
