//
//  ReadingAlertController.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2021/1/12.
//  Copyright © 2021 iHuman Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ReadingAlertController : UIAlertController

@end

NS_ASSUME_NONNULL_END
