//
//  UserCenter.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN NSString *const UserCenterSDKLoginUpdateNotification;
FOUNDATION_EXTERN NSString *const UserCenterLoginUpdateNotification;
FOUNDATION_EXTERN NSString *const UserCenterUserInfoUpdateNotification;

typedef NS_ENUM(NSUInteger, LoginState) {
    LoginStateLogout = 0, /// 用户从未登录过，或用户手动注销
    LoginStateLogin = 1, /// 用户登录
    LoginStateTokenInvalid = 2, /// token失效或缓存过期
};

@interface UserCenter : NSObject

+ (instancetype)sharedInstance;

- (void)loginWithSuccess:(void (^ _Nullable)(void))success failure:(void (^ _Nullable)(NSError *error))failure;

- (void)logout;

- (void)refreshUserInfoWithSuccess:(void (^ _Nullable)(UserInfoModel *model))success failure:(void (^ _Nullable)(NSError *error))failure;

@property (nonatomic, assign, readonly) LoginState loginState;

@property (nonatomic, strong, nullable, readonly) LoginModel *loginModel;
@property (nonatomic, strong, nullable, readonly) UserInfoModel *userInfoModel;
@property (nonatomic, strong, nullable, readonly) UserRightsModel *userRightsModel;

@end

NS_ASSUME_NONNULL_END
