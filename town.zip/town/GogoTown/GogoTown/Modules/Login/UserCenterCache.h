//
//  UserCenterCache.h
//  GogoTown
//
//  Created by changle on 2023/7/17.
//

#import <Foundation/Foundation.h>
#import "LoginModel.h"
#import "UserInfoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserCenterCache : NSObject

- (void)clear;

- (LoginModel *)loginModel;
- (UserInfoModel *)userInfoModel;

- (void)saveLoginModel:(LoginModel *)model;
- (void)saveUserInfoModel:(UserInfoModel *)model;



@end

NS_ASSUME_NONNULL_END
