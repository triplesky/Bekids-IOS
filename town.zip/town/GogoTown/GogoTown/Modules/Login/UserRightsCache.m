//
//  UserCache.m
//  Enlighten
//
//  Created by changle on 2022/7/13.
//

#import "UserRightsCache.h"
@import FMDB;
#import <sqlite3.h>

#define DB_SECRETKEY @"YpKZiRfbVJuMA4os"

static NSString *const kMainTable = @"MainTable";

@interface UserRightsCache ()

@property (nonatomic, copy) NSString *path;
@property (nonatomic, strong) FMDatabase *db;

@property (nonatomic, strong) NSMutableDictionary<NSString *, UserRightsModel *> *userRightsDict;

@end

@implementation UserRightsCache

- (instancetype)initWithDirectory:(NSString *)directory filename:(NSString *)filename {
    if (self = [super init]) {
        
        _userRightsDict = [NSMutableDictionary dictionary];
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:directory isDirectory:nil]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        NSString *key = [DB_SECRETKEY gogo_keyWithP1:NSStringFromClass([self class])];
        DLog(@"UserRightsCache DB KEY: %@", key);
        
        self.path = [directory stringByAppendingPathComponent:filename];
        self.db = [FMDatabase databaseWithPath:self.path];
        [self.db setKey:key];
        
        if (![self createTable]) {
            [self.db close];
            [[NSFileManager defaultManager] removeItemAtPath:self.path error:nil];
            self.db = [FMDatabase databaseWithPath:self.path];
            [self.db setKey:key];
            [self createTable];
        }
    }
    
    return self;
}

- (BOOL)createTable {
    return [self.db executeUpdate:[NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (\n"
                                   "\t uid TEXT PRIMARY KEY, \n"
                                   "\t userRightsJson TEXT NOT NULL \n"
                                            ");\n", kMainTable]];
}

- (void)dealloc {
    [self close];
}

- (void)saveUserRightsModel:(UserRightsModel *)model uid:(NSString * _Nullable)uid {
    [self.db beginExclusiveTransaction];
    
    if (model == nil) {
        return;
    }
    
    model.cacheTime = [[NSDate date] timeIntervalSince1970];
    if (uid == nil) {
        uid = @"";
    }
    
    if (![self.db executeUpdate:[NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ (uid, userRightsJson) VALUES (?, ?)", kMainTable], uid, [model yy_modelToJSONString]]) {
        [self.db rollback];
        DLog(@"saveUserRightsModel insert error: %@, %@", kMainTable, [model yy_modelToJSONString]);
        return;
    }
    
    [self.db commit];
    
    _userRightsDict[uid] = model;
}

- (UserRightsModel *)userRightsModelWithUid:(NSString *)uid {
    if (uid == nil) {
        uid = @"";
    }
    
    UserRightsModel *userRightsModel = _userRightsDict[uid];
    if (userRightsModel == nil) {
        
        FMResultSet *res = [self.db executeQuery:[NSString stringWithFormat:@"SELECT * FROM %@ WHERE uid = ?", kMainTable], uid];
        
        UserRightsModel *model = nil;
        NSError *error = nil;
        while ([res nextWithError:&error]) {
            model = [UserRightsModel yy_modelWithJSON:[res stringForColumn:@"userRightsJson"]];
        }
        
        if (error) {
            DLog(@"%@", error);
        }
        
        if (model == nil) {
            return nil;
        }
        
        NSUInteger dur = [[NSDate date] timeIntervalSince1970] - model.cacheTime;
        if (dur < 0 || dur > 60 * 60 * 24 * 7) { // 用户权益，7天强制过期
            return nil;
        }
        
        userRightsModel = model;
        _userRightsDict[uid] = userRightsModel;
    }
    
    return userRightsModel;
}

#pragma mark -

- (FMDatabase *)db {
    if (![_db isOpen]) {
        [_db openWithFlags:SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE];
    }
    
    return _db;
}

- (void)close {
    [self.db close];
    self.db = nil;
}

@end
