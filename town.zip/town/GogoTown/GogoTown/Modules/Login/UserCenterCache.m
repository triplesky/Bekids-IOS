//
//  UserCenterCache.m
//  GogoTown
//
//  Created by changle on 2023/7/17.
//

#import "UserCenterCache.h"

static NSString *const kUserLoginInfoKey = @"AppLoginInfo";
static NSString *const kUserUserInfoKey = @"AppUserInfo";

@interface UserCenterCache ()

@property (nonatomic, copy) NSString *path;
@property (nonatomic, strong) NSMutableDictionary *caches;

@end

@implementation UserCenterCache

- (instancetype)init {
    if (self = [super init]) {
        self.path = [AppLibraryDirectory stringByAppendingPathComponent:@"UserInfoCaches"];
        self.caches = [NSMutableDictionary dictionaryWithContentsOfFile:self.path];
        if (self.caches == nil) {
            self.caches = [NSMutableDictionary dictionary];
        }
    }
    
    return self;
}

- (void)clear
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserLoginInfoKey];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserUserInfoKey];
    [self.caches removeAllObjects];
    [self.caches writeToFile:self.path atomically:YES];
}

- (LoginModel *)loginModel {
    NSString *loginInfo = self.caches[kUserLoginInfoKey];
    if (loginInfo.length == 0) {
        loginInfo = [[NSUserDefaults standardUserDefaults] objectForKey:kUserLoginInfoKey];
        if (loginInfo.length == 0) {
            return nil;
        }
    }
    
    LoginModel *loginModel = [LoginModel yy_modelWithJSON:loginInfo];
    return loginModel;
}

- (UserInfoModel *)userInfoModel {
    NSString *userInfo = self.caches[kUserUserInfoKey];
    if (userInfo.length == 0) {
        userInfo = [[NSUserDefaults standardUserDefaults] objectForKey:kUserUserInfoKey];
        if (userInfo.length == 0) {
            return nil;
        }
    }
    UserInfoModel *userInfoModel = [UserInfoModel yy_modelWithJSON:userInfo];
    return userInfoModel;
}

- (void)saveLoginModel:(LoginModel *)model {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserLoginInfoKey];
    self.caches[kUserLoginInfoKey] = [model yy_modelToJSONString];
    [self.caches writeToFile:self.path atomically:YES];
}

- (void)saveUserInfoModel:(UserInfoModel *)model {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserUserInfoKey];
    self.caches[kUserUserInfoKey] = [model yy_modelToJSONString];
    [self.caches writeToFile:self.path atomically:YES];
}

@end
