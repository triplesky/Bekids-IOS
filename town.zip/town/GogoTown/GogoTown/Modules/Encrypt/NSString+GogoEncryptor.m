//
//  NSString+AppEncryptor.m
//  puzzle
//
//  Created by changle on 2022/11/14.
//

#import "NSString+GogoEncryptor.h"
#import "UserCenter.h"
@import QXUtilityKit;

@implementation NSString (GogoEncryptor)


- (NSString *)gogo_keyWithP1:(NSString *)p1 {
    
    NSMutableString *mstr = [NSMutableString stringWithString:[iHumanSDK deviceId]];
    if (self.length) {
        [mstr appendString:self];
    }
    
    if (p1.length) {
        [mstr appendString:[p1 qx_md5]];
    }
    
    if (mstr.length == 0) {
        return @"";
    }
    
    return [mstr qx_md5];
}

- (NSString *)gogo_keyWithP1:(NSString *)p1 p2:(NSString *)p2 {
    
    NSMutableString *mstr = [NSMutableString string];
    [mstr appendString:[self gogo_keyWithP1:p1]];
    
    if (p2.length) {
        [mstr appendString:p2];
    }
    
    if (mstr.length == 0) {
        return @"";
    }
    
    return [mstr qx_md5];
}

@end
