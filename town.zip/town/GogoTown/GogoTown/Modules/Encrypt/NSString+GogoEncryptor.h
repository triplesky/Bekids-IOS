//
//  NSString+AppEncryptor.h
//  puzzle
//
//  Created by changle on 2022/11/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (GogoEncryptor)

- (NSString *)gogo_keyWithP1:(NSString *)p1;

- (NSString *)gogo_keyWithP1:(NSString *)p1 p2:(NSString *)p2;

@end

NS_ASSUME_NONNULL_END
