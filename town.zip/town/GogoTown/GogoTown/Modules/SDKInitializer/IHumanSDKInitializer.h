//
//  IHumanSDKInitializer.h
//  UnityFramework
//
//  Created by 王哲贤 on 2020/9/8.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <iHumanSDK/iHumanSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface IHumanSDKInitializer : NSObject<IHAppDelegate>
//初始化项目SDK
- (void) initSDK;

- (BOOL)application:(UIApplication *)application handleOpenURL:(nonnull NSURL *)url;
- (BOOL)application:(UIApplication *)app openURL:(nonnull NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(nonnull id)annotation;
- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler;
- (UIInterfaceOrientationMask) application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window;
@end

NS_ASSUME_NONNULL_END
