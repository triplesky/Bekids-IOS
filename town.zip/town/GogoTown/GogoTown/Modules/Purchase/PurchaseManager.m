//
//  PurchaseManager.m
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "PurchaseManager.h"
#import "UserCenter.h"

NSString *const kProductIdForUserRightsUserDefaultKey = @"ProductIdForUserRightsType";

NSString *const kUserStatusUserDefaultsKey = @"UserStatusUserDefaultsKey";

@interface PurchaseManager () /* <IHPaymentProtocol> */

@property (nonatomic, strong) NSArray<ProductListItem *> *productList;

@end

@implementation PurchaseManager

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static id instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    
    if (self = [super init]) {
        
    }
    
    return self;
}

- (void)fetchProductList:(void (^)(NSArray<ProductListItem *> * _Nullable))success failure:(void (^)(NSError * _Nonnull))failure userStatusCallback:(void (^)(NSError * _Nullable))userStatusCallback {
    
    if (self.productList) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (userStatusCallback) {
                userStatusCallback(nil);
            }
            
            if (success) {
                success(self.productList);
            }
        });
        return;
    }
    
    [API getApi:API_PRODUCT_LIST params:nil responseModelClass:[ProductListModel class] cachePolicy:NetworkCachePolicyNone verifyResponse:NO processModelBlock:nil success:^(ProductListModel *  _Nullable model, NSDictionary * _Nonnull responseObject) {
        
        NSMutableDictionary *userDict = [NSMutableDictionary dictionary];
        userDict[@"status"] = @(model.status);
        userDict[@"version"] = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
        [[NSUserDefaults standardUserDefaults] setObject:userDict forKey:kUserStatusUserDefaultsKey];
        
        if (userStatusCallback) {
            userStatusCallback(nil);
        }
        
        ProductListItem *item = model.product_list.firstObject;
        if (item.product_id.length == 0) {
            
            if (failure) {
                failure(kError(NetworkErrorDomain, NetworkErrorCodeAPIModelIsNotValid));
            }
            return;
        }
        
        
        NSMutableDictionary *map = [NSMutableDictionary dictionary];
        NSMutableArray *ids = [NSMutableArray array];
        for (ProductListItem *item in model.product_list) {
            if (item.product_id) {
                [ids addObject:item.product_id];
                map[item.product_id] = item;
            }
        }
        
        [IHPurchase fetchProductsWithIds:ids block:^(NSArray<IHProduct *> * _Nullable validProducts, NSArray<NSString *> * _Nullable invalidProductIds, IHError * _Nonnull error) {
            
            if (error.code == IHErrorCodeOK) {
                
                NSArray<ProductListItem *> *validProductList = [self cacheProductInfoForUserRightsWithProducts:validProducts map:map];
                self.productList = validProductList;
                
                if (success) {
                    success(validProductList);
                }
                return;
            }
            
            if (failure) {
                failure(kIHError(error));
            }
        }];
        
    } failure:^(NSError * _Nonnull error) {
        
        if (failure) {
            failure(error);
        }
        
        if (userStatusCallback) {
            userStatusCallback(error);
        }
    }];
}

- (void)clearProductList {
    self.productList = nil;
}

- (void)purchaseWithProductId:(NSString *)productId {
    IHPayment *payment = [IHPayment paymentWithProductId:productId quantity:1];
    [IHPurchase purchaseWithPayment:payment uid:nil];
}

- (void)createOrderAndPurchaseWithProductId:(NSString *)productId createOrderSuccess:(void (^)(NSString *orderId))createOrderSuccess failure:(nonnull void (^)(NSError * _Nonnull))failure {
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"product_id"] = productId;
    
    [API getApi:API_CREATE_ORDER params:params responseModelClass:[PurchaseOrder class] cachePolicy:NetworkCachePolicyNone verifyResponse:NO processModelBlock:nil success:^(PurchaseOrder *  _Nullable model, NSDictionary * _Nonnull responseObject) {
        
        DLog(@"%@", responseObject);
        IHPayment *payment = [IHPayment paymentWithProductId:productId quantity:1];
        payment.appOrderId = model.order_id;
        payment.safeInfo = model.safe_info;
        
        DLog(@"product_id: %@, uid: %@", payment.product.productId, model.uid);
        [IHPurchase purchaseWithPayment:payment uid:model.uid];
        
        if (createOrderSuccess) {
            createOrderSuccess(model.order_id);
        }
        
    } failure:^(NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

- (void)restore {
    [self clearProductList];
    [self fetchProductList:^(NSArray<ProductListItem *> * _Nonnull products) {
        [IHPurchase restorePurchase];
    } failure:^(NSError * _Nonnull error) {
        [IHPurchase restorePurchase];
    } userStatusCallback:nil];
}

// AppStore购买。打开家长验证，通过后购买。
- (void)wantsToPurchasePromotedPayment:(IHPayment *)payment {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"product_id"] = payment.product.productId;

    [API getApi:API_CREATE_ORDER params:params responseModelClass:[PurchaseOrder class] cachePolicy:NetworkCachePolicyNone verifyResponse:NO processModelBlock:nil success:^(PurchaseOrder *  _Nullable model, NSDictionary * _Nonnull responseObject) {
        DLog(@"%@", responseObject);

        payment.appOrderId = model.order_id;
        payment.safeInfo = model.safe_info;

        DLog(@"product_id: %@, uid: %@", payment.product.productId, model.uid);
        [IHPurchase purchaseWithPayment:payment uid:model.uid];
    } failure:^(NSError * _Nonnull error) {
        DLog(@"%@", error);
    }];
}


- (NSArray<ProductListItem *> *)cacheProductInfoForUserRightsWithProducts:(NSArray<IHProduct *> *)products map:(NSDictionary *)map {
    
    NSMutableDictionary *productIdForUserRightsType = [NSMutableDictionary dictionary];
    NSDictionary *cachedDict = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kProductIdForUserRightsUserDefaultKey];
    if (cachedDict.count > 0) {
        [productIdForUserRightsType addEntriesFromDictionary:cachedDict];
    }
    
    NSMutableArray *validProducts = [NSMutableArray array];
    for (IHProduct *product in products) {
        ProductListItem *item = map[product.productId];
        if (item.rights_type) {
            productIdForUserRightsType[item.rights_type] = [item yy_modelToJSONObject];
        }
        item.ih_product = product;
        [validProducts addObject:item];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:productIdForUserRightsType forKey:kProductIdForUserRightsUserDefaultKey];
    return validProducts;
}

- (NSDictionary *)productInfoForUserRightsType:(NSString *)userRightsType {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kProductIdForUserRightsUserDefaultKey];
    return dict[userRightsType];
}

- (BOOL)hasVisitorRights:(NSString *)userRightsType {
    
    ProductListItem *productInfo = [ProductListItem yy_modelWithJSON:[self productInfoForUserRightsType:userRightsType]];
    if (productInfo == nil) {
        return NO;
    }
    
    IHPurchasedProduct *purchasedProduct = [IHPurchase purchasedProductWithId:productInfo.product_id];
    if (purchasedProduct == nil) {
        return NO;
    }
    
    if (productInfo.product_type == 1) { // 非消耗品
        if (purchasedProduct.purchasedStatus == IHPurchasedStatusPurchased) {
            return YES;
        }
    }
    
    if (productInfo.product_type == 2) { // 连续订阅
        if (purchasedProduct.purchasedStatus == IHPurchasedStatusInSubscription || purchasedProduct.purchasedStatus == IHPurchasedStatusInTrial) {
            return YES;
        }
    }
    
    return NO;
}

- (BOOL)hasAnyVisitorRights {
    for (IHPurchasedProduct *product in [IHPurchase allPurchasedProducts]) {
        if (product.purchasedStatus == IHPurchasedStatusPurchased || product.purchasedStatus == IHPurchasedStatusInSubscription || product.purchasedStatus == IHPurchasedStatusInTrial) {
            return YES;
        }
    }
    
    return NO;
}

- (NSInteger)userStatus {
    
    NSDictionary *userDict = [[NSUserDefaults standardUserDefaults] objectForKey:kUserStatusUserDefaultsKey];
    if (userDict == nil) {
        return 1;
    }
    
    NSString *version = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
    if ([version isEqualToString:userDict[@"version"]]) {
        return [userDict[@"status"] integerValue];
    }
    
    return 1;
}

- (NSString *)productPriceWithRate:(double)rate productId:(NSString *)productId {
    
    for (ProductListItem *item in self.productList) {
        if ([item.product_id isEqualToString:productId]) {
            if (item.ih_product) {
                return [item.ih_product priceStringWithRate:rate];
            }
        }
    }
    
    return @"";
}

- (NSString *)productPriceWithPrice:(double)price productId:(NSString *)productId {
    
    for (ProductListItem *item in self.productList) {
        if ([item.product_id isEqualToString:productId]) {
            if (item.ih_product) {
                return [item.ih_product priceStringWithPrice:price];
            }
        }
    }
    
    return @"";
}


@end


