//
//  PurchaseModel.m
//  Enlighten
//
//  Created by changle on 2022/8/1.
//

#import "PurchaseModel.h"

@implementation PurchaseOrder

@end

@implementation ProductListModel

+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass {
    return @{
        @"product_list" : [ProductListItem class],
    };
}

@end

@implementation ProductListItem


+ (nullable NSArray<NSString *> *)modelPropertyBlacklist {
    return @[
        @"ih_product"
    ];
}

@end
