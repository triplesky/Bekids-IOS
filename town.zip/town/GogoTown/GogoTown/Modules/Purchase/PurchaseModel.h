//
//  PurchaseModel.h
//  Enlighten
//
//  Created by changle on 2022/8/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PurchaseOrder : NSObject

@property (nonatomic, copy) NSString *order_id;
@property (nonatomic, copy) NSString *safe_info;
@property (nonatomic, copy) NSString *uid;

@end

@class ProductListItem;

@interface ProductListModel : NSObject

@property (nonatomic, assign) NSInteger status;
@property (nonatomic, strong) NSArray<ProductListItem *> *product_list;

@end


@interface ProductListItem : NSObject

/// 商品id
@property (nonatomic, copy) NSString *product_id;

@property (nonatomic, copy) NSString *legacy_product_id;

/// 商品描述
@property (nonatomic, copy) NSString *product_desc;

/// 权益类型
@property (nonatomic, copy) NSString *rights_type;

/// 消耗品的商品数量
@property (nonatomic, assign) NSInteger payable_amount;

/// 商品类型: 1 非消耗品，2 连续订阅
@property (nonatomic, assign) NSInteger product_type;

/// 商品名称
@property (nonatomic, copy) NSString *product_name;

/// 永久包折扣
@property (nonatomic, assign) NSInteger all_pack_discount;

/// sdk商品
@property (nonatomic, strong) IHProduct *ih_product;

@end

NS_ASSUME_NONNULL_END
