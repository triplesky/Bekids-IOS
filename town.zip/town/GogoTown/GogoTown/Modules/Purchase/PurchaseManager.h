//
//  PurchaseManager.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import <Foundation/Foundation.h>
#import "PurchaseModel.h"


NS_ASSUME_NONNULL_BEGIN

@interface PurchaseManager : NSObject

+ (instancetype)sharedInstance;

- (void)fetchProductList:(void (^)(NSArray<ProductListItem *> * _Nullable products))success failure:(void (^)(NSError *error))failure userStatusCallback:(void (^ _Nullable)(NSError * _Nullable error))userStatusCallback;

- (void)clearProductList;

- (void)purchaseWithProductId:(NSString *)productId;

- (void)createOrderAndPurchaseWithProductId:(NSString *)productId createOrderSuccess:(void (^)(NSString *orderId))createOrderSuccess failure:(void (^)(NSError *error))failure;

- (void)restore;

- (NSDictionary *)productInfoForUserRightsType:(NSString *)userRightsType;

- (BOOL)hasAnyVisitorRights;
- (BOOL)hasVisitorRights:(NSString *)userRightsType;

- (NSInteger)userStatus;

- (void)wantsToPurchasePromotedPayment:(IHPayment *)payment;

- (NSString *)productPriceWithRate:(double)rate productId:(NSString *)productId;

- (NSString *)productPriceWithPrice:(double)price productId:(NSString *)productId;

@end

NS_ASSUME_NONNULL_END
