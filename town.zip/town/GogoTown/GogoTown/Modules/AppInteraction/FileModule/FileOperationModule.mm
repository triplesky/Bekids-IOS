//
//  FileOperationModule.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/12.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "FileOperationModule.h"
#import <QXUtilityKit/QXFile.h>
#import <Bugly/Bugly.h>
#import <QXUtilityKit/QXCodec.h>

@implementation FileOperationModule
- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(is_file_exist:(NSString*) filepath){
    return [self return_bool:[[NSFileManager defaultManager] fileExistsAtPath:filepath]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(rename_file:(NSString*) filepath newname:(NSString*) newname){
    if(filepath == nil || filepath.length == 0||
       newname == nil || newname.length == 0
       ){
       return [self return_bool:NO];
    }
    NSError * error = nil;
    NSString * newpath = [[filepath stringByDeletingLastPathComponent] stringByAppendingPathComponent:newname];
    [[NSFileManager defaultManager] moveItemAtPath:filepath toPath:newpath error:&error];
    if(error != nil){
        BLYLogError(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(copy_file_to:(NSString*) origin newname:(NSString*) dest){
    if(![[NSFileManager defaultManager] fileExistsAtPath:origin]){
         BLYLogError(@"拷贝的文件不存在:%@",origin);
        return [self return_bool:NO];
    }else{
        NSError * error = nil;
        [[NSFileManager defaultManager] copyItemAtPath:origin toPath:dest error:&error];
        if(error != nil){
            BLYLogError(@"%@",error);
            return [self return_bool:NO];
        }else{
            return [self return_bool:YES];
        }
    }
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(get_file_size:(NSString*) filePath){
    if(![[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        return [self return_number:0];
    }else{
        NSError * error = nil;
        NSDictionary<NSFileAttributeKey, id> * attrs = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:&error];
        if(error != nil){
            BLYLogError(@"%@",error);
            return [self return_number:0];
        }else{
            return [self return_bool:[attrs fileSize]];
        }
    }
}


- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(move_all_files_to_folder:(NSString*) origin dest:(NSString*) dest){
    BOOL isDirectory = NO;
    if(![[NSFileManager defaultManager] fileExistsAtPath:origin isDirectory:&isDirectory]){
        DLog(@"move_all_files_to_folder 拷贝的文件不存在:%@",origin);
        return [self return_bool:NO];
    }
    if(!isDirectory){
         DLog(@"这个路径不是文件夹:%@",origin);
         return [self return_bool:NO];
    }
    
    isDirectory = NO;
    if(![[NSFileManager defaultManager] fileExistsAtPath:dest isDirectory:&isDirectory]){
        DLog(@"move_all_files_to_folder 目标文件不存在:%@",dest);
        return [self return_bool:NO];
    }
    if(!isDirectory){
        DLog(@"这个路径不是文件夹:%@",dest);
        return [self return_bool:NO];
    }
    NSError * error = nil;
    NSArray<NSString *> *result = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:origin error:&error];
    if(error){
        DLog(@"%@",error);
         return [self return_bool:NO];
    }
    for(NSString * file in result){
        NSString * filename = [file lastPathComponent];
        NSString * destpath = [dest stringByAppendingPathComponent:filename];
        if([[NSFileManager defaultManager] fileExistsAtPath:destpath]){
            [[NSFileManager defaultManager] removeItemAtPath:destpath error:nil];
        }
        [[NSFileManager defaultManager] moveItemAtPath:[origin stringByAppendingPathComponent:file] toPath:destpath error:&error];
        if(error){
            DLog(@"%@",error);
            [self return_bool:NO];
        }
    }
    [[NSFileManager defaultManager] removeItemAtPath:origin error:nil];
    return [self return_bool:YES];
}



- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(read_text_from_file:(NSString*) filepath){
    NSString * str = [[NSString alloc] initWithContentsOfFile:filepath encoding:NSUTF8StringEncoding error:nil];
    return [self translate_string_for_unity:str];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(move_file_to:(NSString*) filepath dest:(NSString*) path){
    if(filepath == nil || filepath.length == 0||
       path == nil || path.length == 0
       ){
        return [self return_bool:NO];
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:path]){
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
    NSError * error = nil;
    [[NSFileManager defaultManager] moveItemAtPath:filepath toPath:path error:&error];
    if(error != nil){
        DLog(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(copy_file_to:(NSString*) filepath dest:(NSString*) path){
    if(filepath == nil || filepath.length == 0||
       path == nil || path.length == 0
       ){
        return [self return_bool:NO];
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:path]){
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
    NSError * error = nil;
    [[NSFileManager defaultManager] copyItemAtPath:filepath toPath:path error:&error];
    if(error != nil){
        DLog(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}


- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_file_at_path:(NSString*) filepath){
    NSError * error = nil;
    if([[NSFileManager defaultManager] fileExistsAtPath:filepath] == NO){
        return [self return_bool:YES];
    }
    [[NSFileManager defaultManager] removeItemAtPath:filepath error:&error];
    if(error != nil){
        DLog(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(get_file_md5:(NSString*) filepath)
{
    return [self translate_string_for_unity:[QXFile md5OfFileAtPath:filepath]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(get_string_md5:(NSString*)str) {
    return [self translate_string_for_unity:[str qx_md5]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(is_folder_exist:(NSString*) folderpath)
{
    BOOL isDirectory = NO;
    [[NSFileManager defaultManager] fileExistsAtPath:folderpath isDirectory:&isDirectory];
    return [self return_bool:isDirectory];
}

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(get_file_size_at_path:(NSString*) filePath)
{
    long long filesize = [self getFileSize:filePath];
    return [self return_number:filesize];
}

- (long long) getFileSize:(NSString *) filepath
{
    NSFileManager *manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filepath]){
        return [[manager attributesOfItemAtPath:filepath error:nil] fileSize];
    }
    DLog(@"文件不存在，无法获取大小:%@",filepath);
    return 0;
}


- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(rename_folder:(NSString*) folderpath newname:(NSString*) newname )
{
    if(folderpath == nil || folderpath.length == 0||
       newname == nil || newname.length == 0
       ){
        return [self return_bool:NO];
    }
    NSError * error = nil;
    NSString * newpath = [[folderpath stringByDeletingLastPathComponent] stringByAppendingPathComponent:newname];
    [[NSFileManager defaultManager] moveItemAtPath:folderpath toPath:newpath error:&error];
    if(error != nil){
        DLog(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(move_folder:(NSString*) folderpath dest:(NSString*) path)
{
    if(folderpath == nil || folderpath.length == 0||
       path == nil || path.length == 0
       ){
        return [self return_bool:NO];
    }
    BOOL isDirectory = NO;
    [[NSFileManager defaultManager] fileExistsAtPath:folderpath isDirectory:&isDirectory];
    if(!isDirectory){
        DLog(@"原始文件夹不存在，无法移动:%@",folderpath);
        return [self return_bool:NO];
    }
    isDirectory = NO;
    [[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDirectory];
    if(isDirectory){
         DLog(@"目标文件夹已经存在，直接移除,%@",path);
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
    NSError * error = nil;
    [[NSFileManager defaultManager] moveItemAtPath:folderpath toPath:path error:&error];
    if(error != nil){
        BLYLogError(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_folder:(NSString*) folderpath)
{
    NSError * error = nil;
    [[NSFileManager defaultManager] removeItemAtPath:folderpath error:&error];
    if(error != nil){
        BLYLogError(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
    
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(create_folder:(NSString*) folderpath)
{
    NSError * error = nil;
    [[NSFileManager defaultManager] createDirectoryAtPath:folderpath withIntermediateDirectories:YES attributes:nil error:&error];
    if(error != nil){
        BLYLogError(@"%@",error);
        return [self return_bool:NO];
    }else{
        return [self return_bool:YES];
    }
}


- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(get_folders_size:(NSArray*) folderlist)
{
    NSFileManager *manager = [NSFileManager defaultManager];
    long long folderSize = 0;
    if(folderlist == nil || folderlist.count == 0){
        DLog(@"文件夹列表不存在，无法查看大小");
        return [self return_number:folderSize];
    }
    for(NSString * folder in folderlist){
        if ([manager fileExistsAtPath:folder]){
            NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath:folder] objectEnumerator];
            NSString *fileName;
            while ((fileName = [childFilesEnumerator nextObject]) != nil){
                NSString *fileAbsolutePath = [folder stringByAppendingPathComponent:fileName];
                folderSize += [self getFileSize:fileAbsolutePath];
            }
        }else{
            DLog(@"文件夹不存在:%@",folder);
        }
    }
    return [self return_number:folderSize];
}



@end
