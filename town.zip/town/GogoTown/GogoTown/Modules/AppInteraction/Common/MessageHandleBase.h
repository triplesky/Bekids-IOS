//
//  MessageHandleBase.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/8.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MessageInvocation.h"
#import <iHumanSDK/iHumanSDK.h>
#import <QXUtilityKit/QXLogger.h>
NS_ASSUME_NONNULL_BEGIN

#ifndef CALL_NATIVE_FUNC_DEC
#define CALL_NATIVE_BLOCK block:(NSString*) blockID
#define CALL_NATIVE_BLOCK_NO_PARAMS :(NSString*) blockID
#define CALL_NATIVE_FUNC_DEC_WITH_PARAMS(FUNC_NAME) call_native_##FUNC_NAME CALL_NATIVE_BLOCK
#define CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(FUNC_NAME) call_native_##FUNC_NAME CALL_NATIVE_BLOCK_NO_PARAMS
#endif

@interface MessageHandleBase : NSObject
- (BOOL) respondsMessage:(NSString *) message;
- (const char*) processMessage:(NSString *) message params:(NSArray *) params block:(NSString *) block;

- (void) call_application:(NSString *) message params:(NSString *) jsonStr block:(NSString *) block_id;
- (void) report_download_task:(NSString*) url status:(int) status current:(int) bytes total:(int)total_bytes error:(int) ercode errormsg:(NSString*) errormsg;
- (void) make_params;

- (void) make_int_params:(NSString *) key value:(int) v;

- (void) add_int_params:(NSString *) key value:(int) v;

- (void) make_bool_params:(NSString *) key value:(bool) v;

- (void) add_bool_params:(NSString *) key value:(bool) v;

- (void) make_string_params:(NSString *) key value:(NSString *) v;

- (void) add_string_params:(NSString *) key value:(NSString *) v;

- (void) make_float_params:(NSString *) key value:(float) v;

- (void) add_float_params:(NSString *) key value:(float) v;

- (void) add_dic_params:(NSString*)key value:(NSDictionary*) v;

- (void) add_array_params:(NSString*)key value:(NSArray*) v;

- (NSString *) safe_string:(NSString *) row;

- (char*) translate_string_for_unity:(NSString *) s;
- (const char*) return_void;
- (const char*) return_string:(NSString*) str;
- (const char*) return_number:(double) num;
- (const char*) return_bool:(bool) bl;
- (const char*) return_object:(NSDictionary*) obj;
- (const char*) return_array:(NSArray*) obj;
- (const char*) return_int:(NSInteger )value;

- (NSString *) get_params;
- (void)ShowAlert:(NSString *) title content:(NSString*) content;
- (void)showSettingAlertWithTitle:(NSString *)title content:(NSString *)content block:(NSString *)blockID;
- (void) reportDownloadError:(NSString *) title info:(NSString *) errorInfo url:(NSString *) url;

- (void) logAction:(NSString*) event attr:(NSDictionary*) info;

- (void) app_enter_background;
- (void) app_enter_forgeground;

- (UIViewController*) get_current_top_view_controller;
@end

NS_ASSUME_NONNULL_END
