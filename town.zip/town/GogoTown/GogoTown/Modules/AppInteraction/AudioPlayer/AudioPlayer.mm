//
//  AudioPlayer.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2021/1/23.
//  Copyright © 2021 iHuman Inc. All rights reserved.
//

#import "AudioPlayer.h"
#import <AVFoundation/AVFoundation.h>

@class AudioPlayerHandler;
@protocol AudioPlayerHandlerProtocol <NSObject>

- (void) AudioPlayerHandlerDidPlayEnd:(AudioPlayerHandler*) player url:(NSString*) url res:(BOOL) result block:(NSString*) block;

@end



@interface AudioPlayerHandler: NSObject<AVAudioPlayerDelegate>
@property (nonatomic,strong) AVAudioPlayer * player;
@property (nonatomic,strong) NSString * blockID;
@property (nonatomic,strong) NSString * rawString;
@property (nonatomic,weak) id<AudioPlayerHandlerProtocol> delegate;
- (AudioPlayerHandler *) createPlayerWithURL:(NSURL *) url;

- (void) stop;
- (void) play;
@end

@implementation AudioPlayerHandler
- (void) stop
{
    [self.player stop];
}
- (void) play
{
     [self.player play];
}
- (AudioPlayerHandler *) createPlayerWithURL:(NSURL *) url
{
    NSError * error = nil;
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    self.player.delegate = self;
    if(error == nil){
        return self;
    }
    DLog(@"%@",error);
    return nil;
}
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [self.delegate AudioPlayerHandlerDidPlayEnd:self url:self.rawString res:flag block:self.blockID];
}

@end

@interface AudioPlayer()<AudioPlayerHandlerProtocol>
@property (nonatomic,strong) AudioPlayerHandler * player;
@end

@implementation AudioPlayer

- (void) setCategory{

}

- (void) stopCurrentAudio
{
    if(self.player!= nil){
        [self.player stop];
        self.player.delegate = nil;
        self.player = nil;
    }
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(reset_audio_category)
{
    [self setCategory];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(stop_current_audio_player)
{
    [self stopCurrentAudio];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(play_audio_with_url:(NSString *) urlstr)
{
    [self setCategory];
    [self stopCurrentAudio];
    AudioPlayerHandler * player = [[AudioPlayerHandler alloc] init];
    NSURL * url = [NSURL URLWithString:urlstr];
    NSData * audioData = [NSData dataWithContentsOfURL:url];
    NSString * docDirPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString * filename = [urlstr lastPathComponent];
    NSString * filePath = [[docDirPath stringByAppendingPathComponent:@"png"] stringByAppendingPathComponent:filename];
    [audioData writeToFile:filePath atomically:YES];
    

    [player createPlayerWithURL:[NSURL fileURLWithPath:filePath]];
    player.delegate = self;
    self.player = player;
    [self.player play];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(play_audio_at_path:(NSString *) path)
{
    [self setCategory];
    [self stopCurrentAudio];
    AudioPlayerHandler * player = [[AudioPlayerHandler alloc] init];
    [player createPlayerWithURL:[NSURL fileURLWithPath:path]];
    player.delegate = self;
    self.player = player;
    [self.player play];
}

- (void) AudioPlayerHandlerDidPlayEnd:(AudioPlayerHandler*) player url:(NSString*) url res:(BOOL) result block:(NSString*) block
{
    [self make_params];
    [self add_bool_params:@"result" value:result];
    [self add_string_params:@"url" value:url];
    [self call_application:@"audio_play_completed" params:[self get_params] block:block];
}

@end
