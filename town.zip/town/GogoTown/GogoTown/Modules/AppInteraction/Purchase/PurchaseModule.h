//
//  PurchaseModule.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import "MessageHandleBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface PurchaseModule : MessageHandleBase

@end

NS_ASSUME_NONNULL_END
