//
//  OperationalModule.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/9.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "MessageHandleBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface OperationalModule : MessageHandleBase

@end

NS_ASSUME_NONNULL_END
