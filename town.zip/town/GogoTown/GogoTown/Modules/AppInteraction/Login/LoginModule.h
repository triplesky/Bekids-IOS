//
//  LoginModule.h
//  Enlighten
//
//  Created by changle on 2022/7/11.
//

#import "MessageHandleBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginModule : MessageHandleBase

@end

NS_ASSUME_NONNULL_END
