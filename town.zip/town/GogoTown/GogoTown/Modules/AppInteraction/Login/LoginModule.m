//
//  LoginModule.m
//  Enlighten
//
//  Created by changle on 2022/7/11.
//

#import "LoginModule.h"
#import "UserCenter.h"
#import "AppDelegate.h"
#import "PurchaseManager.h"

@interface LoginModule ()

@end

@implementation LoginModule

- (instancetype)init {
    if (self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notiLoginUpdate) name:UserCenterLoginUpdateNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notiUserInfoUpdate) name:UserCenterUserInfoUpdateNotification object:nil];
    }
    
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(login) {
    
    [[UserCenter sharedInstance] loginWithSuccess:^{
        [self make_params];
        [self add_int_params:@"code" value:0];
        [self call_application:@"login" params:[self get_params] block:blockID];
    } failure:^(NSError * _Nonnull error) {
        [self make_params];
        [self add_string_params:@"domain" value:error.domain];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.localizedDescription];
        [self call_application:@"login" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(logout) {
    [[UserCenter sharedInstance] logout];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(refresh_user_info) {
    [[UserCenter sharedInstance] refreshUserInfoWithSuccess:^(UserInfoModel * _Nonnull model) {
        [self make_params];
        [self add_int_params:@"code" value:0];
        [self call_application:@"refresh_user_info" params:[self get_params] block:blockID];
    } failure:^(NSError * _Nonnull error) {
        [self make_params];
        [self add_string_params:@"domain" value:error.domain];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.localizedDescription];
        [self call_application:@"refresh_user_info" params:[self get_params] block:blockID];
    }];;
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(login_state) {
    return [self return_number:(int)[[UserCenter sharedInstance] loginState]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_login_info) {
    NSDictionary *obj = [[UserCenter sharedInstance].loginModel yy_modelToJSONObject];
    return [self return_object:obj ? : @{}];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_user_info) {
    NSDictionary *obj = [[UserCenter sharedInstance].userInfoModel yy_modelToJSONObject];
    return [self return_object:obj ? : @{}];
}

/// 用户权益
- (const char *)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_user_rights) {
    NSDictionary *obj = [[UserCenter sharedInstance].userRightsModel yy_modelToJSONObject];
    return [self return_object:obj ? : @{}];
}

/**
 获取当前用户信息
 
 @return 当前用户
 */
-(const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(current_account){
    return [self return_object:[[iHumanSDK currentAccount] yy_modelToJSONObject]];
}

/**
 获取上次登录的用户信息
 
 @return 上次登录的用户
 */
-(const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(last_account)
{
    return [self return_object:[[iHumanSDK lastAccount] yy_modelToJSONObject]];
}

/**
 获取当前未激活邮箱信息
 
 @return 当前缓存的未激活邮箱信息
 */
-(const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(inactive_email)
{
    return [self return_string:[self safe_string:[iHumanSDK inactiveEmail]]];
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(app_show_launch_view){
    AppDelegate* appController =  (AppDelegate*)[UIApplication sharedApplication].delegate;
    [appController showLaunchScreenWithCompletion:^{
        [self call_application:@"app_show_launch_view" params:[self get_params] block:blockID];
    }];
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(client_begin_restart_action){
    
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(user_status)
{
    return [self return_number:(int)[[PurchaseManager sharedInstance] userStatus]];
}


- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(test_kick_off) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:LoginTokenExpiredNotification object:nil];
    });
}

#pragma mark -
- (void)notiUserInfoUpdate {
    [self make_params];
    [self call_application:@"noti_user_info_update" params:[self get_params] block:@""];
}

- (void)notiLoginUpdate {
    [self make_params];
    [self call_application:@"noti_login_update" params:[self get_params] block:@""];
}

@end
