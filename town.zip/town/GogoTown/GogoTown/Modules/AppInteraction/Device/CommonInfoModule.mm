//
//  CommonInfoModule.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/12/9.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "CommonInfoModule.h"
#import "ClientUtils.h"
#import "AppConfigs.h"
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"
#import "ToastView.h"
#import "NSString+GogoEncryptor.h"
#import "Photos/PHPhotoLibrary.h"
#import "Photos/PHAssetChangeRequest.h"
#import <DateTools/NSDate+DateTools.h>


@interface CommonInfoModule()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (nonatomic,assign) bool launchViewDidShow; //SDK里面只能展示一次，资源更新之后，重新加载之后，无法继续展示，导致流程中断
@end

@implementation CommonInfoModule

- (const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_environment)
{
    AppConfigs * config = [AppConfigs sharedInstance];
    NSString *appURL = [NSString  stringWithFormat: @"itms-apps://itunes.apple.com/app/id%@?action=write-review",APPSTORE_ID];
    NSDictionary * dic = @{
        @"debug_mode":@(config.debug_mode),
        @"env":@(config.enviroment),
        @"device_id":[iHumanSDK deviceId],
        @"platform":@"ios",
        @"phone":@(![iHumanSDK isPad]),
        @"app_version":config.app_version,
        @"app_url":appURL,
        @"channel":@"appstore",
        @"app_display_name":config.app_display_name
    };
    return [self return_object:dic];
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(pasteboard_text:(NSString *) content)
{
    UIPasteboard* pasteboard = [UIPasteboard generalPasteboard];
    [pasteboard setString:content];
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(regist_system_notification:(NSString *) name)
{
    if(name && name.length > 0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recive_system_notification:) name:name object:nil];
    }
}

-(void) recive_system_notification:(NSNotification *) notification
{
    [self make_params];
    [self call_application:notification.name params:[self get_params] block:@""];
}


-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_phone_login_view_with_number:(NSString*) number url:(NSString*) url){
//    AppDelegate* appController =  (AppDelegate*)[UIApplication sharedApplication].delegate;
//    appController.orientationType = IHOrientationTypeLandscape;
//    LoginWithPhoneViewController * loginViewController = [[LoginWithPhoneViewController alloc] init];
//    loginViewController.phonenumber = number;
//    loginViewController.url = url;
//    loginViewController.enterType = 0;
//    loginViewController.modalPresentationStyle = UIModalPresentationFullScreen;
//    UIViewController* vc =  [UIApplication sharedApplication].delegate.window.rootViewController;
//    [vc presentViewController:loginViewController animated:YES completion:nil];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(authorization_status_for_audio){
//    DLog(@"authorization_status_for_audio = %zd",[IHPreference authorizationStatusForAudio]);
//    NSInteger value =(NSInteger)[IHPreference authorizationStatusForAudio];
//    DLog(@"authorization_status_for_audio = %s %d",[self return_int:[IHPreference authorizationStatusForAudio]],value);
    return [self return_int:[IHPreference authorizationStatusForAudio]];
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(request_authorization_status_for_audio){
    [IHPreference requestAccessForAudioWithBlock:^(IHAuthorizationStatus status) {
        [self make_int_params:@"status" value:(int)status];
        [self call_application:@"request_authorization_status_for_audio" params:[self get_params] block:blockID];
    }];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(authorization_status_for_camera){
    return [self return_int:[IHPreference authorizationStatusForCamera]];
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(request_authorization_status_for_camera){
    [IHPreference requestAccessForCameraWithBlock:^(IHAuthorizationStatus status) {
        [self make_int_params:@"status" value:(int)status];
        [self call_application:@"request_authorization_status_for_camera" params:[self get_params] block:blockID];
    }];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(authorization_status_for_photo){
    return [self return_int:[IHPreference authorizationStatusForPhoto]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(authorization_status_for_photo_add_only) {
    PHAuthorizationStatus status;
    if (@available(iOS 14.0, *)) {
        status = [PHPhotoLibrary authorizationStatusForAccessLevel:PHAccessLevelAddOnly];
    } else {
        status = [PHPhotoLibrary authorizationStatus];
    }
    
    return [self return_int:[self ihAuthorizationStatusForPHAuthorizationStatus:status]];
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(request_authorization_status_for_photo){
    [IHPreference requestAccessForPhotoWithBlock:^(IHAuthorizationStatus status) {
        [self make_int_params:@"status" value:(int)status];
        [self call_application:@"request_authorization_status_for_photo" params:[self get_params] block:blockID];
    }];
}


- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(request_authorization_status_for_photo_add_only) {
    if (@available(iOS 14.0, *)) {
        [PHPhotoLibrary requestAuthorizationForAccessLevel:PHAccessLevelAddOnly handler:^(PHAuthorizationStatus status) {
            [self make_int_params:@"status" value:(int)[self ihAuthorizationStatusForPHAuthorizationStatus:status]];
            [self call_application:@"request_authorization_status_for_photo_add_only" params:[self get_params] block:blockID];
        }];
    } else {
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            [self make_int_params:@"status" value:(int)[self ihAuthorizationStatusForPHAuthorizationStatus:status]];
            [self call_application:@"request_authorization_status_for_photo_add_only" params:[self get_params] block:blockID];
        }];
    }
}

- (IHAuthorizationStatus)ihAuthorizationStatusForPHAuthorizationStatus:(PHAuthorizationStatus)status {
    
    IHAuthorizationStatus ihStatus;
    switch (status) {
        case PHAuthorizationStatusNotDetermined:
            ihStatus = IHAuthorizationStatusNotDetermined;
            break;
        case PHAuthorizationStatusAuthorized:
            ihStatus = IHAuthorizationStatusAuthorized;
            break;
        default:
            ihStatus = IHAuthorizationStatusDenied;
            break;
    }
    
    return ihStatus;
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(save_image:(NSString *)image_path){
    UIImage *saveImage = [UIImage imageWithContentsOfFile:image_path];
    if (saveImage == nil) {
        [self make_bool_params:@"success" value:false];
        [self call_application:@"save_image" params:[self get_params] block:blockID];
    }
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
        [PHAssetChangeRequest creationRequestForAssetFromImage:saveImage];
    } completionHandler:^(BOOL success, NSError * _Nullable error) {
        NSLog(@"save_image--success = %d, error = %@", success, error);
        [self make_bool_params:@"success" value:success];
        [self call_application:@"save_image" params:[self get_params] block:blockID];
        if (saveImage != nil) {
            NSError * removeError = nil;
            [[NSFileManager defaultManager] removeItemAtPath:image_path error:&removeError];
        }
    }];
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_setting_alert_view:(NSString*)title content:(NSString*)content){
    [self showSettingAlertWithTitle:title content:content block:blockID];
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(open_app_preference){
    [IHPreference openAppPreference];
}

//打开自己app所在的appstore
-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(open_current_app_store){
    [IHPreference openAppStoreWithId:APPSTORE_ID];
}


-(void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(open_app_store_with_id:(NSString*) appid){
    [IHPreference openAppStoreWithId:appid];
}


#pragma mark-iHumanSDKProtocol

/**
 设置SDK的语言，某些SDK自己触发的UI界面，需要根据语言来进行显示
 */

-(void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_language:(int) language){
    [iHumanSDK setLanguage:(IHLanguageType)language];
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_language_v2:(int) language region:(int)region){
    [iHumanSDK setLanguage:(IHLanguageType)language region:(IHLanguageRegionType)(region)];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(preferred_language){
    NSLog(@"%zd",[iHumanSDK preferredLanguage]);
    return [self return_number:[iHumanSDK preferredLanguage]];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(preferred_language_region){
    return [self return_number:[iHumanSDK preferredLanguageRegion]];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(is_simplified_chinese){
    NSArray * preferred_languages =[NSLocale preferredLanguages];
    if(preferred_languages.count == 0){
        return [self return_bool:NO];
    }
    NSString * current_language_name = preferred_languages[0];
    if([current_language_name isEqualToString:@"zh-Hans-CN"] || [current_language_name isEqualToString:@"zh-Hans"] )
    {
        return  [self return_bool:YES];;
    }
    return [self return_bool:NO];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(current_server_time){
    return [self return_number:[iHumanSDK currentServerTime]];
}
/**
 最低支持的iOS版本
 
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(mini_support_ios_version){
    return [self return_string:[iHumanSDK minSupportiOSVersion]];
}

/**
 SDK版本
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(sdk_version){
    return [self return_string:[iHumanSDK sdkVersion]];
}
/**
 切换Debug模式
 */
-(void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(enable_debug_mode:(BOOL) bl){
    [iHumanSDK enableDebugMode:bl];
}

/**
 服务器检测到客户端是否属于海外
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(is_overseas){
    return [self return_bool:[iHumanSDK isOverseas]];
}
/**
 app当前的地域
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(app_region){
    NSString *countryCode = [[NSLocale currentLocale] countryCode];
    if (countryCode == nil) {
        countryCode = @"CN";
    }
    return [self return_string:countryCode];
}

#pragma mark-IHAppProtocol

//-(NSDictionary*) qqinfo_to_dic:(IHQQInfo*) qq
//{
//    return @{
//        @"number":[self safe_string:qq.number],
//        @"name":[self safe_string:qq.name],
//        @"url":[self safe_string:qq.url]
//    };
//}

/**
 获取QQ群信息
 */
//-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_qq_info){
//    return [self return_object:[self qqinfo_to_dic:[iHumanSDK qqInfo]]];
//}
/**
 获取"关于我们"页面URL
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(about_us_url){
    return [self translate_string_for_unity:[iHumanSDK aboutusURL]];
}

/// 显示开屏页面
-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_launch_view_with_dismiss_block){
//    [iHumanSDK useVideoLaunchView:YES];
//    [iHumanSDK showLaunchViewWithDismissBlock:^{
//        self.launchViewDidShow = YES;
//        [self make_params];
//        [self call_application:@"show_launch_view_with_dismiss_block" params:[self get_params] block:blockID];
//    }];
    
    
}

/**
 app 签名
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(app_sign_for_params:(NSDictionary*) params){
    return [self return_string:[iHumanSDK appSignForParams:params]];
}


/**
 验证app API返回值签名
 */
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(verify_sign_response:(NSDictionary*) params forURL:(NSString *)URLString){
    return [self return_bool:[iHumanSDK verifyResponse:params forURL:URLString]];
}


/// 验证app API返回值签名
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(verify_sign_response_string:(NSString *)responseString forURL:(NSString *)URLString){
    return [self return_bool:[iHumanSDK verifyResponseString:responseString forURL:URLString]];
}

///  获取App logo Icon数组
-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(app_icon_files_array){
    return [self return_array:[iHumanSDK appIconFilesArray]];
}

///  获取App logo Icon name
/// @return logo Icon name

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(app_icon_name){
    return [self return_string:[iHumanSDK appIconName]];
}

-(const char*) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(is_pad){
    return [self return_bool:[iHumanSDK isPad]];
}


#pragma mark-eduInfo

-(void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(report_edu_info:(NSDictionary *)info){
    [IHEdu reportEduInfo:[IHEduInfo eduInfoWithDict:info]];
}
/**
 获取学习报告小程序信息
 */

-(NSDictionary *) mini_program_to_dic:(IHReportMiniProgram*) info
{
    return @{
        @"subscribed":@(info.subscribed),
        @"name":[self safe_string:info.name],
        @"path":[self safe_string:info.path],
        @"type":@(info.type),
        @"url":[self safe_string:info.url],
    };
}
-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(fetch_report_mini_program_with_block){
    [IHEdu fetchReportMiniProgramWithBlock:^(IHReportMiniProgram *progarm, IHError *error) {
        [self make_params];
        [self add_dic_params:@"program" value:[self mini_program_to_dic:progarm]];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_report_mini_program_with_block" params:[self get_params] block:blockID];
    }];
}

-(void) CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_native_launcher_view){
    if(!self.launchViewDidShow){
        [iHumanSDK useVideoLaunchView:YES];
        [iHumanSDK showLaunchViewWithDismissBlock:^{
            self.launchViewDidShow = YES;
            [self make_params];
            [self call_application:@"launch_view_did_close" params:[self get_params] block:blockID];
        }];
    }else{
        [self make_params];
        [self call_application:@"launch_view_did_close" params:[self get_params] block:blockID];
    }
}

-(const char *) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_audio_session:(NSString*) audio_session){
    NSError * error = nil;
//    [[AVAudioSession sharedInstance] setCategory:audio_session error:&error];
    if([[AVAudioSession sharedInstance].category isEqualToString:audio_session]){
        return [self return_bool:YES];
    }
    [[AVAudioSession sharedInstance] setCategory:audio_session withOptions:AVAudioSessionCategoryOptionAllowBluetoothA2DP|AVAudioSessionCategoryOptionDefaultToSpeaker error:&error];
//    [[AVAudioSession sharedInstance] setActive:YES error:&error];
    if(error){
        DLog(@"%@",error);
        return [self return_bool:NO];
    }
    return [self return_bool:YES];
}


- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(device_free_space){
    long long space = [iHumanSDK freeSpace];
    space = space/1024.0/1024.0;
    return [self return_number:space];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_abtest_group_id){
    DLog(@"%d",[iHumanSDK groupId]);
    return [self return_number:[iHumanSDK groupId]];
}


- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(keep_app_alive){
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

-(void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_debug_alert_view:(NSString*) title content:(NSString*) content){
    [self ShowAlert:title content:content];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(show_toast:(NSString *)toast) {
    [ToastView showToast:toast];
}

- (void) app_enter_background
{
    
}

- (void) app_enter_forgeground
{
    
}

-(void)  CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(open_photos){
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]){
        UIImagePickerController * imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        imagePicker.mediaTypes = [NSArray arrayWithObject:@"public.movie"];
        imagePicker.allowsEditing = YES;
        imagePicker.delegate = self;
        UIViewController * top_view_controller = [self get_current_top_view_controller];
        if(top_view_controller != nil){
            [top_view_controller presentViewController:imagePicker animated:YES completion:^{
                            
            }];
        }
    }
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info
{
    NSURL * url = info[@"UIImagePickerControllerMediaURL"];
    if(url != nil){
        [picker dismissViewControllerAnimated:YES completion:^{
//            [LoginHelper share_video_with_url:url];
        }];
       
    }
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(gogo_key:(NSString*)) {
    return [self return_string:@"roxrEdcBNPuiVLO5xpJJ2tClyNQ1IZ7a"];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(gogo_key_p1:(NSString*)key p1:(NSString *)p1) {
    return [self return_string:[key gogo_keyWithP1:p1]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(gogo_key_p1_p2:(NSString*)key p1:(NSString *)p1 p2:(NSString *)p2) {
    return [self return_string:[key gogo_keyWithP1:p1 p2:p2]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(date_string_with_system_timezone:(double)utc_time format:(NSString *)format) {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:utc_time];
    return [self return_string:[date formattedDateWithFormat:format]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_gogo_town_app_scheme_list) {
    NSArray *schemeList = [NSBundle mainBundle].infoDictionary[@"LSApplicationQueriesSchemes"];
    NSString *bundleId = [NSBundle mainBundle].infoDictionary[@"CFBundleIdentifier"];
    bundleId = [bundleId stringByReplacingOccurrencesOfString:@".staging2" withString:@".staging"];
    
    NSMutableArray *resList = [NSMutableArray array];
    
    for (NSString *scheme in schemeList) {
        if ([scheme containsString:@"com.bekids.gogotown"]) {
            if ([scheme isEqualToString:@"com.bekids.gogotown"] || [scheme isEqualToString:@"com.bekids.gogotown.staging"]) {
                
            } else if ([scheme isEqualToString:bundleId]) {
                
            } else {
                [resList addObject:scheme];
            }
        }
    }
    
    return [self return_array:resList];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_alternate_icon_name:(NSString *)icon_name) {
    [[UIApplication sharedApplication] setAlternateIconName:icon_name completionHandler:^(NSError * _Nullable error) {
        [self make_params];
        if (error) {
            [self add_int_params:@"code" value:(int)error.code];
        } else {
            [self add_int_params:@"code" value:0];
        }
        [self call_application:@"set_alternate_icon_name" params:[self get_params] block:blockID];
    }];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(get_alternate_icon_name) {
    return [self return_string:[[UIApplication sharedApplication] alternateIconName] ? : @""];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(clear_iap_cache) {
    [IHPurchase clearIAPCache];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(clear_device_info) {
    [iHumanSDK clearAllDeviceAppInfoCache];
    [iHumanSDK clearDeviceInfoCache];
    [iHumanSDK clearDeviceUnionIDCache];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(open_app:(NSString*)app_scheme){
    return [self return_bool:[iHumanSDK openApp:app_scheme]];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(can_open_app:(NSString*)app_scheme){
    return [self return_bool:[iHumanSDK canOpenApp:app_scheme]];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(open_app_store_to_app:(NSString*)app){
    [iHumanSDK openAppStoreToApp:app];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(open_inner_app_store_to_app:(NSString*)app){
    [iHumanSDK openInnerAppStoreToApp:app completionBlock:^(BOOL isOpenInApp, IHError * _Nullable error) {
        [self make_bool_params:@"did_finished_block" value:NO];
        [self add_bool_params:@"is_open_in_app" value:isOpenInApp];
        [self add_int_params:@"error_code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"open_inner_app_store_to_app" params:[self get_params] block:blockID];
    } didFinishedBlock:^{
        [self make_bool_params:@"did_finished_block" value:YES];
        [self call_application:@"open_inner_app_store_to_app" params:[self get_params] block:blockID];
    }];
}

@end
