//
//  DataReportModule.h
//  Enlighten
//
//  Created by changle on 2022/8/4.
//

#import "MessageHandleBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DataReportModule : MessageHandleBase

@end

NS_ASSUME_NONNULL_END
