//
//  UserCommentModule.m
//  ahaworld
//
//  Created by 王哲贤 on 2020/12/9.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "UserCommentModule.h"
#import "AppKeys.h"

@implementation UserCommentModule

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_zan) {
    [IHZan showZanWithAppId:APPSTORE_ID];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(show_myzan) {
    [IHZan showMyZanWithAppId:APPSTORE_ID completion:^(NSInteger score) {
        [self make_int_params:@"score" value:(int)score];
        [self call_application:@"show_myzan" params:[self get_params] block:blockID];
    }];
}

@end
