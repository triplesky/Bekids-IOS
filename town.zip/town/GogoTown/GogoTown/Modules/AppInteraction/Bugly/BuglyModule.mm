//
//  BuglyModule.m
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/10/16.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import "BuglyModule.h"
#import <Bugly/Bugly.h>
#import "ClientUtils.h"
#import <objc/runtime.h>
#import "MessageInvocation.h"
#import <UnityFramework/NativeCommunicater.h>
#import "AppKeys.h"
#import "ErrorMaker.h"

@interface BuglyModule()<BuglyDelegate>

@end

@implementation BuglyModule
- (instancetype)init{
    self = [super init];
    if(self){
      
    }
    return self;
}

+ (void) buglyLog:(NSString*) message
{
    [BuglyLog log:@"%@",message];
}

- (void) quick_respone_message:(NSString *) message info:(NSString *) info
{
    if ([@"bugly_report_exception" isEqualToString:message]) {
        [self call_native_bugly_report_exception:info block:nil];
    }else{
        [self call_native_bugly_log:info block:nil];
    }
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(bugly_log:(NSString *) message){
    BLYLogInfo(@"%@",message);
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(bugly_report_exception:(NSString *) excep){
    BLYLogError(@"%@",excep);
    if(excep == nil or excep.length == 0){
        return;
    }
    [self ShowAlert:@"代码异常" content:excep];
    NSDictionary * luaError = @{@"lua error":excep};
    NSInteger length =excep.length;
    if(length > 30){
        length = 30;
    }
    NSString * domain = [excep substringWithRange:NSMakeRange(0, length)];
    NSError * error = [NSError errorWithDomain:domain code:0 userInfo:luaError];
    [Bugly reportError:error];
}

- (void) CALL_NATIVE_FUNC_DEC_WITH_PARAMS(bugly_report_error:(NSString *) title content:(NSString*) content){
    NSException * exception = [NSException exceptionWithName:title reason:content userInfo:@{}];
    [Bugly reportException:exception];
}

- (void) checkInitBuglyTime
{
    BuglyConfig * config = [[BuglyConfig alloc] init];
    config.reportLogLevel = BuglyLogLevelVerbose;
    config.blockMonitorEnable = true;
    config.blockMonitorTimeout = 2;
    config.consolelogEnable = NO;
    config.channel = @"app store";
    config.delegate = self;
    [Bugly startWithAppId:BuglyKey config:config];
    [BuglyLog initLogger:BuglyLogLevelVerbose consolePrint:NO];
    NSString * userID = [NSString stringWithFormat:@"%@[%@]", [UIDevice currentDevice].name,[iHumanSDK deviceId]];
    [Bugly setUserIdentifier:userID];
}

- (void) initBugly
{
    TIME_CHECK(@"初始化BUGLY", @"BUGLY初始化结束",
               [self checkInitBuglyTime];
               );
    
    
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(register_error_message:(NSString *)message
                                         domain:(NSString *)domain
                                         code:(int)code
                                         identifier:(NSString *)identifier) {
    [ErrorMaker registerMessage:message forErrorDomain:domain code:code identifier:identifier];
}

- (const char*)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(error_message_for_domain:(NSString *)domain
                                         code:(int)code
                                         identifier:(NSString *)identifier
                                         ) {
    return [self return_string:[ErrorMaker messageForDomain:domain code:code identifier:identifier]];
}

#pragma mark- buglyDelegate
- (NSString * BLY_NULLABLE)attachmentForException:(NSException * BLY_NULLABLE)exception
{
    return [[NativeCommunicater sharedInstance] get_app_runing_state];
}



@end
