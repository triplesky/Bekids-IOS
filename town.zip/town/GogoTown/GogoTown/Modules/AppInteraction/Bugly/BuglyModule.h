//
//  BuglyModule.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/10/16.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MessageHandleBase.h"
NS_ASSUME_NONNULL_BEGIN

@interface BuglyModule : MessageHandleBase

- (void) quick_respone_message:(NSString *) message info:(NSString *) info;
- (void) initBugly;
+ (void) buglyLog:(NSString*) message;
@end

NS_ASSUME_NONNULL_END
