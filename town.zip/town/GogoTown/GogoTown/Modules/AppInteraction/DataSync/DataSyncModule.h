//
//  DataSyncModule.h
//  puzzle
//
//  Created by changle on 2022/12/8.
//

#import "MessageHandleBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface DataSyncModule : MessageHandleBase

@end

NS_ASSUME_NONNULL_END
