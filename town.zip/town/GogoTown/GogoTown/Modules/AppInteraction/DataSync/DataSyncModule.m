//
//  DataSyncModule.m
//  puzzle
//
//  Created by changle on 2022/12/8.
//

#import "DataSyncModule.h"
#import "UserCenter.h"

@interface DataSyncModule () <IHDataSyncDelegate>

@property (nonatomic, strong) NSMutableDictionary<NSString *, IHData *> *dataCache;

@end

@implementation DataSyncModule

- (instancetype)init {
    if (self = [super init]) {
        _dataCache = [NSMutableDictionary dictionary];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sdkLoginStateUpdate) name:UserCenterSDKLoginUpdateNotification object:nil];
        [IHDataSync setDelegate:self];
    }
    
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)sdkLoginStateUpdate {
    
    if ([UserCenter sharedInstance].loginModel.utoken.utoken) {
        NSString *utoken = [UserCenter sharedInstance].loginModel.utoken.utoken;
        DLog(@"cldebug setAppToken: %@", utoken);
        [IHDataSync setAppToken:utoken roleId:nil roleToken:nil];
    } else {
        [IHDataSync setAppToken:nil roleId:nil roleToken:nil];
    }
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(register_with_schema:(NSString *)schema)
{
    [IHDataSync registerWithSchema:schema];
    [self sdkLoginStateUpdate];
}

- (IHDNumber *)numberWithName:(NSString *)name {
    if (self.dataCache[name] == nil) {
        self.dataCache[name] = [IHDataSync numberWithName:name];
    }
    
    return (IHDNumber *)self.dataCache[name];
}

- (IHDString *)stringWithName:(NSString *)name {
    if (self.dataCache[name] == nil) {
        self.dataCache[name] = [IHDataSync stringWithName:name];
    }
    
    return (IHDString *)self.dataCache[name];
}

- (IHDSet *)setWithName:(NSString *)name {
    if (self.dataCache[name] == nil) {
        self.dataCache[name] = [IHDataSync setWithName:name];
    }
    
    return (IHDSet *)self.dataCache[name];
}

- (IHDMap *)mapWithName:(NSString *)name {
    if (self.dataCache[name] == nil) {
        self.dataCache[name] = [IHDataSync mapWithName:name];
    }

    return (IHDMap *)self.dataCache[name];
    
//    return [IHDataSync mapWithName:name];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_number_for_name:(NSString *)name number:(double)number) {
    return [self return_bool:[[self numberWithName:name] setNumber:number]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(increase_number_for_name:(NSString *)name number:(double)number) {
    return [self return_bool:[[self numberWithName:name] increaseNumber:number]];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_number_for_name:(NSString *)name) {
    [[self numberWithName:name] fetchNumberWithBlock:^(NSDictionary * _Nullable responseData, NSString * _Nullable responseString, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self add_dic_params:@"data_obj" value:responseData];
        [self call_application:@"fetch_number_for_name" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_string_for_name:(NSString *)name) {
    [[self stringWithName:name] fetchStringWithBlock:^(NSDictionary * _Nullable responseData, NSString * _Nullable responseString, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self add_dic_params:@"data_obj" value:responseData];
        [self call_application:@"fetch_string_for_name" params:[self get_params] block:blockID];
    }];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_string_for_name:(NSString *)name string:(NSString *)string) {
    return [self return_bool:[[self stringWithName:name] setString:string]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(add_number_to_set_for_name:(NSString *)name number:(double)number) {
    return [self return_bool:[[self setWithName:name] addObject:@(number)]];;
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(add_string_to_set_for_name:(NSString *)name string:(NSString *)string) {
    return [self return_bool:[[self setWithName:name] addObject:string]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(add_objects_to_set_for_name:(NSString *)name objects:(NSArray *)objects) {
    return [self return_bool:[[self setWithName:name] addObjects:objects]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(replace_objects_to_set_for_name:(NSString *)name objects:(NSArray *)objects) {
    return [self return_bool:[[self setWithName:name] replaceWithObjects:objects]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_number_to_set_for_name:(NSString *)name number:(double)number) {
    return [self return_bool:[[self setWithName:name] deleteObject:@(number)]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_string_to_set_for_name:(NSString *)name string:(NSString *)string) {
    return [self return_bool:[[self setWithName:name] deleteObject:string]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_objects_to_set_for_name:(NSString *)name objects:(NSArray *)objects) {
    return [self return_bool:[[self setWithName:name] deleteObjects:objects]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_all_objects_to_set_for_name:(NSString *)name) {
    return [self return_bool:[[self setWithName:name] deleteAllObjects]];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(check_number_exists_to_set_for_name:(NSString *)name number:(double)number) {
    [[self setWithName:name] checkObjectExist:@(number) block:^(BOOL exist, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_bool_params:@"data_obj" value:exist];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"check_number_exists_to_set_for_name" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(check_string_exists_to_set_for_name:(NSString *)name string:(NSString *)string) {
    [[self setWithName:name] checkObjectExist:string block:^(BOOL exist, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_bool_params:@"data_obj" value:exist];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"check_string_exists_to_set_for_name" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_length_in_set_for_name:(NSString *)name) {
    [[self setWithName:name] fetchLengthWithBlock:^(NSUInteger length, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_int_params:@"data_obj" value:(int)length];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_length_in_set_for_name" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_all_objects_in_set_for_name:(NSString *)name) {
    [[self setWithName:name] fetchAllObjectsWithBlock:^(NSDictionary * _Nullable responseData, NSString * _Nullable responseString, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_dic_params:@"data_obj" value:responseData];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_all_objects_in_set_for_name" params:[self get_params] block:blockID];
    }];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_number_for_name_for_key:(NSString *)name key:(NSString *)key number:(double)number) {
    return [self return_bool:[[self mapWithName:name] setObject:@(number) forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_string_for_name_for_key:(NSString *)name key:(NSString *)key string:(NSString *)string) {
    return [self return_bool:[[self mapWithName:name] setObject:string forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_object_for_name_for_key:(NSString *)name key:(NSString *)key object:(NSDictionary *)object) {
    return [self return_bool:[[self mapWithName:name] setObject:object forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_objects_for_name_for_key_array:(NSString *)name key_array:(NSArray *)key_array objects:(NSArray *)objects) {
    return [self return_bool:[[self mapWithName:name] setObjects:objects forKeys:key_array]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(set_all_dictionary_for_name:(NSString *)name dictionary:(NSDictionary *)dictionary) {
    return [self return_bool:[[self mapWithName:name] setObject:dictionary]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(replace_all_dictionary_for_name:(NSString *)name dictionary:(NSDictionary *)dictionary) {
    return [self return_bool:[[self mapWithName:name] replaceWithObject:dictionary]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(replace_number_for_name_for_key:(NSString *)name key:(NSString *)key number:(double)number) {
    return [self return_bool:[[self mapWithName:name] replaceWithObject:@(number) forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(replace_string_for_name_for_key:(NSString *)name key:(NSString *)key string:(NSString *)string) {
    return [self return_bool:[[self mapWithName:name] replaceWithObject:string forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(replace_object_for_name_for_key:(NSString *)name key:(NSString *)key object:(NSDictionary *)object) {
    return [self return_bool:[[self mapWithName:name] replaceWithObject:object forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(increase_number_for_name_for_key:(NSString *)name key:(NSString *)key number:(double)number) {
    return [self return_bool:[[self mapWithName:name] increaseNumber:number forKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_object_for_name_for_ley:(NSString *)name key:(NSString *)key) {
    return [self return_bool:[[self mapWithName:name] deleteObjectForKey:key]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_objects_for_name_for_key_array:(NSString *)name key_array:(NSArray *)key_array) {
    return [self return_bool:[[self mapWithName:name] deleteObjectsForKeys:key_array]];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(delete_all_objects_to_dict_for_name:(NSString *)name) {
    return [self return_bool:[[self mapWithName:name] deleteAllObjects]];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_object_for_name_for_key:(NSString *)name key:(NSString *)key) {
    [[self mapWithName:name] fetchObjectForKey:key block:^(NSDictionary * _Nullable responseData, NSString * _Nullable responseString, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_dic_params:@"data_obj" value:responseData];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_object_for_name_for_key" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_objects_for_name_for_key_array:(NSString *)name key_array:(NSArray *)key_array) {
    [[self mapWithName:name] fetchObjectsForKeys:key_array block:^(NSDictionary * _Nullable responseData, NSString * _Nullable responseString, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_dic_params:@"data_obj" value:responseData];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_objects_for_name_for_key_array" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_length_in_dict_for_name:(NSString *)name) {
    [[self mapWithName:name] fetchLengthWithBlock:^(NSUInteger length, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_int_params:@"data_obj" value:(int)length];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_length_in_dict_for_name" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(fetch_all_objects_in_dict_for_name:(NSString *)name) {
    [[self mapWithName:name] fetchAllObjectsWithBlock:^(NSDictionary * _Nullable responseData, NSString * _Nullable responseString, IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_dic_params:@"data_obj" value:responseData];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"fetch_all_objects_in_dict_for_name" params:[self get_params] block:blockID];
    }];
}

- (const char *)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(remove_data_from_cache_for_name:(NSString *)name) {
    if (name) {
        self.dataCache[name] = nil;
    }
    
    return [self return_bool:false];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(flush_data_with_name:(NSString *)name) {
    [IHDataSync flushDataWithName:name block:^(IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"flush_data_with_name" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(flush_all_data:(NSString *)name) {
    [IHDataSync flushAllDataWithBlock:^(IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"flush_all_data" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_PARAMS(force_flush_data:(NSDictionary *)merged_data) {
    [IHDataSync forceFlushData:merged_data block:^(IHError * _Nonnull error) {
        [self make_params];
        [self add_int_params:@"code" value:(int)error.code];
        [self add_string_params:@"message" value:error.message];
        [self call_application:@"force_flush_data" params:[self get_params] block:blockID];
    }];
}

- (void)CALL_NATIVE_FUNC_DEC_WITH_NO_PARAMS(test_invalid_data_version) {
    [IHDataSync testInvalidDataVersion];
}

#pragma mark - IHDataSyncDelegate
- (void)mergeWithData:(NSDictionary *)data dataString:(NSString *)dataString needForceFlush:(BOOL)needForceFlush {
    [self make_params];
    [self add_dic_params:@"data" value:data];
    [self add_bool_params:@"need_force_flush" value:needForceFlush];
    [self call_application:@"mongo_merge_with_data" params:[self get_params] block:@""];
}

@end
