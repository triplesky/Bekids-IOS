//
//  Network.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define NetworkShare [Network sharedInstance]

FOUNDATION_EXPORT NSString * const LoginTokenExpiredNotification;

FOUNDATION_EXTERN NSErrorDomain const NetworkErrorDomain;
FOUNDATION_EXTERN NSString *const ErrorResponseUserInfo;

typedef NS_ENUM(NSUInteger, NetworkErrorCode) {
    NetworkErrorCodeOK = 0,                       /// 无错误
    NetworkErrorCodeDefault = 1,                  /// 默认错误
    NetworkErrorCodeAPIModelIsNotValid = 1,       /// 接口返回的result与预期不一致，未通过客户端校验
    NetworkErrorCodeVerifyResponseFailed = 2,    /// 响应未通过客户端校验
};

typedef NS_ENUM(NSUInteger, NetworkCachePolicy) {
    NetworkCachePolicyNone = 0,                /// 不用缓存
    NetworkCachePolicyUseCacheWhenFailed = 1,     /// 请求失败时读缓存
};

@interface Network : NSObject

+ (instancetype)sharedInstance;

/// GET请求
/// @param url 请求路径
/// @param params 请求参数
/// @param modelClass 如果为nil，表示不需要解析responseObject，这时sucess回调返回的model的类型取决于AFN resposeObject返回的类型，或者为nil。
/// @param processModelBlock 预处理回调，子线程中执行，若返回值不为nil，则处理完毕的response.result会被替换为该回调的返回值。
/// @param success 成功回调
/// @param failure 失败回调
- (NSURLSessionDataTask *)getUrl:(NSString *)url params:(NSDictionary * _Nullable)params responseModelClass:(Class _Nullable)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)verifyResponse processModelBlock:(nullable id (^)(id _Nullable model))processModelBlock success:(void (^)(id _Nullable model, NSDictionary *responseObject))success failure:(void (^)(NSError * _Nonnull error))failure;

/// POST请求
/// @param url 请求路径
/// @param params 请求参数
/// @param modelClass 如果为nil，表示不需要解析responseObject，这时sucess回调返回的model的类型取决于AFN resposeObject返回的类型，或者为nil。
/// @param processModelBlock 预处理回调，子线程中执行，若返回值不为nil，则处理完毕的response.result会被替换为该回调的返回值。
/// @param success 成功回调
/// @param failure 失败回调
- (NSURLSessionDataTask *)postUrl:(NSString *)url params:(NSDictionary * _Nullable)params responseModelClass:(Class _Nullable)modelClass cachePolicy:(NetworkCachePolicy)cachePolicy verifyResponse:(BOOL)verifyResponse processModelBlock:(nullable id (^)(id _Nullable model))processModelBlock success:(void (^)(id _Nullable model, NSDictionary *responseObject))success failure:(void (^)(NSError * _Nonnull error))failure;

/// 获取公共参数
+ (NSMutableDictionary *)getCommonParams;

- (void)setValue:(NSString * _Nullable)value forCommonParamKey:(NSString *)key;

- (void)cancelWithTaskId:(NSUInteger)taskId;

- (void)clearCaches;

@end

NS_ASSUME_NONNULL_END
