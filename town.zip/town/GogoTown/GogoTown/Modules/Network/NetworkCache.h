//
//  NetworkCache.h
//  GogoTown
//
//  Created by changle on 2022/9/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NetworkCache : NSObject

- (void)loadResponseObjectWithUrl:(NSString *)url params:(NSDictionary *)params completion:(void (^)(id _Nullable responseObject))completion;

- (void)saveResponseObjectWithUrl:(NSString *)url params:(NSDictionary *)params responseObject:(id)responseObject;

- (void)clearCaches;

@end

NS_ASSUME_NONNULL_END
