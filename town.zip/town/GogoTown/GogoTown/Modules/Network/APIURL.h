//
//  APIURL.h
//  Enlighten
//
//  Created by changle on 2022/7/12.
//

#ifndef APIURL_h
#define APIURL_h

#ifdef ENVIRONMENT_STAGING

#define API_BASE_URL              @"https://staging-api.ihumand.com/gogo_town"

#else

#define API_BASE_URL              @"https://townapi.bekids.com/gogo_town"

#endif


/// 用户登录
#define API_LOGIN                       @"/client/user/v1/login"

#define API_GET_USER_INFO               @"/client/user/v1/get_user_info"

#define API_PRODUCT_LIST                @"/client/product/v1/list"

#define API_CREATE_ORDER                @"/client/order/v1/create_order"

#endif /* APIURL_h */
