//
//  OrientationController.h
//  Exercise
//
//  Created by changle on 2021/12/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, IHJOrientationType) {
    IHJOrientationTypeUseCurrent = 0,
    IHJOrientationTypeLandscape,
    IHJOrientationTypePortrait,
    IHJOrientationTypeAll,
};

@interface OrientationController : NSObject

+ (instancetype)sharedInstance;

/// SDK转屏，调用该方法更新
@property (nonatomic, assign) UIInterfaceOrientationMask orientationMask;

/// push页面 或 其他非present页面的任何时候，调用该方法强制更新app的横竖屏状态
- (void)updateInterfaceOrientationMask:(UIInterfaceOrientationMask)orientationMask;

- (void)setIHOrientation:(IHJOrientationType)orientation;

@end

NS_ASSUME_NONNULL_END
