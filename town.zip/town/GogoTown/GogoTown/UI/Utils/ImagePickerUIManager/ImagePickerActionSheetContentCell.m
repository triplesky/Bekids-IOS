//
//  ImagePickerActionSheetContentCell.m
//  live
//
//  Created by changle on 2020/9/16.
//  Copyright © 2020 changle. All rights reserved.
//

#import "ImagePickerActionSheetContentCell.h"

@interface ImagePickerActionSheetContentCell ()

@property (nonatomic, weak) UILabel *titleLabel;
@property (nonatomic, weak) UIView *lineView;

@end

@implementation ImagePickerActionSheetContentCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setupUI];
    }
    
    return self;
}

- (void)setupUI {
    
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
//    titleLabel.font = SP_FONT_C;
//    titleLabel.textColor = SP_COLOR_F;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    UIView *lineView = [[UIView alloc] init];
    [self.contentView addSubview:lineView];
    self.lineView = lineView;
    lineView.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.5];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    
    self.titleLabel.frame = CGRectMake(20, 0, w - 20 * 2, self.titleLabel.intrinsicContentSize.height);
    self.titleLabel.center = CGPointMake(self.titleLabel.center.x, h * 0.5);
    
    self.lineView.frame = CGRectMake(20, h - 1, w - 20 * 2, 1);
}

#pragma mark -
- (void)setTitle:(NSString *)title {
    _title = title.copy;
    self.titleLabel.text = title;
}

@end
