//
//  ImagePickerUIManager.h
//  live
//
//  Created by changle on 2020/9/16.
//  Copyright © 2020 changle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface ImagePickerUIManager : NSObject

- (void)showImagePickerControllerFromParentController:(UIViewController *)parentVc completion:(void (^)(UIImage * _Nullable image, BOOL success))completion;

@end

NS_ASSUME_NONNULL_END
