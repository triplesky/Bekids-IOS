//
//  ImagePickerUIManager.m
//  live
//
//  Created by changle on 2020/9/16.
//  Copyright © 2020 changle. All rights reserved.
//

#import "ImagePickerUIManager.h"
#import "ActionSheetContainerController.h"
#import "ImagePickerActionSheetContentView.h"

@interface UIImagePickerController(NO_AUTO_ROTATION)

@end
@implementation UIImagePickerController(NO_AUTO_ROTATION)
-(BOOL) shouldAutorotate
{
    return NO;
}
- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape;
}
@end






@interface ImagePickerUIManager () <
    ImagePickerActionSheetContentViewDelegate,
    UIImagePickerControllerDelegate,
    UINavigationControllerDelegate
>

@property (nonatomic, weak) UIViewController *parentVc;
@property (nonatomic, strong) ActionSheetContainerController *actionVc;
@property (nonatomic, strong) ImagePickerActionSheetContentView *actionView;
@property (nonatomic, strong) UIImagePickerController *pickerController;

@property (nonatomic, copy) void (^completionBlock)(UIImage *image, BOOL success);

@end

@implementation ImagePickerUIManager

- (void)showImagePickerControllerFromParentController:(UIViewController *)parentVc completion:(void (^)(UIImage * _Nullable, BOOL))completion {
    
    ImagePickerActionSheetContentView *contentView = [[ImagePickerActionSheetContentView alloc] init];
    contentView.frame = CGRectMake(0, 0, contentView.intrinsicContentSize.width, contentView.intrinsicContentSize.height);
    contentView.delegate = self;
    
    ActionSheetContainerController *sheet = [[ActionSheetContainerController alloc] init];
    sheet.contentView = contentView;
    
    [sheet showWithAnimated:YES completion:^(BOOL finished) {
        
    }];
    
    self.actionVc = sheet;
    self.actionView = contentView;
    self.completionBlock = completion;
    self.parentVc = parentVc;
}

- (void)dealloc
{
    self.actionVc.contentView = nil;
    self.actionVc.contentViewController = nil;
}

#pragma mark -
- (void)imagePickerActionSheetContentView:(ImagePickerActionSheetContentView *)contentView didSelectActionType:(ImagePickerActionSheetType)type {
    if (!self.parentVc) { return; }
    
    
    
    if (type == ImagePickerActionSheetTypeCancel) {
        [self.actionVc hideWithAnimated:YES completion:^(BOOL finished) {
            if (self.completionBlock) {
                self.completionBlock(nil, NO);
                self.completionBlock = nil;
            }
        }];
        return;
    }
    
    [self.actionVc hideWithAnimated:YES completion:nil];
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = (type == ImagePickerActionSheetTypeCamera) ? UIImagePickerControllerSourceTypeCamera : UIImagePickerControllerSourceTypePhotoLibrary;
    picker.modalPresentationStyle = UIModalPresentationFullScreen;
    picker.allowsEditing = YES;
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    }
    [self.parentVc presentViewController:picker animated:YES completion:nil];
    //[self.parentVc addChildViewController:picker];
    //[self.parentVc.view addSubview:picker.view];
}

#pragma mark -
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    if (self.completionBlock) {
        self.completionBlock(nil, NO);
        self.completionBlock = nil;
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info {
    UIImage *image = info[UIImagePickerControllerEditedImage];
    if (self.completionBlock) {
        self.completionBlock(image, image != NULL);
        self.completionBlock = nil;
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
