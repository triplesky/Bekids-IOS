//
//  ImagePickerActionSheetContentView.m
//  live
//
//  Created by changle on 2020/9/16.
//  Copyright © 2020 changle. All rights reserved.
//

#import "ImagePickerActionSheetContentView.h"
#import "ImagePickerActionSheetContentCell.h"

@interface ImagePickerActionSheetContentView () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, weak) UITableView *tableView;

@end

@implementation ImagePickerActionSheetContentView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    
    return self;
}

- (void)setupUI {
    
//    self.backgroundColor = [UIColor redColor];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    [self addSubview:tableView];
    self.tableView = tableView;
    tableView.dataSource = self;
    tableView.delegate = self;
    [tableView registerClass:[ImagePickerActionSheetContentCell class] forCellReuseIdentifier:@"cell"];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.rowHeight = 60;
    tableView.scrollEnabled = NO;


    tableView.layer.cornerRadius = 30;
}
- (BOOL) shouldAutorotate
{
    return NO;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    float widthRate = 0.8;
    self.tableView.frame = CGRectMake(self.bounds.size.width*(1-widthRate)*0.5, 0, self.bounds.size.width*widthRate, self.bounds.size.height);
}

- (CGSize)intrinsicContentSize {
    return CGSizeMake([UIScreen mainScreen].bounds.size.width - 20 * 2, 60 * 3);
}

#pragma mark -
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ImagePickerActionSheetContentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    if (indexPath.row == 0) {
        cell.title = @"拍照";
    } else if (indexPath.row == 1) {
        cell.title = @"从相册中选择";
    } else {
        cell.title = @"取消";
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.delegate respondsToSelector:@selector(imagePickerActionSheetContentView:didSelectActionType:)]) {
        [self.delegate imagePickerActionSheetContentView:self didSelectActionType:indexPath.row];
    }
}

@end
