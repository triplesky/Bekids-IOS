//
//  ToastView.h
//  Enlighten
//
//  Created by changle on 2022/7/15.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

NS_ASSUME_NONNULL_BEGIN

@interface ToastView : MBProgressHUD

+ (void)showToast:(NSString *)text;
+ (void)showToast:(NSString *)text fromView:(UIView *)view;
+ (void)showToast:(NSString *)text fromView:(UIView *)view completion:(void (^ _Nullable)(void))completion;
+ (void)showToast:(NSString *)text completion:(void (^ _Nullable)(void))completion;
+ (void)showToastImage:(NSString *)ImageStr text:(NSString *)text fromView:(UIView *)view;

@end

NS_ASSUME_NONNULL_END
