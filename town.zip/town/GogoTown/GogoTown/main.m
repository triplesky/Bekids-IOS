//
//  main.m
//  GogoTown
//
//  Created by changle on 2022/11/22.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#include <UnityFramework/UnityFramework.h>


int main(int argc, char * argv[]) {
    NSString * appDelegateClassName;
    @autoreleasepool {
        NSString* bundlePath = nil;
        bundlePath = [[NSBundle mainBundle] bundlePath];
        bundlePath = [bundlePath stringByAppendingString: @"/Frameworks/UnityFramework.framework"];
        
        NSBundle* bundle = [NSBundle bundleWithPath: bundlePath];
        if ([bundle isLoaded] == false) [bundle load];
        
        UnityFramework* ufw = [bundle.principalClass getInstance];
        if (![ufw appController])
        {
            [ufw setExecuteHeader: &_mh_execute_header];
        }
        [ufw setDataBundleId:"com.unity3d.framework"];
        [ufw runUIApplicationMainWithArgc: argc argv: argv];
        
        
        // Setup code that might create autoreleased objects goes here.
        appDelegateClassName = NSStringFromClass([AppDelegate class]);
    }
    
    return UIApplicationMain(argc, argv, nil, appDelegateClassName);
}
