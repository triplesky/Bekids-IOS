//
//  AppDelegate.h
//  GogoTown
//
//  Created by changle on 2022/11/22.
//

#import <UnityFramework/UnityFramework.h>
#import <iHumanSDK/iHumanSDK.h>
#import <UIKit/UIKit.h>

@interface AppDelegate : UnityAppController

- (void)showLaunchScreenWithCompletion:(void (^)(void))completion;

@end

