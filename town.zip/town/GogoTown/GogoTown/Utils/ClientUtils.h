//
//  ClientUtils.h
//  ReadingIOS
//
//  Created by 王哲贤 on 2020/9/23.
//  Copyright © 2020 iHuman Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <mach/mach_time.h>
#import <UIKit/UIKit.h>
#import <QXUtilityKit/QXLogger.h>


#define WEAK_SELF(ctype) __weak typeof(ctype) weakself = self;

#define TIME_CHECK(BEGIN_TAG,END_TAG,OP)\
CFAbsoluteTime begin_time = CFAbsoluteTimeGetCurrent();\
DLog(@"%@",BEGIN_TAG);\
\
OP;\
\
CFAbsoluteTime delta_time = CFAbsoluteTimeGetCurrent()-begin_time;\
DLog(@"%@ 时间:%f",END_TAG,delta_time);\

#define RGB_COLOR(R,G,B) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:1]

@interface ClientUtils : NSObject
+ (NSString *)convertToString:(NSDictionary *) dic;
+ (NSString *)convertArrayToString:(NSArray *) array;
+ (NSDictionary *)convertToDictionary:(NSString *) jsonStr;
+ (NSArray *)convertToArray:(NSString *) jsonStr;
+ (void) quickSetSession;
+ (BOOL) isPad;
+ (UIImage*) load_image:(NSString *) name;
+ (BOOL) is_current_user_login;
+ (void) show_login_view_controller;
+ (void) report_login_result:(NSDictionary *) user_info user_token:(NSDictionary *) tokenInfo new_account:(BOOL) new_account;
+ (void) report_login_result_from_sdk;
@end


