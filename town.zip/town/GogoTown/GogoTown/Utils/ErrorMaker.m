//
//  ErrorMaker.m
//  Enlighten
//
//  Created by changle on 2022/7/17.
//

#import "ErrorMaker.h"

static NSString *const kDefaultIdentifier = @"_inner";
static NSString *const kDefaultMessage = @"Something went wrong.";

@implementation ErrorMaker

static NSMutableDictionary *_messageInfo;

+ (void)load {
    _messageInfo = [NSMutableDictionary dictionary];
}

+ (NSError *)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code message:(NSString *)message extraInfo:(NSDictionary * _Nullable)extraInfo {
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    userInfo[NSLocalizedDescriptionKey] = message;
    
    if (extraInfo.count) {
        [userInfo addEntriesFromDictionary:extraInfo];
    }
    
    return [NSError errorWithDomain:domain code:code userInfo:userInfo];
}

+ (NSError *)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code identifier:(NSString * _Nullable)identifier extraInfo:(NSDictionary * _Nullable)extraInfo {
    NSString *message = [self messageForDomain:domain code:code identifier:identifier];
    return [self errorWithDomain:domain code:code message:message extraInfo:extraInfo];
}

+ (void)registerMessage:(NSString *)message forErrorDomain:(NSErrorDomain)domain code:(NSInteger)code identifier:(NSString * _Nullable)identifier {
    if (message == nil) {
        return;
    }
    
    if (domain.length == 0) {
        return;
    }
    
    NSMutableDictionary *codes = _messageInfo[domain];
    if (codes == nil) {
        codes = [NSMutableDictionary dictionary];
        _messageInfo[domain] = codes;
    }
    
    NSMutableDictionary *identifiers = codes[@(code)];
    if (identifiers == nil) {
        identifiers = [NSMutableDictionary dictionary];
        codes[@(code)] = identifiers;
    }
    
    if (identifier == nil) {
        identifier = kDefaultIdentifier;
    }
    
    identifiers[identifier] = message;
}

+ (void)registerMessage:(NSString *)message forErrorDomain:(NSErrorDomain)domain code:(NSInteger)code {
        [self registerMessage:message forErrorDomain:domain code:code identifier:kDefaultIdentifier];
}

+ (NSString *)messageForDomain:(NSErrorDomain)domain code:(NSInteger)code identifier:(NSString * _Nullable)identifier {
    if (identifier == nil) {
        identifier = kDefaultIdentifier;
    }
    
    NSMutableDictionary *codes = _messageInfo[domain];
    NSMutableDictionary *identifiers = codes[@(code)];
    NSString *message = identifiers[identifier];
    if (message == nil) {
        message = kDefaultMessage;
    }
    
    return message;
}


@end
