#!/bin/zsh -il

# Usage:

# package.sh \
# UPDATE_POD="${update_pod_repo}" \
# PROJECT_DIR="${PROJECT_DIR}" \
# PROJECT_NAME="${PROJECT_NAME}" \
# PODFILE_DIR="${PODFILE_DIR}" \
# INFOPLIST_FILE="${INFOPLIST_FILE}" \
# SCHEME="${scheme}" \
# CONFIGURATION_NAME="${configuration_name}" \
# EXPORT_OPTIONS_PLIST=${export_options_plist} \
# PROVISION="${provision}" \
# CERT="${cert}"


main() {

	for ARGUMENT in "$@"
	do
		KEY=$(echo $ARGUMENT | cut -f1 -d=)
		VALUE=$(echo $ARGUMENT | cut -f2 -d=)

		case "$KEY" in
			UPDATE_POD)				UPDATE_POD=${VALUE};;
			PROJECT_DIR)			PROJECT_DIR=${VALUE};;
			PROJECT_NAME)			PROJECT_NAME=${VALUE};;
			PODFILE_DIR)			PODFILE_DIR=${VALUE};;
			INFOPLIST_FILE)			INFOPLIST_FILE=${VALUE};;
			SCHEME)					SCHEME=${VALUE};;
			CONFIGURATION_NAME)		CONFIGURATION_NAME=${VALUE};;
			EXPORT_OPTIONS_PLIST)	EXPORT_OPTIONS_PLIST=${VALUE};;
			PROVISION)				PROVISION=${VALUE};;
			CERT)					CERT=${VALUE};;
			*)
		esac
	done
	
	UPDATE_POD=`echo ${UPDATE_POD-true} | tr '[:upper:]' '[:lower:]'`

	echo "UPDATE_POD: ${UPDATE_POD}"
	echo "PROJECT_DIR: ${PROJECT_DIR}"
	echo "PROJECT_NAME: ${PROJECT_NAME}"
	echo "PODFILE_DIR: ${PODFILE_DIR}"
	echo "INFOPLIST_FILE: ${INFOPLIST_FILE}"
	echo "SCHEME: ${SCHEME}"
	echo "CONFIGURATION_NAME: ${CONFIGURATION_NAME}"
	echo "EXPORT_OPTIONS_PLIST: ${EXPORT_OPTIONS_PLIST}"
	echo "PROVISION: ${PROVISION}"
	echo "CERT: ${CERT}"

	# 清空之前的缓存
	rm -rf ${WORKSPACE}/build/

	#更新Cocoapods
	update_cocoapods "$PODFILE_DIR" ${UPDATE_POD}

	#编译并打包主工程
	package_workspace "$PROJECT_DIR" "$PROJECT_NAME" "$INFOPLIST_FILE" "$SCHEME" "$CONFIGURATION_NAME" "$EXPORT_OPTIONS_PLIST" "$PROVISION" "$CERT"
}

update_cocoapods() {
	
	local podfile_dir=$1
	local update_pod_repo=$2

	cd $podfile_dir

	echo "===== 开始更新 Pod ====="

	local repo_update="--no-repo-update"
	if [ "${update_pod_repo}" = 'true' ]; then
	  repo_update=""
	else
	  pod repo update ihuman-mobile-public-ihuman-specs
	fi

	local pod_res=`pod update --verbose ${repo_update}`

	echo $pod_res

	if [[ ${pod_res} =~ "Pod installation complete" ]]; then
	  echo "===== Pod update 成功 ====="
	else
	  echo "===== Pod update 失败 ====="
	  exit -1
	fi
	echo "===== begin podfile.lock diff ====="
	git diff Podfile.lock
	echo "===== end podfile.lock diff ====="
}


package_workspace() {

	local project_dir=$1
	local project_name=$2
	local infoplist_path=$3

	local scheme=$4
	local configuration_name=$5
	local export_options_plist=$6
	local provision=$7
	local cert=$8

	local archive_path=${WORKSPACE}/build/${project_name}.xcarchive

	cd $project_dir

	echo "===== 开始编译 ${project_name} ====="


	if
	  xcodebuild clean archive \
	  -workspace "${project_name}.xcworkspace" \
	  -scheme "${scheme}" \
	  -configuration "${configuration_name}" \
	  -archivePath ${WORKSPACE}/build/${project_name}.xcarchive \
	  CONFIGURATION_BUILD_DIR=${WORKSPACE}/build \
	  CODE_SIGN_IDENTITY="${cert}" \
	  PROVISIONING_PROFILE_SPECIFIER="${provision}" \
	  -destination 'generic/platform=iOS'
	then
	  echo "===== ${project_name} 编译成功 ====="
	else
	  exit -1
	fi

	local commit_number=`git rev-parse --short HEAD`

	# build_number 最好在 xcodebuild之后再去获取，防止xcodebuild过程中更改该值
	local build_number=`/usr/libexec/PlistBuddy -c "Print CFBundleVersion" "$INFOPLIST_FILE"`

	cd ${WORKSPACE}/build

	if [[ $(grep "<string>app-store</string>" $export_options_plist) ]]; then
		isAppStore="APPSTORE"
	else
		isAppStore=""
	fi

	local archive_name="${scheme}_${configuration_name}_${isAppStore}_${NODE_NAME}_${BUILD_DISPLAY_NAME}_${commit_number}_${build_number}"

	xcodebuild -exportArchive \
	-archivePath ${archive_path} \
	-exportPath ${WORKSPACE}/build/${archive_name} \
	-exportOptionsPlist ${export_options_plist}

	cp ${WORKSPACE}/build/${archive_name}/*.ipa ${WORKSPACE}/build/${archive_name}.ipa

}

main "$@"
